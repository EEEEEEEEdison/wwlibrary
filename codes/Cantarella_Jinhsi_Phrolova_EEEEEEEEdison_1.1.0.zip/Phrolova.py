"""工具 workshop axis code: Cantarella / Jinhsi / Phrolova, 25 s advanced axis (Phrolova)."""
import logging
import time

import numpy as np
from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct', 'ring', 'ring_min', 'outer', 'inner', 'arms', 'miss_inner', 'miss_arms')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Phrolova(BaseChar):
    """Workshop axis team Cantarella / Jinhsi / Phrolova, 25 s advanced axis: Phrolova opens the loop axis.

    Node comments: axis row, axis text, video interval (s) and the timeline.json node id.
    """

    PROMPT_RING = 0.10  # E 格紫环占比阈值：亮 0.13–0.27、熄 ≤0.08（purple_ring.py 标定，I16）
    PROMPT_BG = 0.10  # 环外 0.85h–1.00h 紫色占比 ≥0.10 为背景泛紫，不算亮；真亮 ≤0.008、背景误判 0.54–0.86（I41）
    PROMPT_NATURAL = 0.8  # 普通入场到提示亮的固定时长，TS04、I16
    PROMPT_INTRO = 1.6  # 变奏入场到提示亮的固定时长，TS05、I16
    PROMPT_GRACE = 0.75  # 停点普攻后再等提示亮的上限
    PROMPT_RETRY = 0.6  # 普通入场第 2 轮只点普攻 0.6 s、不停点等；历史日志里循环第 3 行第 2 轮判亮 28 次都在开始后 0.4 s 内，不亮 19 次等到 3.1 s（I57）
    A3_HIT_DELAY = 0.75  # 提示亮到按强化 E 的延迟（等 A3 出伤），Phrolova.f2#1
    A3_ECHO_DELAY = 0.55  # 提示亮到按 Q 的延迟；0.70 s 时第 4 循环前多用约 0.6 s，10 局没有第 9 次龙喷，I42 也没变少（I52）
    HOLD_MARGIN = 0.1  # 等 Q、强化 E 时逐帧读提示，离按键不足 0.1 s 改为整段 sleep，免得读帧拖晚按键（I59）
    S1_ECHO_READY = 0.5  # 循环第 1 行等 Q 就绪的上限，I13
    ENH_A_WAIT = 1.5  # 强化普攻到紫环熄灭的上限，Phrolova.f1#2
    ECHO_SWITCH = 0.9  # Q 出冷却数字到切人的最短间隔；1.1 s 时三版无空中出场，用户同意缩短，试 0.9 s（I45、I53）
    STAR_EACH = 0.5  # 强化 E 每次按下后等紫环熄灭 0.5 s，最多 2 次，Phrolova.f2#1
    E_TRY_WAIT = 1.0  # 普通 E 每次按下后等提示亮 1.0 s，最多 2 次（卡弗 7），Phrolova.f3#0
    ENH_E_WAIT = 1.8  # 强化 E 到出冷却数字的上限，Phrolova.f3#1
    HEAVY_WAIT = 2.0  # 等鼠标图标亮、按住到复原，各自的上限，Phrolova.f3#2
    R_WAIT = 3.0  # R 反复尝试的上限（重击在后台打完前按 R 可能无效），Phrolova.f4#0
    R_DELAY = 0.7  # 入场后先等再按 R（I42 用户定）；0.25 s 时 12 次中 3 次 R 后今汐无变奏入场（I54）；用户 2026-10-30 改 0.7 s 试验

    _axis_char = True
    _in_force_switch = False  # 强切期间为真，见 liberation_available（I46）、get_current_con（I48）

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False
        self._reset_char_state()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._reset_char_state()

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        if target is None:
            self._raw_logger.warning(f'[{self._node.upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        self._in_force_switch = True
        try:
            return self.switch_next_char()
        finally:
            self._in_force_switch = False
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def liberation_available(self, check_color=True):
        # I46：BaseChar.switch_next_char 切人前读一次 R，只缓存给框架选人；强切用不上，有冷却数字时这次读要 OCR，约 0.13 s
        if self._in_force_switch:
            return False
        return super().liberation_available(check_color=check_color)

    def get_current_con(self):
        # I48：框架切人前读到 0.8–1 会停 0.05 s 再读一次，约 0.1 s；强切目标已定，切人循环里仍用 is_con_full 补认变奏
        con = super().get_current_con()
        if self._in_force_switch and 0.8 < con < 1:
            return 0.8
        return con

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 共用动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _cast_echo(self, tag, ready_timeout=0.0):
        """Q: optionally wait briefly for ready (I13), then click_echo; ok means the Q cooldown showed up."""
        ready = self.echo_available()
        if not ready and ready_timeout > 0:
            ready = bool(self.task.wait_until(self.echo_available, time_out=ready_timeout))
        if not ready:
            self._trace(tag, 'cast echo', ok=False, reason='not_ready')
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_echo')
            return False
        start = time.time()
        # Loop mode: presses every 0.1 s until echo_available() turns False, i.e. the cooldown digits appear.
        ok = self.click_echo(time_out=1)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit', cd_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_echo')
        return ok

    def _cast_r(self, tag, ready_timeout, attack=False, click_f=True, confirm=False):
        """R: wait for ready (normal attacks only where the model allows), cast, wait the animation out.

        A press without animation waits again within ready_timeout: a one-frame cooldown OCR miss
        reads as ready while R still has about 1.5 s of cooldown (I38).
        confirm: press only if the next frame still reads ready (I58).
        """
        start = time.time()
        while True:
            ready = self.liberation_available()
            remaining = ready_timeout - (time.time() - start)
            if not ready and remaining > 0:
                if remaining >= 2:
                    self._trace(tag, 'wait: r_ready', timeout=remaining)
                ready = bool(self.task.wait_until(self.liberation_available, time_out=remaining,
                                                  pre_action=self.check_combat,
                                                  post_action=self.click_with_interval if attack else None))
            ready_s = time.time() - start
            if not ready:
                self._trace(tag, 'cast R', ok=False, reason='not_ready', ready_s=ready_s)
                break
            if confirm:
                # I58：冷却数字漏读的那一帧 R 读成就绪；下一帧仍就绪才按，否则回到上面重等
                self.task.next_frame()
                if not self.liberation_available():
                    continue
            ok = self.click_liberation(click_f=click_f) or self._finish_late_liberation(tag)
            self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation', ready_s=ready_s)
            if ok:
                return True
            if time.time() - start >= ready_timeout:
                break
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r')
        return False

    def _finish_late_liberation(self, tag):
        """click_liberation gives the animation 0.4 s to start; finish a later one here.

        R lit again means the press was refused: return at once so _cast_r presses again (I38).
        """
        state = self.task.wait_until(
            lambda: 'animation' if not self.task.in_team()[0] else 'lit' if self.liberation_available() else None,
            time_out=0.6)
        if state != 'animation':
            return False
        self._wait_animation_end(tag)
        self.record_liberation_use()
        return True

    def _wait_animation_end(self, tag):
        """HUD hidden by an animation: keep combat checks quiet, wait for the team HUD, book the freeze."""
        start = time.time()
        self.task.in_liberation = True
        try:
            self._trace(tag, 'wait: hud_back', timeout=7.0)
            back = self.task.wait_until(lambda: self.task.in_team()[0], time_out=7.0, settle_time=0.1,
                                        pre_action=self.check_combat)
        finally:
            self.task.in_liberation = False
        self.add_freeze_duration(start)
        return bool(back)

    # ---------------- 弗洛洛：状态与击破 ----------------
    def _reset_char_state(self):
        self._ring = 0.0  # 最近一次 E 格紫环占比，只供 probe 行使用
        self._outer = 0.0  # 最近一次环外紫色占比，只供 probe 行使用

    def f_break(self, check_f_on_switch=False, force=False):
        # D15：切人时弗洛洛不按 F；处决只在坎特蕾拉 QR↓ 的 Q 后、R 前（I34）
        return False

    def skip_combat_check(self):
        # R 后紧接延奏切人；切人循环每轮先查锁定目标，认不到会阻塞重锁最长 30 s，切人键发不出去。
        # R 后 2 s（扣除演出冻结）内跳过，与上游 Phrolova 相同。
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 2

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        # 启动第 2 行 弗 AAQ[A]；视频 109.7–112.5；Phrolova.f1
        self._action_note_q('f1', 'Jinhsi.f1', self.PROMPT_NATURAL, 0.0)
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f1')

    def perform_f2(self):
        # 启动第 4 行 弗 AA[E]；视频 118.3–120.2；Phrolova.f2
        self._action_note_e('f2', 'Jinhsi.f2', self.PROMPT_NATURAL)
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f2')

    def perform_f3(self):
        # 启动第 6 行 弗 E[EZ]；视频 121.9–123.3；Phrolova.f3
        self._action_heavy('f3', 'Jinhsi.f3')
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f3')

    def perform_f4(self):
        # 启动第 9 行 弗 R↓；视频 131.2–135.5；Phrolova.f4
        self._action_finale('f4', 'Jinhsi.f4')
        self._force_switch_to(self._find_teammate('Jinhsi'), 'f4')

    def perform_s1(self):
        # 循环第 1 行 弗 AQ[A]（变奏入场）；视频 153.1–156.7；Phrolova.s1
        self._action_note_q('s1', 'Jinhsi.s1', self.PROMPT_INTRO, self.S1_ECHO_READY)
        self._force_switch_to(self._find_teammate('Jinhsi'), 's1')

    def perform_s2(self):
        # 循环第 3 行 弗 AA[E]；视频 162.7–164.3；Phrolova.s2
        self._action_note_e('s2', 'Jinhsi.s2', self.PROMPT_NATURAL)
        self._force_switch_to(self._find_teammate('Jinhsi'), 's2')

    def perform_s3(self):
        # 循环第 5 行 弗 E[EZ]；视频 165.9–167.2；Phrolova.s3
        self._action_heavy('s3', 'Jinhsi.s3')
        self._force_switch_to(self._find_teammate('Jinhsi'), 's3')

    def perform_s4(self):
        # 循环第 8 行 弗 R↓；视频 174.4–178.8；Phrolova.s4
        self._action_finale('s4', 'Jinhsi.s4')
        self._force_switch_to(self._find_teammate('Jinhsi'), 's4')

    # ---------------- 弗洛洛：强化提示（E 格紫环，卡弗 36） ----------------
    def _prompt_read(self):
        """Purple share around the E icon centre: (ring band 0.50h–0.80h, outer band 0.85h–1.00h),
        h = box height; (0, 0) off-frame (I16)."""
        box = self.task.get_box_by_name('box_resonance')
        cx, cy = box.x + 0.456 * box.width, box.y + 0.4975 * box.height
        r = 1.00 * box.height
        x0, y0 = max(int(cx - r), 0), max(int(cy - r), 0)
        img = self.task.frame[y0:int(cy + r) + 1, x0:int(cx + r) + 1].astype(np.int16)
        if img.size == 0:
            self._ring, self._outer = 0.0, 0.0
            return 0.0, 0.0
        b, g, rr = img[..., 0], img[..., 1], img[..., 2]
        purple = (b >= 170) & (rr >= 120) & (b - g >= 60) & (rr - g >= 25)
        yy, xx = np.ogrid[y0:y0 + img.shape[0], x0:x0 + img.shape[1]]
        d = np.hypot(xx - cx, yy - cy) / box.height
        self._ring = float(purple[(d >= 0.50) & (d < 0.80)].mean())
        self._outer = float(purple[(d >= 0.85) & (d < 1.00)].mean())
        return self._ring, self._outer

    def _prompt_lit(self):
        # 背景整片泛紫时环带也达标，环外同样泛紫，不算亮（I41）
        ring, outer = self._prompt_read()
        return ring >= self.PROMPT_RING and outer < self.PROMPT_BG

    def _prompt_off(self):
        # 熄灭只看环带：写成 not _prompt_lit() 会把提示亮着时的背景泛紫误判成熄灭
        return self._prompt_read()[0] < self.PROMPT_RING

    def _attack_until_prompt(self, fixed, grace=None):
        # 点普攻到提示亮或满 fixed s，再停点等 grace s（默认 0.75 s）：提示亮后再点会先打出强化普攻
        grace = self.PROMPT_GRACE if grace is None else grace
        start = time.time()
        lit = self.task.wait_until(self._prompt_lit, time_out=fixed, pre_action=self.check_combat,
                                   post_action=self.click_with_interval)
        if not lit and grace > 0:
            lit = self.task.wait_until(self._prompt_lit, time_out=max(0.0, start + fixed + grace - time.time()),
                                       pre_action=self.check_combat)
        return bool(lit)

    def _wait_prompt(self, tag, fixed):
        """Attack until the prompt lights; if it stays dark, attack one more natural-entry round (I31).

        Returns (anchor, lit): anchor is when the prompt lit, or when waiting gave up (I16).
        """
        start = time.time()
        lit = self._attack_until_prompt(fixed)
        attempt = 1
        if not lit:
            # I31：在 boss 顶上出场时，前几下普攻变成下落攻击，落地后提示仍未亮；再按普通入场点一轮
            attempt = 2
            if fixed == self.PROMPT_INTRO:
                lit = self._attack_until_prompt(self.PROMPT_NATURAL)
            else:
                lit = self._attack_until_prompt(self.PROMPT_RETRY, grace=0.0)  # I57
        anchor = time.time()
        self._trace(tag, 'probe prompt', lit=lit, ring=self._ring, outer=self._outer, attempt=attempt,
                    wait_s=anchor - start)
        return anchor, lit

    def _sleep_until(self, deadline):
        remaining = deadline - time.time()
        if remaining > 0:
            self.sleep(remaining)

    def _hold_prompt(self, tag, deadline):
        """Sleep until deadline; until HOLD_MARGIN before it, read the prompt every frame.

        probe hold (I59): dark_s is the longest time since the last lit frame. 071f lit on background
        purple, went dark, and lit for real about 0.3 s later; a real light is expected to stay lit.
        """
        frames, ring_min, dark_s = 0, None, 0.0
        last_lit = time.time()
        while deadline - time.time() > self.HOLD_MARGIN:
            self.task.next_frame()
            now = time.time()
            ring = self._prompt_read()[0]
            frames += 1
            ring_min = ring if ring_min is None else min(ring_min, ring)
            if ring >= self.PROMPT_RING:
                last_lit = now
            else:
                dark_s = max(dark_s, now - last_lit)
        late_s = max(0.0, time.time() - deadline)
        self._trace(tag, 'probe hold', frames=frames, ring_min=ring_min, dark_s=dark_s, late_s=late_s)
        self._sleep_until(deadline)

    # ---------------- 弗洛洛：动作体 ----------------
    def _action_note_q(self, tag, nxt, fixed, echo_ready):
        # A：点到提示亮；Q：A3 出伤后（提示亮 +0.55 s，I52）；[A]：点普攻到紫环熄灭；Q 后满 ECHO_SWITCH 再切人
        anchor, lit = self._wait_prompt(tag, fixed)
        if lit:
            self._hold_prompt(tag, anchor + self.A3_ECHO_DELAY)
        else:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: echo_without_prompt')
        echo = self._cast_echo(tag, ready_timeout=echo_ready)
        start = time.time()
        self.task.click()
        off = self.task.wait_until(self._prompt_off, time_out=self.ENH_A_WAIT,
                                   pre_action=self.check_combat, post_action=self.click_with_interval)
        ended = 'prompt_off' if off else 'timeout'
        self._trace(tag, 'attack', ended=ended if lit else 'no_prompt', attack_s=time.time() - start)
        if lit and not off:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_with_prompt')
        if echo:
            # I45：Q 带空中动作，画面落地后马上切人可能仍算空中切人，今汐在空中出场、首下普攻变下落攻击
            self._sleep_until(start + self.ECHO_SWITCH)
        self._trace(tag, 'exit', next=nxt)

    def _action_note_e(self, tag, nxt, fixed):
        # A×2：点到提示亮；[E]：A3 出伤后（提示亮 +0.75 s）按强化 E，紫环熄灭即完成，最多按 2 次
        anchor, lit = self._wait_prompt(tag, fixed)
        if not lit:
            # I31：提示没亮时按 E 打出普通 E，E 进冷却，第 5 行 E[EZ] 按不出 E
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_star')
            self._trace(tag, 'exit', next=nxt)
            return
        self._hold_prompt(tag, anchor + self.A3_HIT_DELAY)
        start = time.time()
        ok = False
        attempt = 0
        while not ok and attempt < 2:
            attempt += 1
            self.send_resonance_key()
            ok = bool(self.task.wait_until(self._prompt_off, time_out=self.STAR_EACH))
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', skill='star', attempt=attempt,
                    fire_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_with_prompt')
        self._trace(tag, 'exit', next=nxt)

    def _action_heavy(self, tag, nxt):
        # E：普通 E 只按 1 次，提示亮即完成，1.0 s 无提示再按 1 次（卡弗 7）
        lit = False
        attempt = 0
        while not lit and attempt < 2:
            attempt += 1
            self.send_resonance_key()
            lit = bool(self.task.wait_until(self._prompt_lit, time_out=self.E_TRY_WAIT, pre_action=self.check_combat))
        self._trace(tag, 'cast E', ok=lit, reason=None if lit else 'timeout', skill='normal', attempt=attempt)
        if not lit:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_note')
            self._trace(tag, 'exit', next=nxt)
            return
        # [E]：强化 E，出冷却数字（普通 E 的 12 s 冷却）即完成
        start = time.time()
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(), time_out=self.ENH_E_WAIT,
                                       pre_action=self.check_combat,
                                       post_action=lambda: self.send_resonance_key(interval=0.1)))
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'timeout', skill='enhanced', cd_s=time.time() - start)
        if not ok:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: heavy_without_enhanced_e')
        # [Z]：满 6 音符后按住，鼠标图标复原即松手，重击在后台打完（卡弗 15、17）
        self._hold_heavy(tag)
        self._trace(tag, 'exit', next=nxt)

    def _hold_heavy(self, tag):
        start = time.time()
        self._trace(tag, 'wait: mouse_forte', timeout=self.HEAVY_WAIT)
        if not self.task.wait_until(self.is_mouse_forte_full, time_out=self.HEAVY_WAIT, pre_action=self.check_combat):
            self._trace(tag, 'cast heavy', ok=False, reason='not_ready', ready_s=time.time() - start)
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_heavy')
            return False
        held = time.time()
        self.task.mouse_down()
        try:
            self._trace(tag, 'wait: release', timeout=self.HEAVY_WAIT)
            done = self.task.wait_until(lambda: not self.is_mouse_forte_full(), time_out=self.HEAVY_WAIT,
                                        settle_time=0.1, pre_action=self.check_combat)
        finally:
            self.task.mouse_up()
        self._trace(tag, 'cast heavy', ok=bool(done), reason=None if done else 'timeout', held_s=time.time() - held)
        if not done:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_after_hold')
        return bool(done)

    def _action_finale(self, tag, nxt):
        # R：入场后等 R_DELAY（I42、I54），再每 0.1 s 按 R 到 HUD 隐藏，最多 R_WAIT；不按 F（D15）。R 演出结束即延奏
        # 入场后 R 图标约 0.5 s 才淡入变亮，按图标判可用会晚约 0.6 s 才按（I32）；重击在后台打完前按 R 可能无效，所以反复按
        # 不调 check_combat：HUD 隐藏的那一帧会判 target lost 并重新锁定（I28）
        start = time.time()
        self.sleep(self.R_DELAY, check_combat=False)
        self._trace(tag, 'wait: r_cast', timeout=self.R_WAIT)
        cast = bool(self.task.wait_until(lambda: not self.task.in_team()[0], time_out=self.R_WAIT,
                                         post_action=lambda: self.send_liberation_key(interval=0.1)))
        fire_s = time.time() - start
        if cast:
            self._wait_animation_end(tag)
            self.record_liberation_use()
        self._trace(tag, 'cast R', ok=cast, reason=None if cast else 'not_ready', fire_s=fire_s,
                    done_s=time.time() - start)
        if not cast:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r')
        self._trace(tag, 'exit', next=nxt)
