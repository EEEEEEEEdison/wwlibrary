from src.char.BaseChar import BaseChar


class Baizhi(BaseChar):
    INTRO_ATTACK_SEC = 1.2   # 入場後普攻秒數
    USE_RESONANCE = False    # 是否施放共鳴技能：True=施放，False=不施放

    def do_perform(self):
        self._intro_attack()
        if self.USE_RESONANCE:
            self.click_resonance()
        self.click_echo()
        self.switch_next_char()

    def _intro_attack(self):
        if not self.has_intro:
            return
        self.logger.debug(f'Baizhi intro: normal attack {self.INTRO_ATTACK_SEC}s, '
                          f'resonance={self.USE_RESONANCE}')  # 白芷入場：普攻秒數、是否用共鳴技能
        self.continues_normal_attack(
            self.INTRO_ATTACK_SEC,
            click_resonance_if_ready_and_return=self.USE_RESONANCE,
        )