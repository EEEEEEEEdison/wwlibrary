import base64
import ctypes
import threading
import time

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Hsin import Hsin as NativeHsin

# ==================== 物理 F 键监视 ====================
# 跟 Iuno__JingRan__ShoreKeeper/JingRan.py 里那份逐字相同, 说明见 Chisa__Suisui__YangYangSp/YangYangSp.py。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按键按住的时间远大于这个, 不会漏采
F_LOG_DEBOUNCE = 1.0     # 按住不放时别刷日志
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自动战斗开关监视 ====================
# 【玩家手动开关自动战斗, 必须从启动轴重跑】。手动停任务不走 combat_end(), opener_armed 会跨局留在
# False, 而角色对象常被粘性复用、reset_state() 不跑。只有独立线程能观察到 enabled 的 True->False->True。
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳变, 把时刻记到 task._ww_task_restarted_at。每个 task 只启一次。"""
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='tool_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # -1 = 从没按过, 跟 last_opener 的"没跑过"对齐(给 0 的话开局第一次判定恒成立)
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    # 宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='tool_f_watch', daemon=True).start()


# ==================== SendInput 左键(心的两段长按用) ====================
# 结构体照搬 Iuno__JingRan__ShoreKeeper/JingRan.py。
_INPUT_MOUSE = 0
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong),
                ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong),
                ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamH', ctypes.c_ushort), ('wParamL', ctypes.c_ushort)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [('ki', _KEYBDINPUT), ('mi', _MOUSEINPUT), ('hi', _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('u', _INPUTUNION)]


def send_input_left(up):
    """系统级左键按下/抬起。返回是否发出去了(发不出去调用方退回 PostMessage)。"""
    try:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(0, 0, 0, _MOUSEEVENTF_LEFTUP if up else _MOUSEEVENTF_LEFTDOWN, 0, 0)
        return ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) == 1
    except Exception:
        return False


class MacroBroken(Exception):
    """某一步切人没成功 / HUD 长时间不在, 后面的按键会落在错的人身上 —— 整圈放弃, 交回框架。"""


class Hsin(NativeHsin):
    """心。心锁守(心/锁暝/守岸人)里她兼任【整条轴的持宏者】, 三个人的 do_perform 都转到 drive()。

    ================= 轴的出处 =================
    E:/轴视频/萌新也能5R轴，鸣潮有史以来最简单的5R心锁守教学.mp4(B 站剪辑教学, 1080p 手柄操作, 没有键盘浮层;
    有视频定格和回放, 墙钟只能用游戏倒计时)。代码【按角色切人】, 编队怎么排都行。
    10-24 按教学3(E:/轴视频/10月24日 (1).mp4, 穹垠青里 5R, 4K 60fps; 左边文字轴跟实际操作对不上, 以操作和字幕为准)
    改了开局守岸人、心1 直接重击、暗鸟位置、心2 闪避位置; 万阙垂天后启动轴、循环轴都按过白屏时停出重击再 E(v0.2.10)。

    ================= 轴的形状 =================
    启动轴: 守 R(开局先放) -> 3A-E-2A-重击-闪-A到头像光圈出来(协奏真满)-Q -> 变奏心
            (光圈认不出来: 闪后 A到回路满(至少 2.3s)-重击-Q; R 没亮就放到最后: 闪后 A到回路满-重击-Q-R-演完) (见 seg_sk_open)
    循环轴(LOOP_KIND='QY', 教学3): 守(变奏入场) 3A-[回路满就强化重击]-[有处决提示就处决]-E -> 锁暝 点 A1A2-闪避-点 A1A2 -> 心 点 3 下 A(应世心左半不到 0.70 多点一下)
            -> 守 [R 没好就边 A 边等]-Q-R -> 协奏满(第一圈 R 不回协奏: 演完直接 A 到满)
            -> 锁暝(变奏碎霆 +200 妄执 = 满) 点 E(无舍念)-点 A(刻心念, 不按住)-等协奏满-Q(暗鸟) -> 变奏心
    循环轴(LOOP_KIND='4A', 旧版): 守 3A-E -> 锁暝 点 A1-A3、按住出 A4 就松手、冲刺后切(解伞形 4 段打满)
            -> 守 A到回路满-强化重击-Q-R -> 协奏满 -> 锁暝 同上
    之后两条一样:
      心   花图标(应世心满)亮了就按住, 没亮先点普攻到亮(应世心要命中、心在场才给)-按住(步红尘, 清空后 1.86~2.06s 解锁转相;
           按下后才亮 = 普通重击, 立刻松开重按) -> 松手就连按 R(不认图标, 没解锁时按 R 没反应)
           -> 转相 -> 【同奏】切锁暝
      锁暝 (响应同奏: 变奏·锁妄念·同奏, 进念深) [R 在 CD 上就边 A 边等] R -> 演完 -> 马上【同奏】切心
      心   (变奏·照世相 直接进统御众机) A 到第 2 颗雕像翻面(A2 楼阁打中) -> 闪避 -> 普攻到第 7 颗 -> 按住(临寰宇)
           -> 演完 Q -> 认出万阙垂天图标就连按 R(没认出边点 A 攒能量边看; 演出快完时按住普攻、按过 HUD 回来后 0.6s 的白屏时停 -> 重击) -> E -> 协奏满变奏守
    宏在【守岸人变奏入场、HUD 回来】时返回, 下一次框架调的就是她。返回点不落在任何演出里。

    ================= 为什么这么打 =================
    - 【守岸人开局先放 R】: 守 R 冷却 25s, 循环轴里守第二次开 R 正好在开局 R 之后 ~25s(视频 0.46s -> 25.76s)。
      R 放在开局最后(心汐守那样)的话, 循环轴那一下 R 还在冷却, 整圈要等。R 先放, 领域也早一点罩住心。
    - 【锁暝靠同奏串】: 心转相给同奏 -> 锁暝响应同奏的变奏(锁妄念·同奏)直接进念深, 念深才解锁锁暝的 R;
      转相给同奏的前提是心放过变奏·应世相, 所以守交棒时协奏一定要真满(心普通入场 = 后面锁暝 R 不亮);
      锁暝 R 给自己 5s 同奏 -> 带同奏切走 = 心变奏·照世相直接进统御众机(+300 照世心), 锁暝放延奏(凄雨瘴雷 + 增伤)。
      所以锁暝 R 一演完就切, 同奏只有 5 秒。【心要共鸣模态·同奏】(电磁模态没有这两样)。
    - 【暗鸟放在锁b 刻心念之后】(用户的锁暝带暗鸟): R 之后放卡手、还吃锁暝 R 给的 5s 同奏; 教学3 作者也带暗鸟,
      放在刻心念收完、变奏心之前。启动轴那次锁R 不放。
    - 【QY 循环: 锁暝 A1A2 闪 A1A2 + 心 3A】一圈被守 R 25s CD 卡住(教学3 心 3A 切回来守 R 还差 1.2s)。旧版拿锁暝 4A +
      守 A到回路满-强化重击 填这段; 教学3 拿锁暝两组 A1A2(攒妄执最快的两段, 闪避重置连段)+ 心 3A 填,
      心的那几下把应世心垫一截, 心1 变奏进来不满就先点 A 补到满再按住出步红尘。守的强化重击挪到第一截 3A 后面
      (开局闪后 2A 给守留了半条回路)。
    - 【循环轴锁暝 4 下普攻 = 攒妄执】(4A 版): 妄执 800 满了 E 才是无舍念。R 给 200, 4 下解伞形攒到 ~600,
      切走后守岸人开 R 满协奏 -> 锁暝变奏碎霆再 +200 = 800, 一进场 E 就是无舍念, 接刻心念(1551% + 回 40 协奏)。
      第 4 段要在第 3 段之后【按住】普攻才出(第 2 段之后按住是旋雷破), 连点打不出完整 4 段。妄执条读数被锁暝自己的
      特效污染(实机 0.1~0.9 乱跳), 不拿来判切人, 按段的时间点走(见 SO_4A_TAP_UNTIL / SO_4A_HOLD_UNTIL / SO_4A_SWITCH_AT)。
      妄执只在锁暝在场时到账, A4 在入场后 ~2.5s 和 ~3.0s 各进一截, 切早了 A4 白打、锁b 回来要补(教学2 在场 3.1s)。
    - 【刻心念点一下就行, 别按住】: 按住那段转圈是时停(倒计时停), 按多久就多花多久实时, 协奏 +40 在收尾那下才给。
      按住到协奏满 = 把转圈拖满(~2s); 教学只转 ~0.5s。刻心念期间不能切人, 收招协奏满就变奏心。
    - 【心变身后 A1A2-闪-A】: 统御众机里照世心(8 颗雕像)只被普攻吃: A1 1 颗, 之后每段楼阁 2 颗(A2 #2#3,
      A3 #4#5, A4 #6#7)。A2 楼阁落下(第 2 颗)就闪避, 闪避不打断已经出手的楼阁, 收招跟 A2 叠在一起;
      A2 打完再闪(v0.2.3)收招单独占 ~0.6s, A2 出手前就闪(v0.2.4)会把 A2 吞掉。
      剩最后 1 颗时按住: 按住只接着打已经出手的那段, 第 8 颗翻面临寰宇马上出(雕像还剩好几颗时按住 = 链打到头干等)。

    ================= 心的判据(2026-10-05 拿两份录像在 2K/1080p 上各验过) =================
    - 应世心条: 回路条中间徽记两边的紫色格子, 左半 0~50、右半 50~100。变奏入场给 60(左半满)。
      两份录像里按住重击的那一刻右半都是 0.68~0.72, 按下去 0.3s 内整条清空 = 步红尘出手 ——
      条读到满之前就按也打得出步红尘(普通重击的伤害把最后那截补满, 按住的键接着出步红尘)。
      判据用紫色占比, 2560 和缩到 1920 的同一帧读数一样(差 <0.04)。
    - R 图标: 【应世相】转相没解锁时白色 0, 解锁后 ~0.17(box_liberation 的白色占比, 就是 liberation_available);
      hsin_lib1 模板在应世相全程都认得(0.9+)。
      【照世相里 R 一直是亮的】(借相·应世, CD 1.5s), 所以万阙垂天解锁【只能认 hsin_lib2 模板】
      (临寰宇之后才出现, 0.95+, 之前一帧都不中) —— 拿"R 亮了"去按会放出借相, 把心切回应世相。
    - 【应世心满 = hsin_h1(重击位的花图标)】: 满了条变成粉红高柱, 紫色判据读成 0.4 上下。用户实机心变奏入场
      应世心就是满的(作者的从没满过), 录屏里满的那几秒 0.96~0.99、步红尘出手当帧 0。
    - 临寰宇出手 = 队伍 HUD 消失(~2.0s)。框架的 mouse_forte / hsin_h2 在录像里一帧都没认出来, 不用。
    - 照世心雕像计数(xn_statue_count)照抄心雷穗 v1.1.0: 翻面那一刻雕像上半身先变亮白, 0.3~0.4s 后中间才出红菱形。

    ================= 锁暝的判据 =================
    - 妄执条 = 回路条那一排点(跟心的应世心条同一个框), 攒上的点是粉紫(色相 150~178、饱和度 95~120),
      没攒的是灰蓝(色相 ~120、饱和度 60~75)。【只进日志】: 10-24 实机录屏锁暝出招时整条被特效染成粉紫, 读数不能用。
    - 锁暝两次 R 刚好隔一个 25s CD, 循环里切进来常常还差零点几秒: R 亮没亮每帧读(so_wait_r_lit)。
    - 妄执满 = 框架的 suoming_forte_e 模板(E 位换成锁妄念/无舍念), 框架原版锁暝也靠它。

    ================= 改这个文件之前先读 =================
    - 整份是心汐守 v1.1.0 的 Hsin.py 删掉今汐、加上锁暝段改出来的; 引擎那一半(macro_* / quick_switch /
      press_key_until_cd / fire_r / switch_to_sk ...)、守岸人 sk_*、心 xn_* 都是那边实机标定过的。
    - 【自定义 __init__ 里跟内置版不同的字段会被打回内置值】, 要保住就在 reset_state() 里重申。
    - 普攻一律走 tap()(按住 A_TAP 秒): task.click() 只按 10ms, 打不出来。
    - 长按期间不调 click()/mouse_down()/send_key() —— 它们先投 WM_ACTIVATE, 会把按住打断。
    """

    # ==================== 全局节奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10
    A_TAP = 0.06                 # 普攻按住这么久才算一下; task.click() 的 10ms 会被吞

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True
    # 宏表里的切人格: 在这一格自己的 gap 里盯到场(正常 0.1s 就到, 剩下的照等, 时序不变);
    # 没到就每 SWITCH_REPRESS 补按, 最多再多等 SWITCH_EXTRA(游戏的换人 CD 约 1 秒)
    SWITCH_EXTRA = 1.50
    SWITCH_REPRESS = 0.05
    SWITCH_CONFIRM = 2

    # ---- 大招 / 演出 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_ANIM_TIME_OUT = 8.0
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在场的上限(防假成功)
    # 【演出中途 HUD 会闪一两帧】(录像: 心转相 0.55s / 3.6s 处、守R 1.9s 处各闪一次)。等"HUD 回来"时
    # 要连读到这么多帧才算, 而且演出开始后不到 min_gone 秒的"回来"一律不认(见 wait_hud_back)
    HUD_BACK_CONFIRM = 2

    # ---- 杂项 ----
    CON_SAMPLE_MAX = 24
    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40      # 刚切进来多久没见过技能亮就当它在 CD 上

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0

    # ==================== 循环轴版本 ====================
    # 'QY' = 教学3(穹垠青里): 守 3A-[重击]-E -> 锁暝 A2-闪-A2 -> 心 3A -> 守 R(刚转好) -> 锁b ...
    #        一圈被守 R 25s CD 卡住, 心那 3A 填等 R 的空、攒应世心, 心1 进场就能直接重击。
    # '4A' = 旧版(10-24 实机 8 次调过): 守 3A-E -> 锁暝 4A -> 守 A到回路满-强化重击-Q-R -> 锁b ...
    LOOP_KIND = 'QY'

    # ==================== 保底 ====================
    # 原则(秧千穗那次定下的): 只花时间的保底默认开(切人重试 / 等 HUD / 判据没成立就再按【那一个本该出去的键】);
    # 会改状态的只在判据明确说"这一下没出去"时才补, 不凭猜测多按
    SWITCH_RETRIES = 2           # 切人超时后先等 HUD 回来再切, 最多再试这么多次(被击飞/硬直时游戏不放人)
    SWITCH_RETRY_TIME_OUT = 3.00
    HUD_LOST_ABORT = 8.00        # 队伍 HUD 连续这么久没见过 = 关卡结束/过场/窗口没了, 整圈放弃(最长的演出 4.3s)
    DRIVE_HUD_CAP = 1.50         # 框架调进来时 HUD 这么久都不在就什么都不做(结算画面上框架还会一直调进来)
    R_TRIES = 3                  # R 亮着但没放出去(被吞/被打断)就再按, 最多这么多次
    R_BLIND_EVERY = 3            # R 读成暗时每这么多轮攒能量盲按一次(防读数不准)
    R_BLIND_WINDOW = 0.40
    R_BUILD_SLICE = 0.60         # 攒能量每轮的连点时长
    ROWS_HUD_READ_EVERY = 2.0    # 宏表回放时至少这么久读一次 HUD(喂看门狗), 只在格子空档里读, 不推后下一格
    # 【协奏真满看头像光圈】协奏满(切人能变奏)那一帧, 另外两个人的头像外面套上一圈细白环往外扩。
    # 框架的协奏环读数快满就报 1.00(开局守比真满早 1.8s 就读到), 光圈跟真满同一帧出来。
    # 只看另外两格: 刚切进来的人自己那格还残留一圈。读法: 头像中心极坐标展开, 只取上半圈(避开数字牌/名字条/属性图标),
    # 半径 80~118(4K)里找白色细脊, 统计落在同一半径上的角度占比。
    # 10-24 录屏 17.55.06 离线(2K + 缩到 1080): 开局守真满那帧两格都 ~0.9, 之前 <= 0.13; 单格误读最高 0.34;
    # 亮背景会把一格压到 0.1~0.3, 所以两格合起来判。1080 下心万阙垂天后那次只有 0.11/0.12(认不出就走读数老路)。
    GLOW_BOTH = 0.15             # 两格都 >= 这个, 而且有一格 >= GLOW_ONE
    GLOW_ONE = 0.35
    GLOW_SOLO = 0.60             # 一格就够
    GLOW_CONFIRM = 2

    # ==================== 守岸人 ====================
    # 启动段: R -> 演完 -> 3A -> E -> 2A -> 重击1 -> 闪避 -> A 到回路满(闪后至少 SHORE_OPEN_MIN_A) -> 重击2 -> Q -> 交棒。
    # 【心必须变奏入场】心只有放过变奏·应世相, 下一次转相才给同奏; 守协奏差一点 = 心普通入场 -> 转相没同奏 ->
    # 锁暝普通入场停在念起 -> R 一直不亮(10-24 17:35~17:37 四局都是这样, 等 R 4s + 攒 5s 都没亮)。
    # 守交棒前的协奏读数不可信: 环快满时 get_current_con 已经判闭合 = 1.00, 那四局闪后 2A 就读到 1.00 切了, 其实不满。
    # 真满看头像光圈(GLOW_*): 闪后 A 到光圈出来就 Q 交棒(17:51 录屏光圈在闪后 1.7s 出来, 老路要到 3.5s 才切)。
    # 光圈认不出来才走老路, 协奏靠动作量保证: A 到回路满(闪后至少 SHORE_OPEN_MIN_A) -> 重击2 -> Q。
    # 教学3 闪后只 2A + 声骸就变奏(重击1 -> 切人 1.9s), 字幕说要蹭到闪(闪避反击协奏 4.4x2)或者带精三奇幻变奏;
    # 我们往前闪蹭不到、奇幻变奏精一 -> 默认关(SHORE_OPEN_FAST)。
    # R 先放是为了 25s 冷却: 循环轴守第二次开 R 离开局正好 ~25s(视频倒计时 0.46 -> 25.76)。开局只放 R(不先 Q, 同教学3), 声骸挪到交棒前。
    # 开局 R 没亮(能量没满, 比如大世界)就照老样子放到最后: A 到回路满 -> 重击2 -> Q -> [协奏不到 0.70 补一发强化重击] -> R。
    # 闪避是往前闪(按住 W + 右键): 守岸人打中才回回路, 往后闪 A 不到怪
    SHORE_OPEN_FAST = False
    SHORE_OPEN_TAIL_A = 0.85     # FAST: 闪避后普攻的时长(两段; 教学3 闪避 -> 切人 1.45s 游戏时间, 含声骸)
    # 闪避后至少 A 这么久才按重击2。实机(v0.1.8, 闪后 A 到回路满 + 重击2): A 1.6~1.7s 的六局四局心没变奏(锁暝 R 不亮),
    # A 2.3~2.7s 的十一局十局正常
    SHORE_OPEN_MIN_A = 2.30
    SHORE_A3_WINDOW = 1.38       # 第一组三段普攻。A3 被 E 掐掉就加, E 前有空转/多出 A4 就减
    SHORE_E_TO_HEAVY = 1.43      # 从按下 E 起算的第一发重击时刻 —— 落在 A3 抬手, 把 A3 那一两格能量卡到下一次回路
    SHORE_HEAVY_HOLD = 0.85      # 读不到鼠标指示时的兜底按住时长
    SHORE_HEAVY2_HOLD = 0.45
    SHORE_HEAVY_CAP = 1.60       # 长按硬上限。指示暗了 = 长按已被识别, 立刻松手
    SHORE_DODGE_TO_A = 0.25      # 闪避 -> 接普攻, 要跨过闪避的派生帧
    SHORE_FORTE_WAIT_CAP = 5.0   # 边打边等回路满的上限, 超时也照按重击
    SHORE_HEAVY_TO_QR = 0.30     # 重击松手 -> Q
    SHORE_LIB_MIN_CON = 0.70     # 放 R 前协奏至少到这个值, 不够补一发强化重击(R 自己给 20)
    SHORE_LIB_CON_SETTLE = 0.60
    SHORE_LIB_RESCUE_CAP = 3.0
    # 两发重击都只在回路满时按: 不满按出来是普通重击(化蝶), 回路不清还白飞一下(日月守那边读不到指示会兜底按满,
    # 这里不兜: 开局 A 打空/怪还没站稳时宁可不按)。重击1 到点没满就再 A 这么久
    SHORE_HEAVY1_WAIT = 1.50
    SK_OPEN_R_CAP = 5.00         # 启动段 R 的保底上限: 不亮就攒能量(普攻 / 回路满打强化重击)、亮了没出就重按
    WD_W_LEAD = 0.05             # 往前闪: 按住 W -> 右键 -> 松 W
    WD_DODGE_HOLD = 0.07
    WD_W_TAIL = 0.05
    SK_FORTE_CONFIRM = 2         # 回路满连着几帧才算(单帧会被特效骗)
    SK_E_CAP = 0.60              # E 按到进 CD 的上限(被打断时那一下会被吞)
    SK_Q_PRESSES = 2             # R 演完之后连发 Q 的次数 / 窗口
    SK_Q_WINDOW = 0.15
    SK_R_HOLD = 0.07
    SK_R_WATCH = 1.00            # 按 R 之后盯 HUD 消失的时长, 没消失就当没放出去
    SK_R_RESCUE = 1.80           # 补按 R 的窗口(要盖过重击/普攻的收招)
    SK_R_ANIM_MIN = 2.40         # 守 R 演出藏 HUD ~3.0s, 第 1.9s 处 HUD 会闪一下
    SK_R_ANIM_CAP = 6.00
    # 【守 R 演出白闪一结束就切锁暝】视频: 白闪那一帧之后直接是锁暝变奏, 倒计时只走 0.06s。
    # 10-24 第三次实机: 白闪后守岸人还站着 ~1s(HUD 不在, 倒计时在走 ~0.5s), HUD 回来才切。
    # R 之前协奏已满才这么切(R 不吃协奏); 白闪 ≈ HUD 消失后 1.9s, 从 SK_R_SWITCH_FROM 起连发切人键(演出里按的被丢掉)
    SK_R_SWITCH_FROM = 1.70
    # 10-24 第四次实机 R 前读 1.0 一次都没成立(R 演完读都是 1.00), 放宽到 0.90 并在日志里记读数
    SK_R_EARLY_CON = 0.90
    # 交棒(变奏心)前协奏要真满。读一下(SK_CON_READ)不满就直接补: E > 强化重击(R 之后回路是满的) > 普攻。
    # 不再边 A 边干等 —— 实机 R 后读数 0.95 一动不动, 等 1s 什么都没变
    SK_CON_READ = 0.25
    # 【第一个循环轴守b: R 演完不读, 直接 A 到能变奏再切】(用户 10-25) 奇幻变奏放 R 回协奏有 25s 冷却, 启动轴开局 R 刚吃过,
    # L1 这发 R 不回协奏, 演完肯定不满。10-24 23:14~23:59 八次 L1: 演完干读 0.26~0.29s 都没满(只有 23:52 一次光圈满),
    # 之后补协奏 A x5 + 强化重击 1.45s 才满。干读那一下就是卡顿。L2 起武器好了, 演完读 0.07s 光圈就满, 照旧
    SK_LB_L1_DIRECT_A = True
    SK_CON_RESCUE_CAP = 4.0
    SK_E_CD = 16.0               # 守岸人 E 冷却。补协奏时 E 好没好按上次放 E 的时间算 —— 实机 11:22 技能栏 OCR 读漏,
                                 # 把 11.6s CD 的 E 当成好了, 白按 0.9s
    SK_CON_ENOUGH = 1.0          # 0.99 是环没闭合的哨兵值, 要真满
    SK_CON_FULL_CONFIRM = 3
    SK_CON_POLL = 0.03
    SK_E_DERIVE = 0.67           # E-地面 派生 40F
    # 循环段分两截, 中间夹锁暝 4 下普攻:
    #   第一截(心变奏进来, HUD 回来之后) 3A -> E -> 切锁暝。E 给 ~2 格回路 + 20 协奏, 回路留到第二截一起清
    #   第二截(锁暝切回来) A 到回路满 -> 强化重击 -> Q -> R -> 协奏满变奏锁暝。视频是"3A 重击", 用户的守回路
    #   不一定刚好 3A 满, 所以照心汐守的 sk_clear: 满了才重击(不满按出来是化蝶)
    SK_LA_E_CAP = 0.80           # 第一截 E 按到进 CD 的上限
    # 【处决放在循环轴守a 3A + 强化重击之后、E 之前】(用户 10-24 定的, 照教学3 顺序)。
    # v0.2.7~v0.2.10 放在守变奏入场、3A 之前: 提示要等 0.36~0.38s(这段计时在走), 处决那圈守a 多 0.4~0.7s(22:26 局 L1/L3)。
    # 教学3 是 3A(0.9s)-强化重击-处决-E-切: 打到处决时提示早亮了, 谐度破坏自带时停(倒计时 93.0~94.1 不走), 守a 一共 1.45s;
    # 3A 里才谐度满的也接得上。强化重击-1 第 23F 出伤、之后可脱手(强化重击-2 自己生成) -> 按下 SK_BREAK_AFTER_HEAVY 后才按 F,
    # 谐度破坏优先级最高, 早按会把这一刀打断。
    # 判据照抄嘉露莫 v1.1.0(2K/1080 实机过): 只在怪身上的 F 提示(屏幕中间 f_break >= 0.90, 不是拾取 F)在的时候按 F。
    # 入场镜头会把中间提示甩出框(嘉露莫 10-16: 到场 +1.05~1.45s 才回来); 3A 打完已经过了 1.4s+, 一般就读 BREAK_READS 帧。
    # 外圈满着(或者切人前心身上读到过提示)才盯到 HUD 回来后 SK_BREAK_UNTIL —— 3A 之后这个点多半已经过了。
    # 不走框架的 task.f_break(): 那个会连点左键、至少卡 0.5s
    SK_BREAK = True
    SK_BREAK_UNTIL = 1.20
    SK_BREAK_AFTER_HEAVY = 0.40
    BREAK_READS = 3
    BREAK_CENTER_MIN = 0.90
    BREAK_RING_MIN = 0.92        # 框架 check_f_break 同一个阈值
    BREAK_SEEN_FRESH = 5.00      # 切守之前心身上读到的提示, 到守 HUD 回来这么久之内算数(守变奏入场藏 HUD 3.2~3.3s)
    BREAK_RESEND = 0.30          # 按完这么久提示还在 = 被吞了(硬直/上一个动作没收), 再按
    BREAK_PRESSES = 5
    BREAK_GONE_FRAMES = 3        # 提示单帧会掉到 0.85~0.88(特效闪), 连这么多帧不见才算处决起手了
    BREAK_ANIM = 1.55            # 守岸人谐度破坏派生 90F(1.50s)
    BREAK_ROUNDS = 2             # 等完动画提示还在 = 那一下没处决上, 再来一轮
    SK_L_FULL_CAP = 4.00         # 第二截 A 到回路满的上限(从空攒满实机 2.3~3.2s, 这里第一截已经攒了 E 的 2 格)
    SK_L_Q_WINDOW = 0.25         # 重击之后连发 Q 的窗口(两下)
    # QY 第二截: 心 3A 切回来时守 R 还差 ~1.2s CD(教学3), 边 A 边每帧看 R, 亮了马上 Q-R; 撞上限交给 ensure_r 攒
    SK_QY_R_WAIT_CAP = 4.00
    SK_R_ENSURE_CAP = 6.00       # 循环段 R 的保底上限(R 不亮就攒能量)
    HEAVY_MIN_HOLD = 0.10        # 长按之后先按这么久再盯指示(按下那一瞬指示还没变)
    SK_HEAVY_HOLD = 0.85         # 读不到鼠标指示时的兜底按住时长
    SK_HEAVY_CAP = 1.60          # 长按硬上限。指示暗了 = 长按已被识别, 立刻松手
    HEAVY_RETRIES = 1            # 指示一直亮(没打出去)就再按, 最多这么多次
    # 切给守岸人: 带演出的强化变奏入场藏 HUD ~3.2s
    SK_INTRO_ANIM_CAP = 6.0
    SK_INTRO_NOANIM = 0.35
    SK_SWITCH_ANIM_HINT = 1.00   # quick_switch 超过这么久才判到到场 = 强化变奏的演出已经在里面演完
    SK_TO_TIME_OUT = 4.00        # 心 -> 守岸人: 万阙垂天收招没完游戏不放人

    # ==================== 心 ====================
    # ---- 应世心条(4K 坐标, hcenter): 回路条中间徽记左右两半的紫色格子 ----
    # 读数 = 有紫色的列占比(HSV 色相 125~160、饱和度>=70、亮度>=90)。第一版用 RGB 阈值, 实机 11:24 那局
    # 背景一暗紫格子跟着暗, 左半满格读成 0.58、右半 0.53 读成 0.31, "到线"一直不成立; HSV 两种场景左半都是 0.99
    XN_GAUGE_L = (1627, 1999, 1837, 2011)
    XN_GAUGE_R = (1965, 1999, 2175, 2011)
    XN_GAUGE_VALID = 0.50        # 左半 >= 这个才算"在应世相、读数可信"(变奏入场之后左半就是满的)
    XN_YING_READY = 0.70         # 右半到这么多就按重击(作者宏/手打按下去那一刻都是 0.73, 0.3s 内出步红尘)
    XN_YING_LATE = 0.58          # 到了 XN1_LATE_AT 右半 >= 这个也按 —— 差的那截普通重击能补上
    XN_CONSUMED = 0.15           # 按住之后左半掉到这个以下 = 整条清空 = 步红尘出手
    # 【应世心满 = 重击位出现 hsin_h1(花图标)】。满的时候条变成粉红高柱(紫色判据读成 0.4 上下, 不能用),
    # 实机录屏满的那几秒模板 0.96~0.99、步红尘一出手当帧 0; 作者两份录像从没打满过, 一帧都不中。2K/1080p 一样
    XN_FULL_THRESHOLD = 0.70
    # 心两段长按走 SendInput(游戏在前台时): PostMessage 的按下沿落在普攻收招里会被丢掉, 后面一直按着也不算数
    XN_HOLD_SENDINPUT = True

    # ---- 第一段(变奏·应世相): A -> A -> 重击 -> Q -> 转相 ----
    # 【上场就满(6 链二链: 进战斗 +100 应世心, 只有启动轴那一次)】可以不打那两下 A 直接按住出步红尘(省 ~1.3s),
    # 开关 XN1_SKIP_A_WHEN_FULL。心汐守那边关着(心第一次上场少了 A3/A4 的协奏, 万阙垂天演完协奏差一截);
    # 心锁守心1 是同奏切锁暝、不吃协奏, 心2 开大前/切守前各有一道补协奏 —— 开。教学3 开局心进场 ~0.4s 就出步红尘,
    # 进场 -> 转相 2.85s, 我们 A 两下再按要 4.1s。
    # 打开时从切人键起 XN1_FULL_FROM 开始看花图标, 到 XN1_A1_AT 之前看到就在 XN1_FULL_HOLD_AT 按住
    XN1_SKIP_A_WHEN_FULL = True
    XN1_FULL_FROM = 0.20
    XN1_FULL_HOLD_AT = 0.50
    # 【上场条差一点: 普攻补到花图标亮再按住】只有普攻/E/变奏技能命中才给应世心, 普通重击不给(nanoka 原文)。
    # 原来右半 >= 0.85 就按住: 18:29 录屏三圈进场右半 0.84 -> 按住出的是普通重击, 条靠变奏剩下的伤害 1.5s 后才满,
    # 满之前按下的那次按住不会变成步红尘, 按满 1.8s 松手再补 2A 重按, 每圈多 ~1.9s。
    # 现在只认花图标(连 2 帧、场上是心): 没亮就从切人键 XN1_ENTRY_TAP_FROM 起点普攻(变奏入场那一刀 ~0.66s 收完), 亮了就按住;
    # 条一直读不出来到第一下 A + XN1_BLIND_AT 照按, 一直不亮到 + XN1_FILL_CAP 照按
    XN1_ENTRY_TAP_FROM = 0.70
    # 没满就照宏表: 切人键后 1.05s / 2.13s 两下 A(接变奏入场的普攻第 3/4 段)、3.21s 按住。
    # 第一版按手打估计提前到 0.70 / 1.70, 实机 11:24 那局第一下之后条一秒多一格没涨(多半落在入场动作里了),
    # 上场 4.2s 才到线(作者 2.6~3.1s) —— 改回宏表
    XN1_A1_AT = 1.05             # 从按切人键起算
    XN1_A_HOLD = 0.08
    # 【从第一下 A 起连续点普攻, 每帧读应世心条, 到线就按住】原来照宏表 A1 -> 隔 1.08s -> A2 -> 再等 ~1.5s 才补 A:
    # 10-08 11:02 循环轴心上场应世心不满, 录屏 160.6 一下 A 之后站了 1.2s 才有下一下(用户: A 得很卡顿)。
    # 点得比出招快没关系(动作里的点击被丢掉), 连段也接得上(补 A 间隔 0.45 断过)。至少打满 XN1_MIN_A 下(启动轴靠这两下攒协奏)。
    # 下面三个时刻都从第一下 A 起算, 跟原来"第二下 A + 1.08s / + 3.0s"对齐
    XN1_TAP_EVERY = 0.25
    XN1_MIN_A = 2
    XN1_LATE_AT = 2.15           # 到这一刻还没到 READY: 右半 >= LATE 也按(差的那截普通重击能补上)
    XN1_BLIND_AT = 2.15          # 到这一刻条一次都没读出来: 不猜, 照按
    XN1_FILL_CAP = 4.00          # 条一直不够的上限, 到了照按
    XN1_FILL_EVERY = 0.40        # 补 A 的间隔(要接得上连段, 0.45 那版断过)
    XN1_GAUGE_CONFIRM = 2        # 连读这么多帧到线才算(特效扫过会闪)
    # 【预输入重击】变奏入场之后普攻接的是第 3/4 段, 第 4 段是往前冲的那一下: 冲出去的时候就按住,
    # 冲完立刻接步红尘(按住要 ~0.3s 才认成重击, 等冲完再按就白站这 0.3s)。按早了(第 3 段里)会把第 4 段吞掉,
    # 少一段协奏。视频: 循环轴切人后 ~1.5s 冲、1.6~1.7s 出步红尘; 开局那次 ~1.9s 冲。
    # 心汐守的"打满两下且到线就按"大约在切人后 1.35~1.6s, 这里再加一道: 切人键后 XN1_HOLD_NOT_BEFORE 之前不按
    XN1_HOLD_NOT_BEFORE = 1.50
    XN1_HOLD = 1.80              # 按住时长(宏表)。步红尘免疫打断, 演出里一直按着没有坏处
    XN1_RETRIES = 2              # 按满 XN1_HOLD 条都没清空(= 出的是普通重击) -> 补两下 A 再按, 最多这么多次
    XN1_RETRY_A = 2
    # 【按住期间条才满 = 这一下多半已经是普通重击, 满了也不出步红尘】10-24 第三次实机 L3: 怪死换波打空, 0.66 就按住,
    # 按下后 0.89s 花图标亮、一直到 1.8s 松手都没出, 又补 2A 重按才出(多花 ~2.8s)。正常按住到出手 0.34~0.81s。
    # 现在: 按下够 XN1_STALE_MIN 且花图标亮了 XN1_STALE_FULL 还没清空 -> 立刻松开重按(不补 A)
    # 按下那一帧花图标没亮、按住期间才亮(连 2 帧) -> 不等, 立刻松开重按(18:29 录屏亮了 0.4s 才撞到 1.8s 松手)
    XN1_STALE_MIN = 0.95
    XN1_STALE_FULL = 0.45
    XN1_STALE_MAX = 1
    # 转相(R1)解锁 = 应世心条清空(步红尘出手) + 1.86~2.06s(10-24 实机)。
    # 【不认转相图标, 步红尘松手就连按 R 到演出出来】(用户 10-24 定的): 应世相里转相没解锁时按 R 什么都不发生,
    # 连按能踩上解锁那一帧; 认图标那条路偶尔读漏(没看到清空 -> 等到按住后 2.6~3.0s 才按)。
    # 窗口从松手(按住 XN1_HOLD 后)起算: 松手时离清空 1.1~1.5s, 还差 0.4~0.9s 解锁
    XN1_R1_SPAM = 2.50
    # 补救(xn_r1_rescue)里还在用: 清空后等解锁 / 连读几帧亮才按
    XN1_R1_UNLOCK = 2.06
    XN1_R1_MARGIN = 0.08
    XN1_R1_READS = 2
    XN_R_WINDOW = 1.50           # R 连按到 HUD 消失的窗口
    # ---- QY 循环插段(锁暝 A2闪A2 切过来, 普通入场): 点 3 下 A -> 第 3 下抬手切守 ----
    # 教学3: 进场 +0.25 第一下进条、+1.2 第三下、+1.95 切守(在场 1.9s, 应世心左半 0.3 -> 0.72)
    XN_MID_A1_AT = 0.15          # 从切人键起
    XN_MID_TAP_EVERY = 0.30
    XN_MID_TAP_UNTIL = 1.30      # 从第一下 A 起点到这一刻
    # 1.90 -> 1.55: 教学3 第三下进条后还站 0.75s 是在等守 R 转好; 我们守b 进场 R 一直是亮的(10-24 全天 30 圈
    # 等R亮 0.12~0.18s, 就是连读 2 帧的时间), 等的那段白站。点完最后一下(切人键 +1.45)再给 0.1s 落地就切
    XN_MID_SWITCH_AT = 1.55      # 从切人键起这一刻切守
    # 【3A 后应世心左半不到 XN_MID_YING_MIN 就多点一下 A 再切】(用户 10-24 定的)。心1 变奏进场 = 插段剩的 + 60 点,
    # 22:26 局插段剩 0.72~0.74 心1 补 1 下 A(0.84~0.91s), 剩 0.63~0.64 补 4 下(1.65~1.70s)。
    # 切人键 +1.55 时 3A 的进条已经到账(录屏: A3 进条 +1.23~1.27, 之后平着), 读 XN_MID_READS 帧取最大(特效会压一帧)。
    # 多点那一下: 点完等到条比点之前涨了 XN_MID_EXTRA_STEP(至少过 XN_MID_EXTRA_MIN, 别把 A3 尾巴的进条当成这一下)
    # 或到线就切, 最多 XN_MID_EXTRA_CAP。读不到条(HUD 不在/场上不是心)就照原样切
    XN_MID_YING_MIN = 0.70
    XN_MID_READS = 3
    XN_MID_EXTRA_STEP = 0.04
    XN_MID_EXTRA_MIN = 0.20
    XN_MID_EXTRA_CAP = 0.70
    XN1_ECHO = False             # 转相前不放声骸: 视频心的声骸留给万阙垂天前(两次大招只隔 ~7s, 声骸冷却转不过来)
    # 【转相一定要放出来】(心汐守用户 10-05 定的): 锁暝响应同奏进念深(才有 R)、心第二段的变奏·照世相全靠它。
    # 第一次没出就补到出为止: 转相亮 -> 按; 应世心满 -> 再按住出步红尘、等解锁; 都不是 -> 普攻攒应世心
    XN1_R1_RESCUE_CAP = 8.00
    XN1_R1_RESCUE_A = 0.80       # 攒应世心一轮的普攻时长
    XN1_R1_LOST_ROUNDS = 3       # 连着这么多轮既看不到转相图标也读不到应世心条 = 已经不在应世相(转相其实出了)
    XN_R_ANIM_MIN = 3.90         # 转相/万阙垂天演出藏 HUD 4.3s, 中途 0.55s / 3.6s 处 HUD 会闪一帧
    XN_R_ANIM_CAP = 7.00

    # ---- 第二段(变奏·照世相, 直接进统御众机 + 300照世心): 2A -> 闪 -> 3A -> 按住到临寰宇 -> Q -> 万阙垂天 ----
    # 视频: 切人后 2.45s 第一下 A(变奏入场 + 楼阁升起那段打不了), 第 1 颗翻完闪避, 第 8 颗翻面时临寰宇已经出手。
    # 心汐守那版是 4A 再按住(A3/A4 吃雕像慢), 从统御众机到临寰宇 5.9s, 视频 ~2.4s 快一大截
    XN2_LEAD = 2.50
    # 每段普攻的楼阁一段翻 2 颗(A1 1 颗, A2 #2#3, A3 #4#5, A4 #6#7), 闪避不打断已经出手的楼阁。
    # 【闪避在 A2 楼阁落下那一下(第 2 颗), 不早不晚】
    # v0.2.3 数到 3 才闪(A2 打完): 闪避收招单独占 0.66s, #3->#4 0.78s(教学3 0.15s), #1 -> #7 2.42s(教学 2.04s)。
    # v0.2.4 读到第 1 颗 0.05s 后就闪: 18:57 录屏 A2 还没出手就被闪避吞了, 闪后从 A2 重打, #1->#2 0.75s(平时 0.46~0.57),
    # #1 -> #7 2.55s 反而更慢。教学3 #1->#2 0.50s 跟不闪一样快, #2->#3 0.36s, #3->#4 0.15s = 闪在 A2 楼阁落下前后。
    # 现在: 读到第 1 颗后接着点 A, 读到第 2 颗(A2 楼阁打中)或第 1 颗后 XN2_DODGE_AFTER 就闪
    XN2_DODGE_COUNT = 2
    XN2_DODGE_AFTER = 0.45       # 18:44 四圈 #1->#2 0.46~0.57s, 第 2 颗读不到也在它前后闪(A2 已经出手)
    XN2_DODGE_MIN = 1.00         # 从第一下 A 起这么久之前不认第 1 颗(入场闪光会让几颗雕像一起"亮", 防误读)
    # 18:44 四圈第 1 颗都在第一下 A 后 1.06~1.11s 翻(前 ~0.6s 的 A 落在变奏入场里被吞)。读不到第 1 颗就到这一刻闪
    # (正常这时候 A2 刚好落下), 别拉太晚: 晚到 A2 打完就回到 v0.2.3(闪避收招单独占一段)
    XN2_DODGE_CAP = 1.60
    XN2_DODGE_HOLD = 0.07        # 闪避 = 右键
    # 0.12 -> 0.03, 闪避后普攻 0.18 -> 0.10 一下 (10-24 第二次实机: 闪避后第 5 颗要 0.70s 才翻, 视频 0.30s;
    # 最后一颗 +1.82s vs 视频 ~+1.1s。闪避收招里按的被吞、不排队, 点得密一点才能踩上第一个能接的帧)
    XN2_DODGE_TO_A = 0.03
    XN2_POST_DODGE_A_EVERY = 0.10
    # 2.00 -> 2.80: 闪避提前到 #2, 闪后要翻 #3~#7; 撞上限早按住会剩几颗不翻(见 XN2_HOLD_AT)
    XN2_EMPTY_CAP = 2.80         # 闪避之后普攻到 XN2_HOLD_AT 颗 / 人像出来的上限, 到了照按
    # 【第 7 颗翻完就按住(预输入), 不等第 8 颗】教学视频第 8 颗翻面到临寰宇出手 < 0.1s(按住早就开始了);
    # 我们等第 8 颗读到再按, 按住到出手还要 0.39s, #7 -> 临寰宇 0.9s vs 教学 0.5s。
    # 10-24 第四次实机在第 5 颗就按住: 按住期间已经排队的楼阁照样翻了 #5~#7, 但那圈闪避切断了 A3, 链打到头还剩
    # #8, 心停手 3s 不出 —— 按住只接着打已经出手的那段, 剩下的不会自己补。所以只剩最后 1 颗才按, 再加 XN2_HOLD_STALL 兜底
    XN2_HOLD_AT = 7
    # 按住后雕像这么久没再翻、也没出手 = 链打到头了还没打空(或判据漏读), 松开回普攻补到人像再按(原来干等满 3s)
    XN2_HOLD_STALL = 1.00
    # 雕像坐标/阈值照抄心雷穗 v1.1.0(2K/1080 实机验过): 4K x, 下半红菱形 y / 上半亮白 y, 半宽
    XN_STATUE_XS = (1647, 1719, 1794, 1866, 1938, 2013, 2085, 2160)
    XN_STATUE_Y = 1980
    XN_STATUE_UP_Y = 1953
    XN_STATUE_HW = 9
    XN_STATUE_RED = 0.08         # 红菱形占比(没翻 0.00, 翻了 0.10~0.55)
    XN_STATUE_GLOW = 0.30        # 上半身亮白占比(没翻 <= 0.12, 翻面那一刻 0.45~0.61, 翻完常亮 0.14~0.5)
    XN_STATUE_CONFIRM = 2
    # 同一帧新亮 >= 这么多颗 = 闪光(心汐守 10-07: 同奏入场闪光让几颗雕像一起亮), 这一帧不算
    XN_STATUE_BURST = 3
    XN2_HOLD_CAP = 3.00
    XN2_READY_REPRESS = 0.60     # 按住时人像出来这么久还没出手就松开重按(人像出来再按住 0.40~0.45s 出手)
    XN2_REPRESS_MAX = 2
    XN2_TY_A_EVERY = 0.18
    XN2_READY_CONFIRM = 2
    XN_READY_MIN = 0.80
    XN_READY_GLYPH = (
        'AAAAAAAGGDxjHgwAAAAAAAAAABQoWcH31Vg3Jg0AAAAAACGmh+r9+X82NzlcMgAAAAZ47tD9/c06R2NGZ2cWAAA32P38/f2+N0xtaDY3MQIa'
        '3/v9/v3x4DhNbFk2OEcVYf39/f34yMM4RGJWQjmCKmH9+vW6sa2FPT09WGFLyjZ5/c7E4fWaQD0/UHOX0POeYfmXotjqXz09PkBvmojMUTfc'
        'vZnUhD08PDw9mcfbvzMBauG+pJZJREA9P9L05XAFACb1+/38refMZD3D+oQjAAAAbfn9/tDY/LQ7tOMxAgAAAABU2f7is/y+QMd0AgAAAAAA'
        'AAhcpG3GgygPAAAAAA=='
    )
    XN_TY_MIN = 0.60             # 统御众机雕像 0.71~1.00 / 其他 <= 0.38
    XN_TY_GLYPH = (
        'AAAAAAAMJCEsJBYBAAAAAAAAABiR1cJ40tzbpyYAAAAAABK+4+Pt2unk48BaJAAAAAhQg6aMnN1/l6RzUVEbAAAzV3Dw9crHyvngXlFQRQIJ'
        'VFqs8dbtovLV8JdRUFAdIlmK7ZPT7IT7v6Dtbk9bOzdhj5en/O2E/PmHoXdelTpIsV1Xrv3thPz7iE9XwJuUJsCvW6797YX9+4dTsfjxriWy'
        '9KGQ++2E/fqGnvfU33sBpvjsmt/thPzfmeylk9cPADOnpLzM7IT4tc54Y+FhAAAASGKt+eyD5uiKUbyiBQAAAAAkjf3tg/j6h3aCCQAAAAAA'
        'AAZbpFvGrUwKAAAAAA=='
    )
    XN_TY_SLOT = (2826, 1893, 82, 79)   # 重击位(4K, 跟 hsin_h1 的标注框一样)
    XN2_READY_HOLD = 1.20        # 补救时人像出来后按住到 HUD 消失的上限(实测 0.40~0.45s 出手)
    XN2_BLIND_HOLD = 2.00        # 补救时没看到人像(撞上限/没进统御众机)按住试一次的上限
    XN2_RELEASE_AFTER_GONE = 0.30
    XN2_ANIM_MIN = 1.40          # 临寰宇藏 HUD ~2.0s
    XN2_ANIM_CAP = 4.00
    # 按住没出(被打断 / 人像误读) -> 普攻到人像再按, 最多这么多次。
    # 心没拿到变奏(锁暝没带同奏/协奏没满)时没进统御众机, 第一次补救前先按一下 E(满 300 照世心是万阙连衡, 不满也给照世心)
    XN2_RETRIES = 2
    XN2_RETRY_CAP = 1.50         # 补的那一轮普攻到人像的上限(同奏下人像不一定认得到, 到点照按)
    # 1.20 -> 0.30: 临寰宇演完 HUD 回来后不点普攻干看 hsin_lib2 的上限。10-24 实机认出来都在 0.05~0.24s,
    # 过了这个点还没认出 = 能量不够, 马上边点普攻边看(下面 XN2_R2_BUILD_CAP), 不再干站 1.2s
    XN2_LIB2_CAP = 0.30
    # 【万阙垂天图标没认出 = 大招能量不够, 先攒能量, 不照按】统御众机那段普攻没打中怪, 能量不满, R 位不是万阙垂天:
    # 10-07 14:16 L1 照按 R 连发 30 下没放出来; 心卜穗 10-06 09:31 照按放成了借相(R 进 1.5s 冷却, 心切回应世相)。
    # 现在照世相普攻攒, 每帧看 hsin_lib2, 认出来再放; 撞上限就这一轮不放
    XN2_R2_BUILD_CAP = 5.00
    # 2 -> 1: hsin_lib2 在临寰宇之前一帧都不中(0.95+ / 之前 <0.7), 读到一帧就按, 省一帧
    XN2_LIB2_READS = 1
    # 【万阙垂天要认图标】v0.2.6 改成临寰宇后盲按, v0.2.8 用户要回来: 伤害丢失(统御众机普攻没打中)时能量不满,
    # 盲按会放成借相、心切回应世相, 这一轮就没万阙垂天了。True = 盲按(认不出才认图标重按)
    XN2_R2_BLIND = False
    # 万阙垂天演完 -> 切守之前协奏要真满(守岸人要变奏入场)。心汐守实机 11:23 启动轴: 心第一次上场协奏从 0 起,
    # 万阙垂天演完协奏环还差一截 -> 下一个人普通入场。不满就补: 心的 E(回协奏多) -> 普攻, 每下之后读一次
    # 【开大之前就把协奏打够】: 实机 10-05 11:56 万阙垂天演完补了 E + 14 下普攻(3.1s)协奏一点没涨 ——
    # 开完大心多半离怪远了, 打不到。所以开大前先读: 低于 XN2_PRE_R2_CON(万阙垂天自己回 20)就照世相普攻补,
    # 这时候人还贴着怪。开大后那道闸只留短上限兜底
    # 【v0.2.6 关: 临寰宇演完直接开大】19:59/20:00/20:03 三次启动轴开大前协奏 0.73~0.80, 普攻补 1.3~2.06s 只涨 0~0.06
    # (照世相这时候的普攻几乎不给协奏), 白耽误万阙垂天; 启动轴协奏改由万阙垂天后的重击 + E + xn_ensure_con 补
    XN2_PRE_R2 = False
    XN2_PRE_R2_CON = 0.80
    XN2_PRE_R2_CAP = 2.00
    XN2_CON_READ = 0.20
    XN2_CON_CAP = 1.50
    XN_E_CD = 12.0               # 共鸣技能·应世相冷却
    XN2_ECHO = True              # 万阙垂天前放心的声骸(视频"释放声骸接大招")
    # 万阙垂天演完按一下 E 偷伤害(视频: "时间紧可以不用")。守 R 冷却 25s, 我们比视频快的话守那边反正要等 R,
    # E 不亏; 实机守 R 总等不到才考虑关
    XN2_E_AFTER_R2 = True
    # 【万阙垂天之后: 启动轴、循环轴都是 重击 + E】
    # 循环轴: v0.2.4~v0.2.9 只偷 E("普通重击不给应世心"是错的 —— 那时重击松在时停里根本没出)。解冻 E 一出手就切,
    # 心插段进场应世心是 0, 3A 打完左半只到 0.45~0.50, 心1 变奏进场右半 0.66, 补 A x7~9 2.5~3.1s(22:02/22:03 实机)。
    # 22:01 启动轴按过时停的重击: 左半 0.03 -> 0.24, E 后 0.40; 下一圈插段进场 0.25 -> 3A 后 0.71, 心1 只补 A x1 0.9s。
    # 收尾多 ~0.8s, 心1 省 1.6~2.1s(用户 10-24 定的)。
    # 启动轴: 心开局应世心就满(链2), 心1 直接出步红尘, 心在场短、协奏攒得少。18:56/18:57 两次启动轴只 E 不重击,
    # 万阙垂天后补协奏 E + 7A 1.5s 撞上限没满, 守普通入场; 22:01 按过时停的重击出了, E 后协奏就满、不用补。
    # 重击: 演出藏 HUD 后 XN2_R2_HOLD_FROM 起按住, 一直按到解冻后 XN2_R2_HEAVY_HOLD 才松, 解冻后 XN2_R2_E_AT 按 E。
    # 【HUD 回来 != 能动】HUD 回来后还有一段白屏时停(技能栏 CD 数字不走): 19:06 录屏 HUD 97.65 -> CD 走 98.25,
    # 教学3 HUD 86.60 -> 87.20, 都是 ~0.60s。v0.2.8 及以前 HUD 回来 +0.45 就松手 = 松在时停里, 重击整个没出,
    # 紧接着的 E 才是那一刀(E 进 CD 98.58), 协奏靠后面补 A 1.15~1.5s。
    # 教学3 一直按着: 解冻那帧就起手, +0.6~0.7 金色一刀, +0.9 E 进 CD, +1.2 切守。
    # 松手放解冻后 0.45: 预输入算数时重击解冻就出, 松手无害; 不算数(解冻才开始计按住)也够出重击的 ~0.3s
    XN2_R2_HEAVY = True
    XN2_R2_HEAVY_OPENER = True
    XN2_R2_HOLD_FROM = 3.60
    XN2_R2_FREEZE = 0.60
    XN2_R2_HEAVY_HOLD = 0.45
    XN2_R2_E_AT = 0.85
    # 0.50 -> 1.20 (10-24 实机: HUD 一回来就连按 5 下, 技能栏 E 有按下的圈但没进 CD —— 万阙垂天收招里被吞)
    XN2_E_CAP = 1.20
    # 【万阙垂天把这一波打死了 -> 等新怪再重击 + E】(用户 10-24) 这两下要打中才给应世心, 是下一圈心1 强化重击的本钱,
    # 没怪空挥就白给了。22:30 录屏 L1/L3 万阙垂天都把 Boss 打死了, 重击 + E 全打在换波的空场里, 下一圈 L2/L4 心1 都补 A x4。
    # 演出里照样预按住; HUD 回来后的白屏时停里看有没有怪(xn_enemy_here), 到 XN2_R2_TARGET_BY 一帧都没读到
    # (至少 TARGET_GONE_CONFIRM 帧)就在时停里松手(时停里松手重击不出, v0.2.8 实机), 不点普攻、每 WAVE_LOCK_INTERVAL
    # 按中键, 新怪出来(连 ENEMY_CONFIRM 帧)再重新按住重击 -> E; XN2_WAVE_WAIT 没等到(整场打完了)就不打, 照常补协奏切守
    # 【v0.2.14 关】10-25 00:0x~00:17 实机 L1/L3 每次都判没怪, 但 1.15~1.49s 就"等到新一波"(录屏里新 Boss 要 5~7s),
    # 多半是血条/破盾图标误读, 用户嫌不稳定先拿掉。关掉 = 照旧按过时停出重击 + E
    XN2_R2_WAVE_WAIT = False
    XN2_R2_TARGET_BY = 0.40      # 时停 0.60s, 留 0.2s 在解冻前松手
    XN2_R2_FRESH_HOLD = 0.45     # 新怪出来后重新按住的时长(解冻后才按, 不吃预输入, 重击要 ~0.3s)
    XN2_R2_FRESH_E_AT = 0.40     # 松手后多久按 E(同预按住那条: 松在解冻 +0.45, E 在 +0.85)
    # 换波: 22:30 录屏 L3 万阙垂天 HUD 回来后 ~7s 新 Boss 血条才出来(L1 <= 5.0s, 中间被守变奏入场挡住看不到)
    XN2_WAVE_WAIT = 9.0
    TARGET_GONE_CONFIRM = 2      # 连着这么多帧没读到怪才算没怪, 单帧被特效挡住不算
    ENEMY_CONFIRM = 2            # 新怪连着这么多帧读到才算出来(怪物血条有怪时也会一闪一闪)
    WAVE_LOCK_INTERVAL = 0.3
    # 【收尾给下一圈心1 垫应世心】心1 变奏进场条 = 收尾剩的 + 插段 3A(~+0.46) + 变奏 60 点, 要满才直接出步红尘。
    # 教学3 收尾打 1.9s, 应世心左半 0 -> 0.27~0.29 才切, 心1 进场右半 0.93~0.97;
    # 17:55 录屏我们 HUD 回来 1.1s 就切, 收尾一点没涨(0.04), 心1 进场右半 0.62~0.84, 补 A + 重按要 1.5~4s。
    # 普攻到左半 >= XN2_TAIL_YING(连 2 帧)才走后面的补协奏/切守, 打不到怪就到 HUD 回来 + XN2_TAIL_CAP 为止。
    # 18:29 录屏(v0.2.2) 四圈全撞上限: E 后普攻打中了(有伤害数字)但 1s 只涨 0.06~0.10, 白多 ~1s/圈 -> 关。
    # 差的那几点改在心1 进场普攻补(xn1_entry_fill), 那里连段打得满、涨得快
    XN2_TAIL_A = False
    XN2_TAIL_YING = 0.30
    XN2_TAIL_CAP = 2.00

    # ==================== 锁暝 ====================
    # ---- 第一次上场(心转相给的同奏 -> 变奏·锁妄念·同奏, 进念深): R -> 演完 -> 同奏切心(暗鸟见 SO_ECHO_IN_KX) ----
    SO_R_LEAD = 0.25             # 切人键 -> 开始按 R(变奏入场的锁里按的被吞, fire_r 会一直按到 HUD 消失)
    SO_R_WINDOW = 2.50           # R 连按到 HUD 消失的窗口(要盖过变奏入场的动作)
    SO_R_ENSURE_CAP = 5.00       # R 不亮(能量不够 / 没进念深)攒的上限
    # 【循环里锁暝两次 R 刚好隔一个 25s CD】: 10-24 实机切进来时 R 还剩 1.0s CD, 旧版"点一轮 A(0.6s)再看一次"
    # 亮了 1.4s 才按出去。改成边点 A 边每帧看, 亮了马上按
    SO_R_WAIT_CAP = 4.00
    SO_R_ANIM_MIN = 2.50         # 锁暝大招藏 HUD(实机 4.9s)
    SO_R_ANIM_CAP = 8.00
    # 暗鸟一直按到声骸进 CD(10-24 实机: HUD 回来连按 2 下, 技能栏 Q 有按下的圈但没进 CD —— R 收招里被吞)。
    # 同奏 5s 按游戏时间算(大招演出里倒计时停), 多按 1s 不会让心丢变奏
    SO_ECHO_CAP = 1.00
    SO_ECHO_RISE = 1.0           # CD 比按之前高出这么多秒才算放出去
    # 【暗鸟挪到锁b 刻心念之后】教学3(作者也带暗鸟): R 之后放卡手, 刻心念收完再放不卡、放完直接变奏心。
    # R 之后那 0.74~0.85s 是在吃锁暝 R 给的 5s 同奏。启动轴那次锁R 就不放了(第一次在循环第一圈锁b)。
    # False = 旧版 R 演完放
    SO_ECHO_IN_KX = True
    # ---- 循环轴第一截(守 3AE 切过来, 普通入场, 念深): 解伞形 4 段 -> 切守 ----
    # 【第 4 段要在第 3 段之后按住普攻】(技能说明; 第 2 段之后按住是旋雷破, 所以前 3 段只能点)。
    # 不看妄执条: 10-24 实机录屏条上的粉紫读数被锁暝自己的特效污染, 0.1~0.9 乱跳, 有三圈 1.7~2.0s 就"读够"切走了,
    # 没打到第 4 段。改成按段的时间点
    SO_A_EVERY = 0.20            # 普攻点按间隔(动作里的点击被丢掉)
    SO_A_LEAD = 0.15             # 切人键 -> 第一下 A
    # 【A4 的妄执要在锁暝在场时到账】妄执只在锁暝是场上角色时攒(技能说明), 切走以后落地的伤害一点不给。
    # 锁R 的变奏·锁妄念·同奏清空妄执、R 给 200, 所以锁a 进场只有 200(条左半一截), 要攒 ~400 回来碎霆 +200 才满。
    # 录屏量条(左右各 17 格, 一格 ~24): A1+A2 入场后 ~1.2s 填满左半, A3 只加一点, A4 的大头在入场后 +2.45~2.75s 才到账。
    # 实机对表(从第一下 A 起按住到): 2.21 四圈 / 1.95 三圈全不满, 锁b 补 1.0~1.4s。
    # 切守的时刻: 教学视频2 A4 起跳砸地 +1.9s -> 冲刺 +2.7s, 冲刺那下妄执到账后切(右半 0.64), 收尾那一击
    # (橙色爆 + 金色地面)切走后在后台打完。第七次实机 2.60 切在冲刺之前, 右半只有 0.57, 6 圈里 1 圈锁b 要补
    # 【A4 出手就松开普攻】第八次实机一直按到切人(2.95): 冲刺之后普攻还按着, 游戏接了下一段, 切走后锁暝在后台转伞,
    # A4 收尾那一击没打出来。A4 只要 A3 之后按住触发, 出手以后松开照样打完
    SO_4A_TAP_UNTIL = 1.25       # 从第一下 A 起点到这一刻(A3 已经出手, 离 A2 收招够远, 按住不会变旋雷破)
    SO_4A_HOLD_UNTIL = 2.15      # 按住普攻到这一刻松手(A4 已经起跳)
    SO_4A_SWITCH_AT = 2.95       # 不按键等到这一刻切守(冲刺那下妄执到账, 在场 ~3.1s, 跟教学同一个点)
    # ---- QY 循环第一截: A1A2 -> 闪避 -> A1A2 -> 切心 ----
    # 教学3(从进场起): A2 +0.95、条左半 +1.35 填满、闪避 +1.65; 闪避后 +0.8 / +1.4~1.7 两下进条、+1.9 切心, 在场 3.5s,
    # 切走时右半 0.76。我们点 A 的节奏 A2 在第一下 A 后 +0.55(4A 实测), 闪避放在 A2 出手后 ~0.7s
    SO_QY_TAP1_UNTIL = 0.65      # 从第一下 A 起点到这一刻(A1/A2 出手; A3 的接段窗口在 +1.0 左右, 那时手已经停了)
    SO_QY_DODGE_AT = 1.25        # 从第一下 A 起这一刻闪避(A2 的伤害进完条)
    SO_QY_TAP2_FROM = 0.25       # 闪避后这一刻开始点
    SO_QY_TAP2_UNTIL = 1.15      # 闪避后点到这一刻(A1/A2)
    SO_QY_SWITCH_AT = 1.85       # 闪避后这一刻切心(A2 那几下在场进条)
    # 4A 被打断保底: 打完妄执条中位数 < 这个就再打一轮(10-24 正常三圈 0.61/0.68/0.74, 被击飞那圈 0.36)
    SO_4A_REDO_BELOW = 0.45
    SO_4A_REDO_MAX = 0           # 不在这里读条补(读条 + 再打一轮比锁b 碎霆后补贵), 交给锁b 补妄执
    # ---- 循环轴第二截(守 R 后协奏满, 变奏碎霆 +200 妄执): 点 E(无舍念) -> 点 A(刻心念) -> 等协奏满 -> 变奏心 ----
    # 0.80 -> 0.30 (10-24 实机: 0.8s 才开始按, 第一次按下沿落在碎霆里被吞, 1.06s 后才重按; 这一截比视频慢 ~0.9s)
    SO_KX_E_LEAD = 0.30          # 切人键 -> 开始看/按 E(碎霆的动作里按的被吞, 靠 SO_KX_E_EVERY 连点)
    # 1.50 -> 0.80 (10-24 第三次实机: 妄执够的圈 E 位一进场 0.3s 就是无舍念; 不够的圈干等满 1.5s 才开始补)
    SO_KX_FORTE_CAP = 0.80       # 等 E 位变成无舍念(妄执满)的上限; 没满就普攻补到满(SO_KX_FILL_CAP)
    # 3.00 -> 6.00, 连点 -> 整轮 4 段(10-24 第二次实机最后一圈: 4A 被 boss 火焰击飞打断, 进碎霆时妄执差一截;
    # 连点只会 A1~A3 循环, 3s 没补满, 没出无舍念、协奏也没满, 心拿不到变奏, 后面全乱)
    SO_KX_FILL_CAP = 6.00
    SO_KX_CON_CAP = 3.00         # 没出刻心念时普攻补协奏的上限(协奏不满切过去心拿不到变奏, 整圈就散了)
    # 【刻心念不按住】按住那段转圈是时停(倒计时、Q 冷却都停), 按多久就多花多久实时, 协奏 +40 在收尾那下才给。
    # 第七次实机按住 E 到协奏满: 转圈 ~2.0s, 锁b 在场 6.7s; 教学视频2 转圈 ~0.5s, 在场 5.0s; 游戏时间两边都是 4.3s。
    # 无舍念出来后 E 和 A 都换成刻心念; 刻心念收完 E 是破隙(带同奏放会扣 20 协奏), 所以刻心念只用 A 点
    SO_KX_E_EVERY = 0.10         # E 位还是无舍念就这么密地点 E(碎霆入场里按的被吞; 0.25s 重按比教学晚 0.15s 出)
    SO_KX_E_TAP = 0.05           # 一下 E 按住这么久(10ms 的会被吞)
    SO_KX_WUSE_CAP = 2.50        # 无舍念点不出来的上限(碎霆入场 ~1.3s)
    # 无舍念出来后 [FROM, UNTIL] 里点 A。刻心念图标(红圈)在无舍念后 ~0.3s 出来; 教学 +1.0s 出手,
    # 一直按着 E 是 +1.3s 才接上, 点到 1.5 两种都盖住; 出手后 1.3~1.6s 才开始转圈, 那时手已经松了
    SO_KX_A_FROM = 0.30
    SO_KX_A_UNTIL = 1.50
    SO_KX_A_EVERY = 0.12
    # 【锁b 交棒只认光圈】18:29 录屏最后一圈刻心念被怪打断, 协奏读数在 0~0.6 乱跳, 最后读到 0.99/1.00 就切了,
    # 另外两格一直没光圈(<= 0.04) -> 心普通入场、应世心 0、整圈散掉。前三圈都是 2.12~2.14s 等到光圈切的。
    # 光圈本局认出过(glow_trusted)就不信读数: 读数满了再等 SO_KX_GLOW_GRACE 没光圈 = 没满, 普攻补到光圈(SO_KX_CON_CAP)。
    # 光圈一直认不出(分辨率/缩放不对)就还按读数
    SO_KX_GLOW_GRACE = 0.50
    SO_KX_FINISH_CAP = 3.50     # 点完 A 不按键等协奏真满(教学刻心念出手 -> 切心 2.7s); 没满走 SO_KX_CON_CAP 普攻补
    SO_KX_WZ_CLEAR = 0.30        # 只记日志: 妄执条读数连 2 帧低于这个 = 刻心念出手清空了妄执
    SO_TO_XN_TIME_OUT = 4.00     # 刻心念收招没完游戏不放人
    SO_WZ_HUE = (145, 180)       # 粉紫(OpenCV 色相 0~180)
    SO_WZ_SAT = 85
    SO_WZ_VAL = 140


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.si_holding = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.hud_seen_at = 0.0         # 最后一次读到队伍 HUD 在场的时刻(HUD_LOST_ABORT 用)
        self.hud_watch = False         # 宏跑着的时候才查 HUD 丢没丢
        self.drive_log_at = 0.0
        self.timeline_logged = True
        self.sk_intro_done_at = 0.0
        self.so_tongzou_at = -99.0     # 锁暝 R 出手的时刻(给自己 5s 同奏, 切守/切心时用来判变奏)
        # reset_state() 只在 load_chars() 时跑, 而角色对象会被粘性复用 —— 这里也要启一次
        try:
            start_enable_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        # 内置非治疗角色默认 True, 换类时会被打回, 所以在这里重申(这条轴不在切人时按处决)
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_xss(self) -> bool:
        """本队 = 心 + 锁暝 + 守岸人。按类名判。"""
        members = 0
        for char in self.task.chars:
            if char and char.name in {'ShoreKeeper', 'Suoming'}:
                members += 1
        return members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。不查任何技能可用性(场下读数是旧的)。"""
        if not self.is_in_xss:
            return 'team is not hsin/shorekeeper/suoming'
        if not self.opener_armed:
            restarted = getattr(self.task, '_ww_task_restarted_at', -1)
            if restarted > self.last_opener:
                self.logger.info('auto combat 重开过 — 启动轴重新武装, 从头跑')
                self.opener_armed = True
                return None
            return 'already armed-down (ran once this combat)'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原语(引擎) ====================

    def macro_wait(self, sec):
        """精确等待, 【不点击】。切成 0.1 秒一片, 片间检查任务是否被停用。"""
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def wait_until_time(self, deadline):
        self.macro_wait(deadline - time.time())

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')
        # 【看门狗】每一步都会打标记, 在这里顺手查: HUD 很久没出现 = 关卡结束/过场/窗口没了,
        # 再按下去就是在结算画面上乱按(景月守实机 2026-09-28 19:17 见过)。不读屏, 只比时间戳
        if self.hud_watch and time.time() - self.hud_seen_at > self.HUD_LOST_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'队伍 HUD {time.time() - self.hud_seen_at:.1f}s 没出现(关卡结束/过场/窗口没了?)')

    def hud_ok(self):
        """队伍 HUD 在不在(读当前帧)。见到就记下时刻, 给看门狗用。"""
        ok = bool(self.task.in_team()[0])
        if ok:
            self.hud_seen_at = time.time()
        return ok

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A'):
        """连点一个窗口。打出几段由 window 决定(动画期间的点击被丢掉, 连点保证总有一下落在动画刚结束时)。"""
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        while time.time() - start < window and n < cap:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            # click 自己按住 A_TAP 秒, 不扣的话连点周期从 interval 变成 interval + A_TAP
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=False, presses=None):
        """在一个窗口里反复发同一个技能键(动画期间的按键被丢掉、不排队, 单发必丢)。

        poke: 发键期间要不要照常点普攻(两条节奏各走各的)。presses: 只发这么多次, 均匀铺在窗口里。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - time.time()))
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def game_foreground(self):
        try:
            return bool(self.task.executor.interaction.hwnd_window.is_foreground())
        except Exception:
            return False

    def attack_down(self, direct):
        """按下左键。direct = 走 SendInput(失败自动退回 PostMessage)。返回实际走没走 SendInput。"""
        if direct and send_input_left(False):
            self.si_holding = True
        else:
            direct = False
            self.task.mouse_down()
        self.holding_attack = True
        return direct

    def release_attack(self):
        # 【SendInput 按下的必须 SendInput 松开】: PostMessage 的 mouse_up 只进游戏窗口的消息队列,
        # 系统里那个左键会一直按着 —— 宏异常退出时整台电脑的左键都是按住的
        if self.si_holding:
            if not send_input_left(True):
                self.logger.warning('SendInput 左键松开没发出去 — 如果左键卡住, 手动点一下')
            self.si_holding = False
            self.holding_attack = False
        elif self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def tap(self, hold=None):
        """点一下普攻, 【真的按住 hold 秒】。"""
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本队里所有的 self.click() 都改成按住 A_TAP(BaseChar.click 强制 10ms, 等于没点)。不在本队走原版。"""
        if not self.is_in_xss:
            return super().click(*args, **kwargs)
        self.tap()

    def quick_switch(self, target, click_during=False, time_out=None, read_con=False, assume_con=False):
        """按数字键直切给指定角色(不走 switch_next_char 选人)。

        read_con: 按键之后读一次协奏决定按不按"带变奏"记账; assume_con: 不读屏直接按满协奏记。
        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        self.switch_press_at = time.time()
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            # 不用 char.is_con_full(): 那层读到过一次满就一直缓存成满
            try:
                con_full = float(self.task.get_current_con()) >= 1.0
            except Exception:
                con_full = False
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace and time.time() - entry > 0.4:
                    self.logger.info(f'slow switch trace -> {target.name}: {" ".join(trace)}')
                return True
        # 一直是旧角色的 index = 游戏在拒绝切人; 带 ? 的都是目标 = count 判据挡住了; 全是 x = HUD 不在
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账。不补的话 get_current_char() 返回 None, 主循环当场崩。"""
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_retry(self, target, tag, **kw):
        """quick_switch, 超时了先等 HUD 回来再切, 最多再试 SWITCH_RETRIES 次。只花时间。"""
        if self.quick_switch(target, **kw):
            return True
        for i in range(self.SWITCH_RETRIES):
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
            self.macro_mark(f'{tag}切{target.name[:3]}重试#{i + 1}')
            kw2 = dict(kw)
            kw2['time_out'] = self.SWITCH_RETRY_TIME_OUT
            if self.quick_switch(target, **kw2):
                return True
        return False

    def wait_hud_back(self, tag='anim', time_out=None, min_gone=0.0, tail=0.0, hold_from=None):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。先确认消失过。

        min_gone: 从第一次读到消失起, 这么久之内读到的"回来"不认(演出中途 HUD 会闪一两帧)。
        回来要连读 HUD_BACK_CONFIRM 帧。
        hold_from: 消失后这么久按住普攻(预输入重击), 返回时还按着, 调用方负责松开。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_at = None
        back_hits = 0
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if (hold_from is not None and gone_at is not None and not self.holding_attack
                    and time.time() - gone_at >= hold_from):
                si = self.xn_attack_down()
                self.macro_mark(f'{tag}按住预输入({"SI" if si else "PM"},{time.time() - gone_at:.2f}s)')
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        back = True
                        break
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_at is not None else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候判"演出开始了"是假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def watch_hud_gone(self, window, tag, poke_after=None):
        """在 window 里盯队伍 HUD 有没有连续消失(= 演出开始), 消失了立刻返回 True。

        poke_after: 过了这么久 HUD 还在就开始点普攻(这一下技能没出手, A 在攒资源)。None = 不点。
        """
        start = time.time()
        gone = clicks = 0
        next_click = 0.0
        while time.time() - start < window:
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    self.macro_mark(f'{tag}(出手,{time.time() - start:.2f}s,A x{clicks})')
                    return True
            else:
                gone = 0
                now = time.time()
                if poke_after is not None and now - start >= poke_after and now >= next_click:
                    self.tap()
                    clicks += 1
                    next_click = time.time() + self.A_INTERVAL
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(没出,A x{clicks})')
        return False

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 只在拿不到入口角色时才用(开局 HUD 渐入时 in_team() 会说谎, 要 count 达标)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的, 读到的是上一个人的 CD。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.hud_ok())
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    def fire_r(self, char, tag, window):
        """发大招到队伍 HUD【连续】消失 LIB_GONE_CONFIRM 帧。返回放出去没有。

        发键之前先等 HUD 在场(HUD 本来就不在会假成功)。确认期间继续按 R 没有副作用 —— 演出里的按键被丢掉。
        """
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        # lit=True: 键被上一个动作吞了; lit=False: 能量不够
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def lib_ready_reads(self, char, frames):
        """HUD 在场时连续 frames 帧读到 char 的 R 可用。HUD 不在的帧不算, 最多读 frames*3 帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def ensure_r(self, char, tag, window, cap, build):
        """R 一定要放出来。读 R 亮 -> 按; 亮着却没放出去就再按, 最多 R_TRIES 次;
        不亮 -> build(轮次) 攒一小段再读, 每 R_BLIND_EVERY 轮盲按一次防读数不准。上限 cap 只防打不到怪。
        """
        start = time.time()
        tries = rounds = 0
        while time.time() - start < cap:
            if self.lib_ready_reads(char, 2):
                tries += 1
                if self.fire_r(char, f'{tag}R' if tries == 1 else f'{tag}R重按#{tries - 1}', window):
                    if rounds:
                        self.logger.info(f'{tag}: {char.name} R 攒了 {time.time() - start:.1f}s 能量才放出去')
                    return True
                if tries >= self.R_TRIES:
                    break
                continue
            rounds += 1
            if rounds == 1:
                self.macro_mark(f'{tag}R没亮(攒能量)')
            build(rounds)
            if rounds % self.R_BLIND_EVERY == 0 and not self.lib_ready_reads(char, 2) and \
                    self.fire_r(char, f'{tag}R盲按#{rounds}', self.R_BLIND_WINDOW):
                return True
        self.logger.warning(f'{tag}: {char.name} 的 R 保底 {time.time() - start:.1f}s 还是没放出去 '
                            f'(亮了按 {tries} 次, 攒能量 {rounds} 轮), 不放了')
        return False

    def read_cd(self, name='resonance', char=None):
        """读技能框里的 CD 数字(秒)。不在 CD / 读不到都返回 0(框架没 CD 时返回负数, 截成 0)。"""
        try:
            index = None if char is None else char.index
            return max(0.0, float(self.task.get_cd(name, index)))
        except Exception:
            return 0.0

    def read_con(self, want, settle=None, click=False, tag=None):
        """读协奏: 自己刷帧、给结算留时间, 连着几帧达到 want 就立刻返回。返回期间读到的最大值。"""
        settle = 0.50 if settle is None else settle
        start = time.time()
        best = 0.0
        hits = 0
        next_click = 0.0
        while True:
            now = time.time()
            if click and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.SK_CON_FULL_CONFIRM or time.time() - start >= settle:
                break
            self.macro_wait(self.SK_CON_POLL)
        if tag:
            self.macro_mark(f'{tag}(con{best:.2f},{time.time() - start:.2f}s)')
        return best

    def wait_con_full(self, who, cap, tag, poke=True, cur=None, strict=False):
        """边打边等协奏真满(连着几帧; 给了 cur 就光圈也算; strict 且光圈认得出过就只认光圈)。返回满没满。"""
        strict = strict and cur is not None and self.glow_trusted()
        start = time.time()
        samples = []
        hits = 0
        next_click = 0.0
        while time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            if cur is not None and self.con_glow(cur):
                self.macro_mark(f'{tag}(满,光圈,{time.time() - start:.2f}s)')
                return True
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            hits = hits + 1 if con >= self.SK_CON_ENOUGH else 0
            if hits >= self.SK_CON_FULL_CONFIRM and not strict:
                self.macro_mark(f'{tag}(满,{time.time() - start:.2f}s)')
                return True
            self.macro_wait(self.SK_CON_POLL)
        self.macro_mark(f'{tag}(没满,{time.time() - start:.2f}s)')
        self.logger.info(f'{tag}: {who} 协奏 {" ".join(samples)}')
        return False

    def glow_slot(self, frame, slot):
        """队伍栏第 slot 格(0 起)头像外面那圈细白环 -> 落在同一半径上的上半圈角度占比(0~1)。"""
        H, W = frame.shape[:2]
        s = H / 2160
        cx = W - (3840 - 3586.5) * s
        cy = (500 + 264 * slot) * s
        R = int(round(125 * s)) + 3
        xa, ya = int(cx) - R, int(cy) - R
        if xa < 0 or ya < 0 or xa + 2 * R + 1 > W or ya + 2 * R + 1 > H:
            return 0.0
        crop = frame[ya:ya + 2 * R + 1, xa:xa + 2 * R + 1, :3]
        white = np.ascontiguousarray(crop.min(axis=2)).astype(np.float32)
        polar = cv2.warpPolar(white, (R, 360), (cx - xa, cy - ya), R, cv2.WARP_POLAR_LINEAR)
        rows = polar[225:331]
        d = max(1, int(round(4.5 * s)))
        r = np.arange(int(80 * s), int(118 * s))
        ridge = rows[:, r] - np.maximum(rows[:, r - d], rows[:, r + d])
        k = ridge.argmax(axis=1)
        hit = ridge[np.arange(len(rows)), k] > 40
        if not hit.any():
            return 0.0
        hist = np.bincount(r[k][hit], minlength=int(r[-1]) + 2)
        win = max(2, int(round(4 * s)))
        return float(np.convolve(hist, np.ones(win), 'valid').max()) / len(rows)

    def glow_now(self, cur):
        """当前帧 cur 以外两格的光圈够不够"协奏满"。同一帧只算一次, 顺手数连着几帧(换人从头数)。"""
        frame = self.task.frame
        if frame is None:
            return False
        same_cur = getattr(self, 'glow_cur', None) == cur.index
        if same_cur and getattr(self, 'glow_frame', None) is frame:
            return self.glow_last
        others = [self.glow_slot(frame, i) for i in range(3) if i != cur.index]
        lo, hi = min(others), max(others)
        on = (lo >= self.GLOW_BOTH and hi >= self.GLOW_ONE) or hi >= self.GLOW_SOLO
        self.glow_hits = ((getattr(self, 'glow_hits', 0) if same_cur else 0) + 1) if on else 0
        self.glow_frame, self.glow_cur, self.glow_last = frame, cur.index, on
        return on

    def con_glow(self, cur):
        """光圈连着 GLOW_CONFIRM 帧都在 = 协奏真满。读当前帧(调用方负责 next_frame)。
        认出过一次就记下"这台机器光圈认得出"(glow_trusted), 之后 strict 的地方不再信读数。"""
        self.glow_now(cur)
        ok = getattr(self, 'glow_hits', 0) >= self.GLOW_CONFIRM
        if ok:
            self.glow_ok = True
        return ok

    def glow_trusted(self):
        return getattr(self, 'glow_ok', False)

    def con_ready(self, cur, settle, tag=None, strict=False):
        """交棒前读协奏: 光圈连 GLOW_CONFIRM 帧 = 满; 认不出光圈时读数连 SK_CON_FULL_CONFIRM 帧 1.00 也算满
        (strict 且光圈认得出过: 读数不算, 只认光圈)。settle 内都没有 = 不满。读数最大值留在 self.con_last(给日志)。"""
        strict = strict and self.glow_trusted()
        start = time.time()
        best = 0.0
        hits = 0
        why = None
        while True:
            self.task.next_frame()
            self.hud_ok()
            if self.con_glow(cur):
                why = '光圈'
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= self.SK_CON_ENOUGH else 0
            if hits >= self.SK_CON_FULL_CONFIRM and not strict:
                why = f'con{best:.2f}'
                break
            if time.time() - start >= settle:
                break
            self.macro_wait(self.SK_CON_POLL)
        self.con_last = best
        if tag:
            self.macro_mark(f'{tag}({why or f"没满con{best:.2f}"},{time.time() - start:.2f}s)')
        return why is not None

    # ==================== 宏表回放 ====================

    def macro_switch(self, target, hold, gap, tag, required=True):
        """宏表里的数字键: 在这一格自己的 gap 里盯到场; 没到就补按, 最多再多等 SWITCH_EXTRA。返回到没到。

        required: 还没到就先等 HUD 回来再切(switch_retry 的那一套), 再不行整圈放弃 —— 切人错一格, 后面每一格都发在错的人身上。
        不 required(插段这种可有可无的): 再认一次场上是谁, 不是目标就算了, 调用方跳过这一段。
        """
        if target is self.cur:
            self.macro_mark(f'{tag}(already)')
            return True
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        entry = time.time()
        self.switch_press_at = entry
        self.task.send_key(slot, down_time=hold)
        soft = entry + hold + gap
        hard = soft + self.SWITCH_EXTRA
        last = time.time()
        hits = 0
        arrived = False
        while time.time() < hard:
            self.task.next_frame()
            in_team, index, _count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hits = hits + 1 if (in_team and index == target.index) else 0
            if hits >= self.SWITCH_CONFIRM:
                arrived = True
                break
            if time.time() - last >= self.SWITCH_REPRESS:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = time.time()
            self.macro_wait(0.02)
        cost = time.time() - entry
        late = time.time() - soft
        if arrived:
            self.handoff(source, target, False)
            self.macro_mark(f'{tag}({cost:.2f}{f",晚{late:.2f}" if late > 0.05 else ""})')
        elif required:
            self.macro_mark(f'{tag}超时({cost:.2f})')
            self.need(self.switch_retry(target, tag), f'{tag}: switch to {target.name} never confirmed')
        else:
            # 超时那一刻可能刚好切过去了: 认一下场上是谁, 键要发给真正在场的人。认不出来先等 HUD 再认
            who = self.on_field_char(time_out=0.6)
            if who is None:
                self.wait_hud_up(cap=1.0, tag=f'{tag}认人前HUD')
                who = self.on_field_char(time_out=1.0)
            if who is target:
                self.handoff(source, target, False)
                self.macro_mark(f'{tag}(晚到,{time.time() - entry:.2f})')
            elif who is not None and who is source:
                self.macro_mark(f'{tag}切不过去({cost:.2f},还是{who.name[:3]})')
                return False
            else:
                # 场上是谁说不清: 不能赌, 按必须切过去处理
                self.macro_mark(f'{tag}超时({cost:.2f},场上{who.name[:3] if who else "?"})')
                self.need(self.switch_retry(target, tag), f'{tag}: switch to {target.name} never confirmed')
        self.wait_until_time(soft)
        return True

    def play_rows(self, rows, tag, chars):
        """按宏表逐格回放: (动作, 按住ms, 松开后ms, 注释)。每一格按【绝对时刻】排, 读屏/发键的开销不往后累计。

        动作: 'A' 普攻按住 / 'E' 'Q' 'R' 技能键按住 / 'E#' 按到进 CD(格子时间照走完) /
              '>SK' '>SO' '>XN' 切人(在这一格的 gap 里确认到场)。技能键【发给当时在场的那个人】。
        """
        t = time.time()
        for row in rows:
            act, hold_ms, gap_ms = row[0], row[1], row[2]
            note = row[3] if len(row) > 3 else ''
            hold = hold_ms / 1000.0
            gap = gap_ms / 1000.0
            self.wait_until_time(t)
            row_start = time.time()
            nxt = row_start + hold + gap
            if act.startswith('>'):
                self.macro_switch(chars[act[1:]], hold, gap, f'{tag}{note or act}')
                t = max(nxt, time.time())
                continue
            char = self.cur if self.cur is not None else self
            if act == 'A':
                self.tap(hold)
            elif act == 'E':
                char.send_resonance_key(down_time=hold)
                char.record_resonance_use()
            elif act == 'Q':
                char.send_echo_key(down_time=hold)
                char.record_echo_use()
            elif act == 'R':
                char.send_liberation_key(down_time=hold)
            elif act == 'E#':
                self.press_res_until_cd(char, max(self.SK_E_CAP, hold + gap), tag=f'{tag}{note}',
                                        ready_grace=0.15)
                char.record_resonance_use()
            else:
                raise ValueError('unknown macro action ' + repr(act))
            # 看门狗要有 HUD 读数: 宏表几秒不读屏的话会误判"HUD 丢了"。只在这一格的空档够读一帧时读
            if time.time() - self.hud_seen_at > self.ROWS_HUD_READ_EVERY and nxt - time.time() > 0.12:
                self.task.next_frame()
                self.hud_ok()
            if note:
                self.macro_mark(f'{tag}{note}')
            t = max(nxt, time.time())
        self.wait_until_time(t)

    # ==================== 守岸人 ====================

    def switch_to_sk(self, sk, tag):
        """切给守岸人并等她的变奏入场演完。返回时 HUD 在场、场上是她。"""
        for attempt in range(1 + self.SWITCH_RETRIES):
            got = self.switch_to_sk_once(sk, tag if attempt == 0 else f'{tag}重切#{attempt}')
            if got is not None:
                return got
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
        return False

    def switch_to_sk_once(self, sk, tag):
        """切一次守岸人。返回 True/False(到场了, HUD 回没回来), None = 守岸人没上场。

        带演出的强化变奏入场一切进来 HUD 就藏了, quick_switch 读不到她到场会超时 ——
        所以不管切人判没判到, 都等 HUD 回来再认一次场上是谁。演出里一下都不点(马上要接循环段)。
        """
        src = self.cur
        sw_at = time.time()
        full = False
        try:
            full = float(self.task.get_current_con()) >= 1.0
        except Exception:
            pass
        arrived = self.quick_switch(sk, assume_con=full, time_out=self.SK_TO_TIME_OUT)
        anim_in_switch = arrived and time.time() - sw_at >= self.SK_SWITCH_ANIM_HINT
        start = time.time()
        gone_at = None
        hits = 0
        back = False
        while time.time() - start < self.SK_INTRO_ANIM_CAP:
            self.task.next_frame()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                hits = 0
            elif gone_at is not None or anim_in_switch:
                hits += 1
                if hits >= self.HUD_BACK_CONFIRM:
                    back = True
                    break
            elif time.time() - start >= self.SK_INTRO_NOANIM:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}守入场({"anim" if gone_at is not None or anim_in_switch else "noanim"},'
                        f'{"ok" if back else "timeout"},{time.time() - start:.2f}s)')
        if not arrived:
            who = self.on_field_char(time_out=1.0)
            if who is not sk:
                self.macro_mark(f'{tag}守没上场({who.name if who else "?"})')
                return None
            self.handoff(src if src is not None else self, sk, full)
            self.macro_mark(f'{tag}>Sho(演出里到场)')
        self.sk_intro_done_at = time.time()
        return back

    def hold_heavy(self, char, hold, cap, tag):
        """守岸人长按重击: 鼠标指示【见过亮之后一暗】就松手; 没亮过按满 hold 兜底; cap 是硬上限。"""
        cap = max(cap, hold)
        self.task.mouse_down()
        self.holding_attack = True
        self.macro_mark(f'{tag}_down')
        start = time.time()
        why = None
        seen_lit = False
        try:
            self.macro_wait(min(self.HEAVY_MIN_HOLD, hold))
            while time.time() - start < cap:
                self.task.next_frame()
                self.hud_ok()
                try:
                    lit = bool(char.is_mouse_forte_full())
                except Exception:
                    lit = False
                if lit:
                    seen_lit = True
                elif seen_lit:
                    why = '指示暗'
                    break
                if not seen_lit and time.time() - start >= hold:
                    why = '一直暗'
                    break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        if why is None:
            why = 'cap'
        self.macro_mark(f'{tag}_up({why},{time.time() - start:.2f}s)')
        return why != 'cap'

    def sk_heavy(self, sk, tag):
        """指示一直亮着没暗(= 没打出去: 被打断/按在别的动作里)就再按, 最多 HEAVY_RETRIES 次。"""
        for i in range(1 + self.HEAVY_RETRIES):
            if self.hold_heavy(sk, self.SK_HEAVY_HOLD, self.SK_HEAVY_CAP,
                               tag=tag if i == 0 else f'{tag}重按#{i}'):
                return True
        return False

    def sk_forte_full_once(self, sk):
        try:
            return bool(sk.is_mouse_forte_full())
        except Exception:
            return False

    def sk_forte_full(self, sk):
        """守岸人回路满(鼠标指示亮)连着 SK_FORTE_CONFIRM 帧。读当前帧起。"""
        for i in range(self.SK_FORTE_CONFIRM):
            if i:
                self.task.next_frame()
            try:
                if not sk.is_mouse_forte_full():
                    return False
            except Exception:
                return False
        return True

    def sk_a_until(self, cap, done, tag):
        """守岸人连点普攻, 每下之后读屏, done() 连着两次成立就停。返回成立没有。"""
        start = time.time()
        taps = 0
        hits = 0
        while time.time() - start < cap:
            self.tap()
            taps += 1
            until = time.time() + max(0.0, self.A_INTERVAL - self.A_TAP)
            first = True
            while True:
                self.task.next_frame()
                if first:
                    self.hud_ok()
                    first = False
                hits = hits + 1 if done() else 0
                if hits >= 2:
                    self.macro_mark(f'{tag}(A x{taps},{time.time() - start:.2f}s)')
                    return True
                if time.time() >= until:
                    break
                self.macro_wait(0.01)
        self.macro_mark(f'{tag}(cap,A x{taps})')
        return False

    def sk_clear(self, sk, cap, tag):
        """清空回路: 满了才重击(满 = 强化重击, 清回路 + 协奏 6), 没满先 A 到满。返回清没清。

        cap 内没满就不按重击 —— 没满时重击出的是普通重击(化蝶, 小蝴蝶飞起来), 回路不清还白花一秒多。
        实机 10-05 14:16 循环段: 插段被跳过、回路没满, 照旧 A 1.2s 就重击 -> 化蝶。
        """
        def full():
            try:
                return bool(sk.is_mouse_forte_full())
            except Exception:
                return False
        self.task.next_frame()
        if self.sk_forte_full(sk):
            self.macro_mark(f'{tag}回路已满')
        elif cap < 0.3 or not self.sk_a_until(cap, full, tag=f'{tag}A到回路满'):
            self.macro_mark(f'{tag}回路没满不重击')
            self.logger.warning(f'{tag}: 守岸人 {max(cap, 0):.1f}s 内回路没攒满(打不到怪/时间不够), 不重击(不满会化蝶)')
            return False
        self.sk_heavy(sk, tag=f'{tag}强化重击')
        return True

    def sk_e_ready(self, sk):
        """守岸人 E 好没好: 上次放 E 的时间 + 技能栏 CD 都要说好了(OCR 读漏过一次, 把 CD 中的 E 当成好了)。"""
        return time.time() - getattr(sk, 'last_res', 0) >= self.SK_E_CD - 0.3 and self.read_cd('resonance') <= 0

    def sk_build_energy(self, sk, tag, rounds):
        """守岸人攒能量的一轮: 回路满了就打强化重击(能量多), 否则普攻一小段。"""
        self.task.next_frame()
        if self.sk_forte_full(sk):
            self.sk_heavy(sk, tag=f'{tag}攒能量重击#{rounds}')
        else:
            self.macro_spam(self.R_BUILD_SLICE, self.A_INTERVAL, tag=f'{tag}攒能量A#{rounds}')

    def sk_ensure_con(self, sk, tag):
        """守岸人协奏没满就别交棒 —— 用能给协奏的技能补: E(20) > 强化重击(6) > 普攻(1~4)。"""
        start = time.time()
        taps = 0
        while time.time() - start < self.SK_CON_RESCUE_CAP:
            if self.con_ready(sk, self.SK_CON_POLL):
                self.macro_mark(f'{tag}补协奏(满,A x{taps},{time.time() - start:.2f}s)')
                return True
            # E 好没好: 上次放 E 的时间 + OCR 都要说好了才按(OCR 读漏过一次, 把 CD 中的 E 当成好了)
            e_ready = time.time() - getattr(sk, 'last_res', 0) >= self.SK_E_CD - 0.3 and self.read_cd('resonance') <= 0
            if e_ready:
                self.spam_key(sk.send_resonance_key, 0.26, interval=0.06, tag=f'{tag}补协奏E')
                sk.record_resonance_use()
                self.macro_wait(self.SK_E_DERIVE)
                continue
            if self.sk_forte_full(sk):
                self.sk_heavy(sk, tag=f'{tag}补协奏重击')
                continue
            # 一下一下打, 每下之后看回路/协奏 —— 回路一满立刻强化重击(实机最后那截协奏就是它补上的)
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
        self.macro_mark(f'{tag}补协奏(cap,A x{taps},{time.time() - start:.2f}s)')
        self.logger.warning(f'{tag}: 补了 {time.time() - start:.1f}s 协奏还是没满, 认赔交棒(打不到怪?)')
        return False

    def sk_r_after_press(self, sk, tag):
        """守 R 按过一下之后: 盯 HUD 消失, 没消失就补按; 放出去了就等演完。返回放没放出去。"""
        if self.watch_hud_gone(self.SK_R_WATCH, tag=f'{tag}R'):
            sk.record_liberation_use()
            fired = True
        else:
            self.logger.info(f'{tag}: 守岸人 R 按了没出手(收招吞了/能量不够) — 补按')
            fired = self.fire_r(sk, f'{tag}R补按', self.SK_R_RESCUE)
        if fired:
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SK_R_ANIM_MIN, time_out=self.SK_R_ANIM_CAP)
        return fired

    def sk_hand_off(self, sk, target, tag, read=True):
        """守岸人 -> target: 协奏满了才交棒(要的是变奏入场), 读一下不满就直接补(不干等)。
        read=False: 明知不满, 不先读, 直接补(补的每一下之前照样看协奏)。"""
        full = self.con_ready(sk, self.SK_CON_READ, tag=f'{tag}协奏') if read else False
        if not full:
            full = self.sk_ensure_con(sk, tag)
        if not full:
            self.logger.warning(f'【协奏没满就交棒】守 -> {target.name}: 拿不到变奏入场')
        self.need(self.switch_retry(target, f'{tag}切{target.name[:3]}', assume_con=full), f'shorekeeper -> {target.name}')
        return full

    def sk_dodge_forward(self, tag):
        """往前闪避(按住 W + 右键): 断重击后摇, 顺便贴近怪。"""
        task = self.task
        task.send_key_down('w')
        try:
            self.macro_wait(self.WD_W_LEAD)
            task.mouse_down(key='right')
            self.macro_wait(self.WD_DODGE_HOLD)
            task.mouse_up(key='right')
            self.macro_wait(self.WD_W_TAIL)
        finally:
            task.send_key_up('w')
        self.macro_mark(f'{tag}闪避')

    def sk_ready_for_lib(self, sk, tag):
        """放 R 之前: 协奏不到 SHORE_LIB_MIN_CON 就补一发强化重击(第二发多半被打断了)。只补一次。"""
        con = self.read_con(self.SHORE_LIB_MIN_CON, settle=self.SHORE_LIB_CON_SETTLE, click=True)
        if con >= self.SHORE_LIB_MIN_CON:
            self.macro_mark(f'{tag}R保底(con{con:.2f},够)')
            return True
        self.macro_mark(f'{tag}R保底(con{con:.2f},补)')
        if self.sk_a_until(self.SHORE_LIB_RESCUE_CAP, lambda: self.sk_forte_full(sk), tag=f'{tag}补等回路'):
            self.sk_heavy(sk, tag=f'{tag}补重击')
        return False

    def sk_open_r(self, sk, tag, echo=True):
        """启动段开局的 [Q]-R。R 亮着(连两帧)才放, 放出去等演完; 返回放没放出去(没亮/没出 = 留到启动段最后)。"""
        if not self.lib_ready_reads(sk, 2):
            self.macro_mark(f'{tag}开局R没亮(放到最后)')
            return False
        if echo:
            self.spam_key(sk.send_echo_key, self.SK_Q_WINDOW, tag=f'{tag}Q', presses=self.SK_Q_PRESSES)
            sk.record_echo_use()
        if not self.fire_r(sk, f'{tag}开局R', self.SK_R_RESCUE):
            return False
        self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SK_R_ANIM_MIN, time_out=self.SK_R_ANIM_CAP)
        return True

    def seg_sk_open(self, sk, xn, tag):
        """守岸人·启动段: R(开局先放) -> 3A -> E -> 2A -> 重击1 -> 闪避 -> A 到头像光圈出来(协奏真满) -> Q -> 变奏心。
        光圈认不出来: A 到回路满(闪后至少 SHORE_OPEN_MIN_A) -> 重击2 -> Q -> 交棒。
        SHORE_OPEN_FAST 打开 = 教学3: 闪避后 2A -> Q 就交棒(要蹭闪或精三奇幻变奏)。
        开局 R 没亮就照心汐守放到最后: 闪避后 A 到回路满 -> 重击2 -> Q -> [协奏不到 0.70 补一发强化重击] -> R -> 演完。

        第一发重击锚在按下 E 的那一刻(用相对间隔往下串误差会累加)。
        """
        r_done = self.sk_open_r(sk, tag, echo=False)
        self.macro_spam(self.SHORE_A3_WINDOW, self.A_INTERVAL, tag=f'{tag}3A')
        e_at = time.time()
        if self.press_res_until_cd(sk, 0.80, f'{tag}E', ready_grace=0.15):
            sk.record_resonance_use()
        left = e_at + self.SHORE_E_TO_HEAVY - time.time()
        if left > 0:
            self.macro_spam(left, self.A_INTERVAL, tag=f'{tag}2A')
        else:
            self.macro_mark(f'{tag}2A(late{-left:.2f}s)')
        self.task.next_frame()
        if self.sk_forte_full(sk) or self.sk_a_until(self.SHORE_HEAVY1_WAIT, lambda: self.sk_forte_full_once(sk),
                                                     tag=f'{tag}重击1前等回路满'):
            self.hold_heavy(sk, self.SHORE_HEAVY_HOLD, self.SHORE_HEAVY_CAP, tag=f'{tag}重击1')
        else:
            self.macro_mark(f'{tag}重击1不按(回路没满)')
        self.sk_dodge_forward(tag)
        self.macro_wait(self.SHORE_DODGE_TO_A)
        dodged = time.time()
        if r_done and self.SHORE_OPEN_FAST:
            self.macro_spam(self.SHORE_OPEN_TAIL_A, self.A_INTERVAL, tag=f'{tag}闪后2A')
            self.spam_key(sk.send_echo_key, self.SK_Q_WINDOW, tag=f'{tag}Q', presses=self.SK_Q_PRESSES)
            sk.record_echo_use()
            return self.sk_hand_off(sk, xn, tag)
        why = {}

        def full_or_forte():
            # 开局 R 放过了: 光圈一出来就交棒; 认不出光圈就老路(回路满 + 闪后至少 SHORE_OPEN_MIN_A)
            if r_done and self.glow_now(sk):
                why['k'] = '光圈'
                return True
            why['k'] = '回路'
            return time.time() - dodged >= self.SHORE_OPEN_MIN_A and self.sk_forte_full_once(sk)

        if self.sk_a_until(self.SHORE_FORTE_WAIT_CAP, full_or_forte, tag=f'{tag}A到协奏满'):
            if why.get('k') == '光圈':
                self.macro_mark(f'{tag}协奏满(光圈,闪后{time.time() - dodged:.2f}s)')
                self.spam_key(sk.send_echo_key, self.SK_Q_WINDOW, tag=f'{tag}Q', presses=self.SK_Q_PRESSES)
                sk.record_echo_use()
                self.need(self.switch_retry(xn, f'{tag}切{xn.name[:3]}', assume_con=True), 'shorekeeper -> hsin')
                return True
            self.hold_heavy(sk, self.SHORE_HEAVY2_HOLD, self.SHORE_HEAVY_CAP, tag=f'{tag}重击2')
            self.macro_wait(self.SHORE_HEAVY_TO_QR)
        else:
            self.macro_mark(f'{tag}重击2不按(回路没满)')
            self.logger.warning(f'{tag}: 守岸人 A 了 {self.SHORE_FORTE_WAIT_CAP:.0f}s 回路没满(打不到怪?), 第二发重击不按')
        if r_done:
            self.spam_key(sk.send_echo_key, self.SK_Q_WINDOW, tag=f'{tag}Q', presses=self.SK_Q_PRESSES)
            sk.record_echo_use()
        else:
            sk.send_echo_key()
            sk.record_echo_use()
            self.macro_mark(f'{tag}Q')
            self.sk_ready_for_lib(sk, tag)
            # R 一定要放出来(领域 + 协奏 20): 不亮就攒能量, 亮了没出就重按
            if self.ensure_r(sk, tag, self.SK_R_RESCUE, self.SK_OPEN_R_CAP,
                             lambda rounds: self.sk_build_energy(sk, tag, rounds)):
                self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SK_R_ANIM_MIN, time_out=self.SK_R_ANIM_CAP)
            else:
                self.logger.warning(f'{tag}: 守岸人启动段 R 没放出去, 照常往下走')
        return self.sk_hand_off(sk, xn, tag)

    def break_prompt(self):
        """怪身上有处决提示(屏幕中间那个 F, 排除拾取 F)。读当前帧。不看顶部的谐度满(f_break_full): 那个比提示早好几秒, 那时按 F 是空按。"""
        task = self.task
        try:
            hit = task.find_one('f_break', box=task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True),
                                target_height=720, threshold=self.BREAK_CENTER_MIN)
            return bool(hit) and not task.is_pick_f()
        except Exception as e:
            self.logger.info(f'处决提示读失败 {e}')
            return False

    def break_ring(self):
        """boss 头像外圈满了(共振度满, 能处决)。读当前帧。没有 boss 血条的怪永远 False。"""
        try:
            return bool(self.task.find_one('f_break_full', threshold=self.BREAK_RING_MIN))
        except Exception:
            return False

    def note_break_prompt(self):
        """切给守岸人之前读一帧处决提示: 小怪没有外圈, 靠这一下决定守入场后要不要等提示回来。"""
        self.task.next_frame()
        if self.hud_ok() and self.break_prompt():
            self.break_seen_at = time.time()

    def break_press(self, tag):
        """提示在就按 F, 按完 BREAK_RESEND 提示还在再按; 提示连 BREAK_GONE_FRAMES 帧不见 = 起手了。
        返回(起手前最后一下 F 的时刻 或 None, 按了几下)。"""
        presses = 0
        last_f = 0.0
        gone = 0
        while True:
            if gone == 0 and time.time() - last_f >= self.BREAK_RESEND:
                if presses >= self.BREAK_PRESSES:
                    return None, presses
                self.task.send_key('f', down_time=0.05)
                presses += 1
                last_f = time.time()
            self.macro_wait(0.03)
            self.task.next_frame()
            if self.hud_ok() and self.break_prompt():
                gone = 0
            else:
                gone += 1
                if gone >= self.BREAK_GONE_FRAMES:
                    return last_f, presses

    def sk_break(self, tag, t_in, seen_before, press_not_before=0.0):
        """守岸人守a 那一下处决。外圈满着 / 切人前读到过提示 -> 盯提示到 t_in + SK_BREAK_UNTIL;
        都没有 -> 只读 BREAK_READS 帧。有提示也等到 press_not_before 才按(别打断强化重击)。
        按到提示消失, 从生效那一下起等 BREAK_ANIM; 等完提示还在就再来一轮。返回处决了没有。"""
        ring = self.break_ring()
        armed = ring or seen_before
        deadline = t_in + self.SK_BREAK_UNTIL if armed else 0.0
        start = time.time()
        reads = 0
        while True:
            self.task.next_frame()
            if self.hud_ok() and self.break_prompt():
                break
            reads += 1
            if reads >= self.BREAK_READS and time.time() >= deadline:
                if armed:
                    self.macro_mark(f'{tag}处决提示没出来(圈{int(ring)},{time.time() - start:.2f}s)')
                    self.logger.info(f'{tag}: 外圈满着/切人前见过提示, 但 HUD 回来 {self.SK_BREAK_UNTIL:.1f}s 内'
                                     f'中间的 F 提示一直没出来(离怪太远/镜头没转回来?), 不处决')
                return False
            self.macro_wait(0.02)
        waited = time.time() - start
        self.wait_until_time(press_not_before)
        total = 0
        for rnd in range(self.BREAK_ROUNDS):
            hit_at, n = self.break_press(tag)
            total += n
            try:
                self.task.can_break = False
            except Exception:
                pass
            if hit_at is None:
                self.macro_mark(f'{tag}处决?(F x{total},提示一直在)')
                self.logger.warning(f'{tag}: 处决 F 按了 {total} 下提示一直没消失(一直被吞?), 不等了')
                return False
            self.wait_until_time(hit_at + self.BREAK_ANIM)
            self.wait_hud_up(cap=1.0, tag=f'{tag}处决后HUD')
            again = False
            for _ in range(2):
                self.task.next_frame()
                if self.hud_ok() and self.break_prompt():
                    again = True
                    break
            if not again:
                self.macro_mark(f'{tag}处决(F x{total},等提示{waited:.2f}s,圈{int(ring)}->{int(self.break_ring())})')
                return True
            self.macro_mark(f'{tag}处决没上(提示还在, 第{rnd + 2}轮)')
        self.logger.warning(f'{tag}: 处决按了 {self.BREAK_ROUNDS} 轮提示还在, 不等了')
        return False

    def seg_sk_la(self, sk, so, tag):
        """守岸人·循环第一截(心变奏进来, HUD 回来之后): 3A -> [QY: 回路满就强化重击] -> [有处决提示就处决] -> E
        -> 切锁暝(普通入场)。"""
        t_in = time.time()
        if not sk.has_intro:
            self.macro_mark(f'{tag}无变奏')
        seen = getattr(self, 'break_seen_at', None)
        seen_before = seen is not None and t_in - seen < self.BREAK_SEEN_FRESH
        self.break_seen_at = None
        self.macro_spam(self.SHORE_A3_WINDOW, self.A_INTERVAL, tag=f'{tag}3A')
        heavy_at = 0.0
        if self.LOOP_KIND == 'QY':
            self.task.next_frame()
            if self.sk_forte_full(sk):
                heavy_at = time.time()
                self.sk_heavy(sk, tag=f'{tag}强化重击')
            else:
                self.macro_mark(f'{tag}回路没满不重击')
        if self.SK_BREAK:
            self.sk_break(f'{tag}', t_in, seen_before,
                          press_not_before=heavy_at + self.SK_BREAK_AFTER_HEAVY if heavy_at else 0.0)
        if self.sk_e_ready(sk):
            if self.press_res_until_cd(sk, self.SK_LA_E_CAP, f'{tag}E', ready_grace=0.15):
                sk.record_resonance_use()
        else:
            self.macro_mark(f'{tag}E冷却中')
        self.need(self.switch_retry(so, f'{tag}切锁暝'), 'shorekeeper -> suoming')

    def seg_sk_lb(self, sk, so, tag):
        """守岸人·循环第二截。4A: 锁暝切回来 A 到回路满 -> 强化重击 -> Q -> R; QY: 心 3A 切回来, R 还差一点 CD 就边 A 边等,
        亮了 Q -> R。之后一样: 演完(R 前协奏够就演出里切) -> 协奏满变奏锁暝。
        第一个循环轴(L1)R 不回协奏(奇幻变奏 25s 冷却): 演完不读, 直接 A(回路满就强化重击)到协奏满再切。"""
        if self.LOOP_KIND == 'QY':
            self.wait_r_lit(sk, tag, self.SK_QY_R_WAIT_CAP, self.A_INTERVAL)
        else:
            self.sk_clear(sk, self.SK_L_FULL_CAP, tag)
        self.spam_key(sk.send_echo_key, self.SK_L_Q_WINDOW, tag=f'{tag}Q', presses=2)
        sk.record_echo_use()
        con_pre = self.read_con(1.0, settle=0.06)
        con_full = con_pre >= self.SK_R_EARLY_CON
        if self.ensure_r(sk, tag, self.SK_R_RESCUE, self.SK_R_ENSURE_CAP,
                         lambda rounds: self.sk_build_energy(sk, tag, rounds)):
            if con_full:
                gone_at = time.time()
                self.wait_until_time(gone_at + self.SK_R_SWITCH_FROM)
                self.macro_mark(f'{tag}R演出里切锁暝(R前协奏{con_pre:.2f})')
                ok = self.quick_switch(so, assume_con=True, time_out=self.SK_R_ANIM_CAP - self.SK_R_SWITCH_FROM)
                self.add_freeze_duration(gone_at, time.time() - gone_at)
                if ok:
                    return True
                self.wait_hud_up(cap=2.0, tag=f'{tag}演出里没切过去')
            else:
                self.macro_mark(f'{tag}R前协奏{con_pre:.2f}(不够, 等演完)')
                self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SK_R_ANIM_MIN, time_out=self.SK_R_ANIM_CAP)
                if self.SK_LB_L1_DIRECT_A and self.loop_count == 1:
                    self.macro_mark(f'{tag}R后直接A(第一圈武器没回协奏)')
                    return self.sk_hand_off(sk, so, tag, read=False)
        return self.sk_hand_off(sk, so, tag)

    # ==================== 心 ====================

    def xn_gauge(self):
        """应世心条 -> (左半, 右半) 有紫色的列占比。读当前帧, 调用方负责 next_frame。"""
        frame = self.task.frame
        out = []
        for x1, y1, x2, y2 in (self.XN_GAUGE_L, self.XN_GAUGE_R):
            box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
            if crop.size == 0:
                return 0.0, 0.0
            hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            purple = (h >= 125) & (h <= 160) & (sat >= 70) & (v >= 90)
            out.append(float(purple.any(axis=0).mean()))
        return out[0], out[1]

    def xn_ying(self):
        """应世心 -> (满没满, 左半紫, 右半紫)。满 = 重击位的花图标 hsin_h1; 没满时条是紫色格子。读当前帧。"""
        try:
            full = bool(self.task.find_one('hsin_h1', threshold=self.XN_FULL_THRESHOLD))
        except Exception:
            full = False
        L, R = self.xn_gauge()
        return full, L, R

    def xn_icon(self, name):
        """心技能栏的图标模板(hsin_lib1 = 转相 / hsin_lib2 = 万阙垂天解锁)。读当前帧。"""
        try:
            return bool(self.task.find_one(name, threshold=0.7))
        except Exception:
            return False

    def xn_attack_down(self):
        return self.attack_down(self.XN_HOLD_SENDINPUT and self.game_foreground())

    def xn_fill_until_ready(self, tag, not_before=0.0):
        """连续点普攻(XN1_TAP_EVERY 一下), 每帧读应世心条, 打满 XN1_MIN_A 下、到线、而且过了 not_before(墙钟)就返回。
        返回 'ready' 到线 / 'late' 到点差一点 / 'cap' 补到上限 / 'blind' 条读不出来。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hits = 0
        valid_seen = False
        last_r = 0.0
        trace = []
        while True:
            now = time.time()
            if now >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            el = time.time() - start
            if self.hud_ok():
                full, L, R = self.xn_ying()
                if len(trace) < 30:
                    trace.append(f'{el:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                if full or L >= self.XN_GAUGE_VALID:
                    valid_seen = True
                    last_r = 1.0 if full else R
                    hits = hits + 1 if (full or R >= self.XN_YING_READY) else 0
                    if taps >= self.XN1_MIN_A and hits >= self.XN1_GAUGE_CONFIRM and time.time() >= not_before:
                        self.macro_mark(f'{tag}应世心到线({R:.2f},A x{taps},{el:.2f}s)')
                        return 'ready'
                    if el >= self.XN1_LATE_AT and R >= self.XN_YING_LATE:
                        self.macro_mark(f'{tag}应世心将满({R:.2f},A x{taps},{el:.2f}s)')
                        return 'late'
            if el >= self.XN1_BLIND_AT and not valid_seen:
                self.macro_mark(f'{tag}应世心读不到(A x{taps}, 照按)')
                self.logger.info(f'{tag}: 应世心条读不出来 — {" ".join(trace)}')
                return 'blind'
            if el >= self.XN1_FILL_CAP:
                self.macro_mark(f'{tag}应世心不够(cap,{last_r:.2f},A x{taps})')
                self.logger.info(f'{tag}: 应世心补到上限还没到线 — {" ".join(trace)}')
                return 'cap'
            self.macro_wait(0.02)

    def xn1_entry_fill(self, xn, tag, sw):
        """心1 进场: 花图标(应世心满)连 2 帧就按住; 没亮就从 XN1_ENTRY_TAP_FROM 起点普攻补, 亮了再按住。"""
        self.wait_until_time(sw + self.XN1_FULL_FROM)
        tap_from = sw + self.XN1_ENTRY_TAP_FROM
        next_tap = tap_from
        taps = hits = 0
        valid_seen = False
        L = R = 0.0
        why = 'cap'
        while time.time() < tap_from + self.XN1_FILL_CAP:
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            ok = False
            if self.hud_ok() and self.so_on_field(xn):
                full, L, R = self.xn_ying()
                valid_seen = valid_seen or full or L >= self.XN_GAUGE_VALID
                ok = full
            hits = hits + 1 if ok else 0
            if hits >= 2:
                why = 'full'
                break
            if not valid_seen and time.time() >= tap_from + self.XN1_BLIND_AT:
                why = 'blind'
                break
            self.macro_wait(0.02)
        el = time.time() - sw
        if why == 'full' and taps == 0:
            self.macro_mark(f'{tag}上场应世心就满({el:.2f}s)')
            self.wait_until_time(sw + self.XN1_FULL_HOLD_AT)
        elif why == 'full':
            self.macro_mark(f'{tag}普攻补满应世心(A x{taps},{el:.2f}s)')
        else:
            self.macro_mark(f'{tag}应世心{"读不到" if why == "blind" else "不够"}(照按,{L:.2f}/{R:.2f},A x{taps},{el:.2f}s)')

    def xn_hold_burn(self, tag):
        """按住重击 XN1_HOLD 秒, 期间看应世心条有没有被清空(= 步红尘出手)。

        返回 (状态, 清空时刻, 按下时刻)。状态:
          'burned'  清空了(时刻可能是 None: 按住期间没读到那一帧, 松手后读到是空的)
          'full'    松手后条还在 = 出的是普通重击(条差太多/被打断) -> 调用方补 A 再按
          'unknown' 条一次都没读出来, 不知道 -> 不重按(重按落在步红尘演出里会再起一个重击)
        """
        si = self.xn_attack_down()
        start = time.time()
        press_at = start
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        seen_full = False
        burned_at = None
        low_at = None
        icon_since = None
        stale = 0
        lit_at_press = None
        lit_hits = 0
        trace = []
        try:
            while time.time() - press_at < self.XN1_HOLD:
                self.task.next_frame()
                if self.hud_ok() and burned_at is None:
                    now = time.time()
                    full, L, R = self.xn_ying()
                    if len(trace) < 30:
                        trace.append(f'{now - start:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                    if lit_at_press is None:
                        lit_at_press = full
                    lit_hits = lit_hits + 1 if full else 0
                    if not lit_at_press and lit_hits >= 2 and stale < self.XN1_STALE_MAX:
                        stale += 1
                        self.release_attack()
                        self.macro_wait(0.05)
                        self.xn_attack_down()
                        press_at = time.time()
                        lit_at_press = True
                        icon_since = None
                        self.macro_mark(f'{tag}按下后才满,重按({now - start:.2f}s)')
                        continue
                    icon_since = (icon_since or now) if full else None
                    if (full and stale < self.XN1_STALE_MAX and now - press_at >= self.XN1_STALE_MIN
                            and now - icon_since >= self.XN1_STALE_FULL):
                        stale += 1
                        self.release_attack()
                        self.macro_wait(0.05)
                        self.xn_attack_down()
                        press_at = time.time()
                        icon_since = None
                        self.macro_mark(f'{tag}满了没出,重按({now - start:.2f}s)')
                        continue
                    if full or L >= self.XN_GAUGE_VALID:
                        seen_full = True
                        low_at = None
                    elif seen_full and L < self.XN_CONSUMED:
                        # 连着两帧空才算(特效闪一下会压暗一帧); 时刻记第一帧 —— 转相解锁从这一刻算
                        if low_at is None:
                            low_at = now
                        else:
                            burned_at = low_at
                            self.macro_mark(f'{tag}步红尘出手({burned_at - start:.2f}s)')
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        if burned_at is not None:
            self.macro_mark(f'{tag}松开')
            return 'burned', burned_at, start
        # 按住期间没读到清空: 松手后再读两帧, 条还在 = 真没出步红尘
        full = empty = 0
        for _ in range(6):
            self.task.next_frame()
            if self.hud_ok():
                is_full, L, R = self.xn_ying()
                if is_full or L >= self.XN_GAUGE_VALID:
                    full += 1
                    seen_full = True
                elif seen_full and L < self.XN_CONSUMED:
                    empty += 1
                if full >= 2 or empty >= 2:
                    break
            self.macro_wait(0.02)
        state = 'full' if full >= 2 else ('burned' if empty >= 2 else 'unknown')
        self.macro_mark(f'{tag}松开({state})')
        self.logger.info(f'{tag}: 按住 {self.XN1_HOLD:.1f}s 没读到应世心清空 -> {state} — {" ".join(trace)}')
        return state, None, start

    def xn_r1_ready(self):
        """转相能不能按: R 图标是转相(hsin_lib1)而且亮着。读当前帧。

        不查 CD(check_cd=False): 那一路每换一帧就 OCR 一次技能栏, 解锁那 0.3s 的窗口里读不了几次; 转相也没有 CD 数字。
        """
        try:
            lit = bool(self.available('liberation', check_color=True, check_cd=False))
        except Exception:
            lit = False
        return lit and self.xn_icon('hsin_lib1')

    def seg_xn1(self, xn, so, tag):
        """心·第一段(变奏·应世相): 连续 A 到应世心到线(至少两下, 第二下往前冲的时候按住 = 预输入) -> 按住出步红尘
        -> 转相解锁 -> 转相 -> 演完 -> 同奏切锁暝。"""
        sw = self.switch_press_at
        if self.XN1_SKIP_A_WHEN_FULL:
            self.xn1_entry_fill(xn, tag, sw)
        else:
            self.wait_until_time(sw + self.XN1_A1_AT)
            self.xn_fill_until_ready(tag, not_before=sw + self.XN1_HOLD_NOT_BEFORE)

        state = 'unknown'
        hold_at = burned_at = None
        for attempt in range(1 + self.XN1_RETRIES):
            if attempt > 0:
                # 上一次松手后条还在 = 出的是普通重击: 花图标亮着就直接重按, 没亮补两下 A 再按
                self.task.next_frame()
                lit = self.hud_ok() and self.xn_ying()[0]
                if not lit:
                    for _ in range(self.XN1_RETRY_A):
                        self.tap(self.XN1_A_HOLD)
                        self.macro_wait(self.XN1_FILL_EVERY)
                self.macro_mark(f'{tag}重击重按#{attempt}{"(亮着)" if lit else ""}')
            state, burned_at, hold_at = self.xn_hold_burn(f'{tag}重击' if attempt == 0 else f'{tag}重击#{attempt}')
            if state != 'full':
                break
        fired = False
        if state == 'full':
            # 步红尘没出, 转相不会解锁, 连按 R 白等: 直接走补救
            self.logger.warning(f'{tag}: 重按 {self.XN1_RETRIES} 次应世心都没清空(步红尘没出), 转相多半放不出来')
        else:
            if self.XN1_ECHO:
                xn.send_echo_key(down_time=0.05)
                xn.record_echo_use()
                self.macro_wait(0.05)
            fired = self.fire_r(xn, f'{tag}转相', self.XN1_R1_SPAM)
            if fired and burned_at is not None:
                self.macro_mark(f'{tag}转相出手(清空后{time.time() - burned_at:.2f}s)')
        if not fired:
            fired = self.xn_r1_rescue(xn, tag)
        if not fired:
            self.logger.warning(f'{tag}: 补了 {self.XN1_R1_RESCUE_CAP:.0f}s 转相还是没放出去 — 锁暝拿不到同奏(进不了念深), 照常往下走')
        else:
            self.wait_hud_back(tag=f'{tag}转相演出', min_gone=self.XN_R_ANIM_MIN, time_out=self.XN_R_ANIM_CAP)
        # 同奏 5 秒: 转相一演完立刻切, 锁暝不用满协奏也是变奏入场(响应同奏 -> 锁妄念·同奏, 进念深)
        self.need(self.switch_retry(so, f'{tag}切锁暝', assume_con=fired), 'hsin -> suoming')
        return fired

    def seg_xn_mid(self, xn, sk, tag):
        """心·循环插段(QY, 锁暝切过来, 普通入场·应世相): 点 3 下普攻 -> [应世心左半不到线就多点一下] -> 切守(普通入场)。

        这几下攒应世心, 下一次心1 变奏进来少补几下 A。教学3 这里还要等守 R 转好, 我们守 R 一直是好的, 点完就切。
        """
        sw = self.switch_press_at
        self.wait_until_time(sw + self.XN_MID_A1_AT)
        start = time.time()
        taps = 0
        next_tap = 0.0
        while time.time() - start < self.XN_MID_TAP_UNTIL:
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN_MID_TAP_EVERY - self.XN1_A_HOLD)
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}3A(A x{taps})')
        self.wait_until_time(sw + self.XN_MID_SWITCH_AT)
        self.xn_mid_top_up(xn, tag)
        self.need(self.switch_retry(sk, f'{tag}切守'), 'hsin -> shorekeeper')

    def xn_mid_ying(self, xn):
        """插段: 连读 XN_MID_READS 帧应世心左半取最大; 一帧都读不到(HUD 不在/场上不是心)返回 None。"""
        best = None
        for _ in range(self.XN_MID_READS):
            self.task.next_frame()
            if self.hud_ok() and self.so_on_field(xn):
                L = self.xn_gauge()[0]
                best = L if best is None else max(best, L)
        return best

    def xn_mid_top_up(self, xn, tag):
        """插段切守前: 应世心左半不到 XN_MID_YING_MIN 就多点一下 A, 等它进条(或到线)再走。"""
        L0 = self.xn_mid_ying(xn)
        if L0 is None:
            self.macro_mark(f'{tag}应世心读不到(照切)')
            return
        if L0 >= self.XN_MID_YING_MIN:
            self.macro_mark(f'{tag}应世心{L0:.2f}')
            return
        tap_at = time.time()
        self.tap(self.XN1_A_HOLD)
        L = L0
        why = 'cap'
        while time.time() - tap_at < self.XN_MID_EXTRA_CAP:
            self.task.next_frame()
            if self.hud_ok() and self.so_on_field(xn):
                L = max(L, self.xn_gauge()[0])
            if L >= self.XN_MID_YING_MIN:
                why = '到线'
                break
            if L >= L0 + self.XN_MID_EXTRA_STEP and time.time() - tap_at >= self.XN_MID_EXTRA_MIN:
                why = '进条'
                break
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}应世心{L0:.2f}补A({why},{L:.2f},{time.time() - tap_at:.2f}s)')

    def xn_r1_rescue(self, xn, tag):
        """转相第一次没放出去: 补到放出去为止(上限 XN1_R1_RESCUE_CAP)。返回放出去没有。

        每一轮看现在卡在哪:
          转相图标亮着(连两帧)       -> 按 R(被吞了就再来)
          应世心是满的(花图标 / 右半到线) -> 再按住出步红尘, 清空后等解锁
          都不是                     -> 普攻攒应世心
          HUD 不在(被击飞/演出)       -> 等它回来
        一直既看不到转相图标也读不到应世心条 = 已经进照世相了(转相其实出了只是没看到演出), 不再按 R ——
        照世相里按 R 放的是借相。
        """
        start = time.time()
        rounds = 0
        lost = 0
        self.macro_mark(f'{tag}转相补救开始')
        while time.time() - start < self.XN1_R1_RESCUE_CAP:
            rounds += 1
            self.task.next_frame()
            if not self.hud_ok():
                self.wait_hud_up(cap=1.0, tag=f'{tag}转相补救等HUD')
                continue
            lit = 0
            for _ in range(self.XN1_R1_READS):
                if self.xn_r1_ready():
                    lit += 1
                self.task.next_frame()
            if lit >= self.XN1_R1_READS:
                lost = 0
                if self.fire_r(xn, f'{tag}转相补#{rounds}', self.XN_R_WINDOW):
                    self.macro_mark(f'{tag}转相补救成功({time.time() - start:.2f}s)')
                    return True
                continue
            full, L, R = self.xn_ying()
            if full or L >= self.XN_GAUGE_VALID or self.xn_icon('hsin_lib1'):
                lost = 0
            else:
                lost += 1
                if lost >= self.XN1_R1_LOST_ROUNDS:
                    self.macro_mark(f'{tag}转相补救: 已不在应世相(当转相出过了)')
                    return True
            if full or (L >= self.XN_GAUGE_VALID and R >= self.XN_YING_READY):
                state, burned_at, _hold_at = self.xn_hold_burn(f'{tag}补步红尘#{rounds}')
                if state == 'burned':
                    # 清空后 2.06s 解锁: 等到点(期间亮了就提前走), 下一轮去按
                    anchor = burned_at if burned_at is not None else time.time() - 0.3
                    due = anchor + self.XN1_R1_UNLOCK + self.XN1_R1_MARGIN
                    while time.time() < due:
                        self.task.next_frame()
                        if self.hud_ok() and self.xn_r1_ready():
                            break
                        self.macro_wait(0.01)
                continue
            self.macro_spam(self.XN1_R1_RESCUE_A, self.XN1_FILL_EVERY, tag=f'{tag}补应世心A#{rounds}')
        self.macro_mark(f'{tag}转相补救(cap,{rounds}轮)')
        return False

    def xn_hold_until_gone(self, cap, tag, watch_ready=False, stall=None):
        """按住左键到队伍 HUD 消失(临寰宇出手)。消失后再按 XN2_RELEASE_AFTER_GONE 秒松手。返回出手没有。

        watch_ready: 按住期间看重击位, 人像出来 XN2_READY_REPRESS 还没出手 = 这一下按住断了(被打断), 松开重按。
        stall: 按住期间数雕像, 这么多秒没再翻一颗也没出手就松手返回(交给调用方普攻补完再按)。
        """
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        gone = 0
        fired = False
        ready_since = None
        repress = 0
        last_count = None
        moved_at = start
        try:
            while time.time() - start < cap:
                self.task.next_frame()
                if not self.hud_ok():
                    gone += 1
                    if gone >= self.LIB_GONE_CONFIRM:
                        fired = True
                        break
                else:
                    gone = 0
                    if stall is not None:
                        try:
                            count = self.xn_statue_count()
                        except Exception as e:
                            count = last_count
                            self.logger.info(f'xn_statue_count failed ({e})')
                        if count != last_count:
                            last_count = count
                            moved_at = time.time()
                        elif time.time() - moved_at >= stall:
                            self.macro_mark(f'{tag}停在{count}颗({time.time() - start:.2f}s)')
                            break
                    if watch_ready and repress < self.XN2_REPRESS_MAX:
                        if self.xn_slot_state() == 'ready':
                            ready_since = ready_since or time.time()
                            if time.time() - ready_since >= self.XN2_READY_REPRESS:
                                repress += 1
                                ready_since = None
                                self.release_attack()
                                self.macro_wait(0.05)
                                self.xn_attack_down()
                                self.macro_mark(f'{tag}人像出来没出手,重按#{repress}({time.time() - start:.2f}s)')
                        else:
                            ready_since = None
                self.macro_wait(0.02)
            if fired:
                self.macro_mark(f'{tag}临寰宇出手({time.time() - start:.2f}s)')
                self.macro_wait(self.XN2_RELEASE_AFTER_GONE)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}松开({"出手" if fired else "没出"})')
        return fired

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def xn_slot_glyph(self):
        """重击位 16x16 灰度(只取圆内像素), 已归一化。心不在场/HUD 不在返回 None。读当前帧。"""
        in_team, index, _count = self.task.in_team()
        if not in_team or index != self.index:
            return None
        self.hud_seen_at = time.time()
        ref = getattr(self, '_slot_ref', None)
        if ref is None:
            yy, xx = np.mgrid[:96, :96]
            disk = ((((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2)).astype(np.float32)
            mask = cv2.resize(disk[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA) > 0.99

            def tpl(chunks):
                raw = base64.b64decode(''.join(chunks))
                return self.glyph_vec(np.frombuffer(raw, np.uint8).reshape(16, 16).astype(np.float32)[mask])

            ref = self._slot_ref = (mask, disk, tpl(self.XN_TY_GLYPH), tpl(self.XN_READY_GLYPH))
        mask, disk, _ty, _rd = ref
        x, y, w, h = self.XN_TY_SLOT
        box = self.task.box_of_screen_scaled(3840, 2160, x, y, x + w, y + h, hcenter=True)
        frame = self.task.frame
        cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
        half = int(box.height * 1.1)
        icon = frame[max(0, cy - half):cy + half, max(0, cx - half):cx + half, :3]
        g = cv2.cvtColor(cv2.resize(icon, (96, 96), interpolation=cv2.INTER_AREA),
                         cv2.COLOR_BGR2GRAY).astype(np.float32) * disk
        v = cv2.resize(g[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA)
        return self.glyph_vec(v[mask])

    def xn_slot_state(self):
        """统御众机里重击位: 'statue'(照世心还没打空) / 'ready'(人像, 临寰宇可按) / '?' / None(HUD 不在)。读当前帧。"""
        try:
            v = self.xn_slot_glyph()
            if v is None:
                return None
            _mask, _disk, ty, rd = self._slot_ref
            self._ty_score = float(v @ ty)
            self._rd_score = float(v @ rd)
            if self._rd_score >= self.XN_READY_MIN:
                return 'ready'
            if self._ty_score >= self.XN_TY_MIN:
                return 'statue'
            return '?'
        except Exception as e:
            self.logger.info(f'xn_slot_state probe failed ({e})')
            return '?'

    def dodge(self, tag):
        """闪避(右键)。"""
        self.task.mouse_down(key='right')
        try:
            self.macro_wait(self.XN2_DODGE_HOLD)
        finally:
            self.task.mouse_up(key='right')
        self.macro_mark(f'{tag}闪避')

    def xn_statue_reset(self):
        self._statue_streak = [0] * len(self.XN_STATUE_XS)
        self._statue_latch = [False] * len(self.XN_STATUE_XS)

    def xn_statue_count(self):
        """照世心雕像从右往左连续翻了几颗(翻过的记住, 每次进统御众机先 xn_statue_reset)。读当前帧。
        照抄心雷穗 v1.1.0, 加了一条: 同一帧新记住 >= XN_STATUE_BURST 颗 = 闪光, 这一帧不算。"""
        frame = self.task.frame
        hw = self.XN_STATUE_HW
        newly = []
        for k, x in enumerate(self.XN_STATUE_XS):
            if self._statue_latch[k]:
                continue
            red = glow = 0.0
            for y, kind in ((self.XN_STATUE_Y, 'red'), (self.XN_STATUE_UP_Y, 'glow')):
                box = self.task.box_of_screen_scaled(3840, 2160, x - hw, y - hw, x + hw, y + hw, hcenter=True)
                crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
                if crop.size == 0:
                    continue
                hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
                h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                if kind == 'red':
                    red = float((((h < 12) | (h > 160)) & (sat > 90) & (v > 110)).mean())
                else:
                    glow = float(((v > 235) & (sat < 60)).mean())
            hit = red >= self.XN_STATUE_RED or glow >= self.XN_STATUE_GLOW
            self._statue_streak[k] = self._statue_streak[k] + 1 if hit else 0
            if self._statue_streak[k] >= self.XN_STATUE_CONFIRM:
                newly.append(k)
        if len(newly) >= self.XN_STATUE_BURST:
            for k in newly:
                self._statue_streak[k] = 0
        else:
            for k in newly:
                self._statue_latch[k] = True
        n = 0
        for latched in reversed(self._statue_latch):
            if not latched:
                break
            n += 1
        return n

    def xn_ty_attack(self, tag, start, until_count, min_t, cap_t, every=None):
        """统御众机里点普攻(every 一下, 默认 XN2_TY_A_EVERY), 每帧数雕像、看重击位。时间从 start 起算:
        min_t 之前不停; 翻满 until_count 颗(或人像出来)就停; 到 cap_t 照停。返回 (原因, 翻了几颗)。"""
        every = self.XN2_TY_A_EVERY if every is None else every
        n = 0
        next_click = 0.0
        count = 0
        ready_hits = 0
        counts = []
        last_count = -1
        why = 'cap'
        while time.time() - start < cap_t:
            if time.time() >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, every - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            if st is not None:
                try:
                    count = self.xn_statue_count()
                except Exception as e:
                    self.logger.info(f'xn_statue_count failed ({e})')
                if count != last_count:
                    last_count = count
                    if len(counts) < 12:
                        counts.append(f'{count}@{time.time() - start:.2f}')
            ready_hits = ready_hits + 1 if st == 'ready' else 0
            if ready_hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            if count >= until_count and time.time() - start >= min_t:
                why = 'count'
                break
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}(A x{n},翻{count},{why},{time.time() - start:.2f}s)')
        if counts:
            self.logger.info(f'{tag}: 照世心雕像翻面(颗@秒) — {" ".join(counts)}')
        return why, count

    def xn_tongyu_phase(self, tag, cap):
        """统御众机里一直普攻到重击位换成人像(照世心打空)。返回 'ready'(人像连读几帧) / 'cap'(到上限没看到人像)。"""
        start = time.time()
        n = 0
        next_click = 0.0
        hits = 0
        why = 'cap'
        last = None
        statue_seen = False
        while time.time() - start < cap:
            now = time.time()
            if now >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, self.XN2_TY_A_EVERY - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            last = st
            statue_seen = statue_seen or st == 'statue'
            hits = hits + 1 if st == 'ready' else 0
            if hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}照世心{"打空" if why == "ready" else "没看到打空(cap)"}'
                        f'(A x{n},{time.time() - start:.2f}s{"" if statue_seen else ",没见过雕像"})')
        if why != 'ready':
            self.logger.info(f'{tag}: {cap:.1f}s 没看到重击位换人像(最后读成 {last}, '
                             f'雕像{getattr(self, "_ty_score", -1):.2f} 人像{getattr(self, "_rd_score", -1):.2f})')
        return why

    def seg_xn2(self, xn, intro, tag, opener=False):
        """心·第二段(变奏·照世相, 直接进统御众机): 普攻到第 1 颗雕像翻面(A1 落下) -> 接着点到第 2 颗(A2 楼阁打中)
        -> 闪避 -> 普攻到第 7 颗 -> 按住到临寰宇(雕像停住/按住断了就松开补普攻再按) -> 演完 -> Q
        -> 万阙垂天(认 hsin_lib2) -> [演出快完按住普攻、按过白屏时停 -> 重击] -> [E] -> 协奏补满(交棒给调用方)。"""
        heavy = self.XN2_R2_HEAVY_OPENER if opener else self.XN2_R2_HEAVY
        self.wait_until_time(self.switch_press_at + self.XN2_LEAD)
        self.xn_statue_reset()
        why, count = self.xn_ty_attack(f'{tag}A1', time.time(), 1, self.XN2_DODGE_MIN, self.XN2_DODGE_CAP)
        if why == 'count':
            why, count = self.xn_ty_attack(f'{tag}A2', time.time(), self.XN2_DODGE_COUNT, 0.0,
                                           self.XN2_DODGE_AFTER)
        if why != 'ready':
            self.dodge(tag)
            self.macro_wait(self.XN2_DODGE_TO_A)
            self.xn_ty_attack(f'{tag}3A', time.time(), self.XN2_HOLD_AT, 0.0, self.XN2_EMPTY_CAP,
                              every=self.XN2_POST_DODGE_A_EVERY)
        fired = self.xn_hold_until_gone(self.XN2_HOLD_CAP, f'{tag}按住', watch_ready=True,
                                        stall=self.XN2_HOLD_STALL)
        for attempt in range(1, 1 + self.XN2_RETRIES):
            if fired:
                break
            # 按满上限没出(照世心没打空 / 被打断): 普攻到人像再按。没拿到变奏(没进统御众机)时先按一下 E
            if attempt == 1 and not intro:
                self.spam_key(xn.send_resonance_key, 0.2, interval=0.06, tag=f'{tag}补E(没变奏)')
                xn.record_resonance_use()
            why = self.xn_tongyu_phase(f'{tag}补#{attempt}', self.XN2_RETRY_CAP)
            fired = self.xn_hold_until_gone(self.XN2_READY_HOLD if why == 'ready' else self.XN2_BLIND_HOLD,
                                            f'{tag}重按#{attempt}', watch_ready=True)
        if not fired:
            self.logger.warning(f'{tag}: 临寰宇一直没出手, 这一轮不放万阙垂天(按 R 会放成借相)')
        else:
            self.wait_hud_back(tag=f'{tag}临寰宇演出', min_gone=self.XN2_ANIM_MIN, time_out=self.XN2_ANIM_CAP)
            if self.XN2_R2_BLIND:
                unlocked = True
            else:
                # 【R 只认 hsin_lib2】: 照世相里 R 一直亮(借相·应世), 只有临寰宇之后、能量够了才换成万阙垂天的图标
                unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
                self.macro_mark(f'{tag}万阙垂天{"解锁" if unlocked else "图标没认出(能量不够?)"}({t:.2f}s)')
                if not unlocked:
                    unlocked, t = self.xn_wait_lib2(self.XN2_R2_BUILD_CAP, build=True)
                    self.macro_mark(f'{tag}普攻攒大招能量({"认出万阙垂天" if unlocked else "cap"},{t:.2f}s)')
            fired = False
            wave = True
            for attempt in range(2):
                if not unlocked:
                    break
                if attempt == 0:
                    if self.XN2_PRE_R2:
                        self.xn_pre_r2_con(tag)
                    if self.XN2_ECHO:
                        xn.send_echo_key(down_time=0.05)
                        xn.record_echo_use()
                        self.macro_wait(0.05)
                fired = self.fire_r(xn, f'{tag}万阙垂天' if attempt == 0 else f'{tag}万阙垂天重按', self.XN_R_WINDOW)
                if fired:
                    self.wait_hud_back(tag=f'{tag}万阙垂天演出', min_gone=self.XN_R_ANIM_MIN,
                                       time_out=self.XN_R_ANIM_CAP,
                                       hold_from=self.XN2_R2_HOLD_FROM if heavy else None)
                    back_at = time.time()
                    if heavy and not self.holding_attack:
                        self.xn_attack_down()
                        self.macro_mark(f'{tag}大招后才按住')
                    thaw_at = back_at + self.XN2_R2_FREEZE
                    if self.XN2_R2_WAVE_WAIT and not self.xn_r2_target(tag, back_at):
                        self.release_attack()
                        wave = self.xn_wait_wave(tag)
                        if wave and heavy:
                            self.wait_until_time(thaw_at)
                            self.xn_attack_down()
                            self.macro_wait(self.XN2_R2_FRESH_HOLD)
                            self.release_attack()
                            self.macro_mark(f'{tag}新怪重击松开({self.XN2_R2_FRESH_HOLD:.2f}s)')
                            self.macro_wait(self.XN2_R2_FRESH_E_AT)
                    elif heavy:
                        self.wait_until_time(thaw_at + self.XN2_R2_HEAVY_HOLD)
                        self.release_attack()
                        self.macro_mark(f'{tag}大招后重击松开(解冻+{self.XN2_R2_HEAVY_HOLD:.2f}s)')
                        self.wait_until_time(thaw_at + self.XN2_R2_E_AT)
                    break
                # 没放出去: 认一下 R 位还是不是万阙垂天, 认得出才重按。盲按没出多半是能量不够、已经放成借相
                # 切回应世相了, 不攒(攒也认不出); 认图标那条路是收招吞了 / 能量差一点, 普攻攒一下
                if self.XN2_R2_BLIND:
                    unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
                else:
                    unlocked, t = self.xn_wait_lib2(1.50, build=True)
            if not fired:
                self.logger.warning(f'{tag}: 万阙垂天没放出去'
                                    f'({"能量攒不满/图标没认出, 不照按(会放成借相)" if not unlocked else "按了没出"})')
            elif not wave:
                self.macro_mark(f'{tag}没等到新怪(不重击不E)')
            elif self.XN2_E_AFTER_R2 and time.time() - getattr(xn, 'last_res', 0) >= self.XN_E_CD:
                if self.press_res_until_cd(xn, self.XN2_E_CAP, f'{tag}E偷伤害', ready_grace=0.15):
                    xn.record_resonance_use()
            if fired and heavy and self.XN2_TAIL_A:
                self.xn_tail_ying(tag, back_at)
        self.xn_ensure_con(xn, tag)

    def target_visible(self):
        """锁定目标在不在。照 CombatCheck.has_target() 的读框, 去掉它最后那个兜底分支 ——
        那个分支会 sleep(1) 再连按两次 ESC, 不能在轴里调(同心卜穗/绯洛穗)。"""
        t = self.task
        try:
            has_name, no_name = t.get_target_names()
            scale = 1.2 if t.is_browser() else 1.1
            for box in (t.get_box_by_name(has_name).scale(scale), t.get_box_by_name('box_target_enemy_long'),
                        t.get_box_by_name('target_box_long2')):
                best = t.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception as e:
            # 别的 工具 版本这几个读框/方法可能改名了: 当成有怪, 退回"不等新怪、照常重击 + E"
            if not getattr(self, '_target_visible_warned', False):
                self._target_visible_warned = True
                self.logger.warning(f'xss target_visible unsupported in this 工具 version ({e!r}), assuming a target is there')
            return True
        return False

    def xn_enemy_here(self):
        """场上有没有怪: Boss 破盾/锁图标、怪物血条(框架 check_health_bar 那两个)、锁定目标, 任一个读到就算有。
        【锁定目标不够用】22:30 录屏(Boss 挑战)target_visible 和框架 has_target 整局都是 False;
        Boss 在场 is_boss/has_health_bar 读得到(白屏时停里也读得到), 换波空场两个都是 False(按战斗中的血条宽度也没误报)。"""
        t = self.task
        try:
            if t.is_boss() or t.has_health_bar():
                return True
        except Exception as e:
            if not getattr(self, '_health_bar_warned', False):
                self._health_bar_warned = True
                self.logger.warning(f'xss is_boss/has_health_bar unsupported in this 工具 version ({e!r})')
        return self.target_visible()

    def xn_r2_target(self, tag, back_at):
        """万阙垂天 HUD 回来后的时停里看有没有怪: 读到一帧就算有。到 XN2_R2_TARGET_BY 一帧都没读到、
        且读够 TARGET_GONE_CONFIRM 帧 = 没怪; 帧数不够(卡帧)当有怪, 退回原来的预按住重击。"""
        gone = 0
        while time.time() < back_at + self.XN2_R2_TARGET_BY:
            self.task.next_frame()
            if self.xn_enemy_here():
                return True
            gone += 1
        if gone < self.TARGET_GONE_CONFIRM:
            return True
        self.macro_mark(f'{tag}时停里没怪(松手等新一波, {gone}帧)')
        return False

    def xn_wait_wave(self, tag):
        """没怪: 不点普攻(空挥), 每 WAVE_LOCK_INTERVAL 按中键, 连 ENEMY_CONFIRM 帧读到怪就返回 True, 上限 XN2_WAVE_WAIT。"""
        start = time.time()
        next_mid = 0.0
        hits = 0
        while time.time() - start < self.XN2_WAVE_WAIT:
            self.task.next_frame()
            self.hud_ok()
            hits = hits + 1 if self.xn_enemy_here() else 0
            if hits >= self.ENEMY_CONFIRM:
                self.macro_mark(f'{tag}等到新一波({time.time() - start:.2f}s)')
                return True
            if time.time() >= next_mid:
                self.task.middle_click()
                next_mid = time.time() + self.WAVE_LOCK_INTERVAL
            self.macro_wait(0.05)
        self.macro_mark(f'{tag}{self.XN2_WAVE_WAIT:.0f}s没等到新怪')
        return False

    def xn_tail_ying(self, tag, back_at):
        """万阙垂天之后(回到应世相): 普攻到应世心左半 >= XN2_TAIL_YING 再交棒, 上限从 HUD 回来起 XN2_TAIL_CAP。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hits = 0
        L = 0.0
        while time.time() < back_at + self.XN2_TAIL_CAP:
            self.task.next_frame()
            if self.hud_ok():
                full, L, R = self.xn_ying()
                hits = hits + 1 if (full or L >= self.XN2_TAIL_YING) else 0
                if hits >= 2:
                    self.macro_mark(f'{tag}收尾应世心({L:.2f},A x{taps},{time.time() - start:.2f}s)')
                    return True
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}收尾应世心(cap,{L:.2f},A x{taps})')
        return False

    def xn_wait_lib2(self, cap, build=False):
        """等 R 位变成万阙垂天(hsin_lib2 连读几帧)。build: 期间点普攻攒大招能量。返回 (认出没有, 用时)。"""
        start = time.time()
        hits = 0
        next_tap = 0.0
        while time.time() - start < cap:
            if build and time.time() >= next_tap:
                self.tap()
                next_tap = time.time() + max(0.0, self.A_INTERVAL - self.A_TAP)
            self.task.next_frame()
            if self.hud_ok():
                hits = hits + 1 if self.xn_icon('hsin_lib2') else 0
                if hits >= self.XN2_LIB2_READS:
                    return True, time.time() - start
            self.macro_wait(0.02)
        return False, time.time() - start

    def xn_pre_r2_con(self, tag):
        """万阙垂天之前: 协奏低于 XN2_PRE_R2_CON 就照世相普攻补(人还贴着怪), 每下之后读一次。"""
        start = time.time()
        con = self.read_con(1.0, settle=0.12)
        if con >= self.XN2_PRE_R2_CON:
            self.macro_mark(f'{tag}开大前协奏{con:.2f}')
            return
        samples = [f'0:{con:.2f}']
        taps = 0
        while time.time() - start < self.XN2_PRE_R2_CAP:
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            con = self.read_con(1.0, settle=0.03)
            if len(samples) < 20:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= self.XN2_PRE_R2_CON:
                break
        self.macro_mark(f'{tag}开大前补协奏({con:.2f},A x{taps},{time.time() - start:.2f}s)')
        if con < self.XN2_PRE_R2_CON:
            self.logger.info(f'{tag}: 开大前协奏补不到 {self.XN2_PRE_R2_CON:.2f} — {" ".join(samples)}')

    def xn_ensure_con(self, xn, tag):
        """心切守之前协奏要真满: 读一下, 不满就 E -> 普攻, 每下之后读一次。返回满没满。"""
        start = time.time()
        if self.con_ready(xn, self.XN2_CON_READ):
            return True
        samples = [f'0:{self.con_last:.2f}']
        taps = 0
        used_e = False
        while time.time() - start < self.XN2_CON_CAP:
            if not used_e and time.time() - getattr(xn, 'last_res', 0) >= self.XN_E_CD:
                used_e = True
                self.spam_key(xn.send_resonance_key, 0.26, interval=0.06, tag=f'{tag}补协奏E')
                xn.record_resonance_use()
            else:
                self.tap()
                taps += 1
                self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            full = self.con_ready(xn, 0.03)
            if len(samples) < 20:
                samples.append(f'{time.time() - start:.2f}:{self.con_last:.2f}')
            if full:
                self.macro_mark(f'{tag}补协奏(满,E{int(used_e)},A x{taps},{time.time() - start:.2f}s)')
                return True
        self.macro_mark(f'{tag}补协奏(cap,E{int(used_e)},A x{taps},{time.time() - start:.2f}s)')
        self.logger.warning(f'{tag}: 心补了 {time.time() - start:.1f}s 协奏还是没满, 守岸人拿不到变奏'
                            f' — {" ".join(samples)}')
        return False

    # ==================== 锁暝 ====================

    def so_wz(self):
        """妄执条 -> 两半有粉紫的列占比的平均(0~1)。读当前帧。跟心的应世心条同一个框, 只换颜色。"""
        frame = self.task.frame
        out = []
        h1, h2 = self.SO_WZ_HUE
        for x1, y1, x2, y2 in (self.XN_GAUGE_L, self.XN_GAUGE_R):
            box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
            if crop.size == 0:
                return 0.0
            hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            pink = (h >= h1) & (h <= h2) & (sat >= self.SO_WZ_SAT) & (v >= self.SO_WZ_VAL)
            out.append(float(pink.any(axis=0).mean()))
        return (out[0] + out[1]) / 2

    def so_forte_full(self, so):
        """妄执满(E 位是锁妄念/无舍念, 框架的 suoming_forte_e 模板)。读当前帧。"""
        try:
            return bool(so.forte_available())
        except Exception:
            return False

    def so_build_energy(self, so, tag, rounds):
        """锁暝 R 不亮时攒一轮: 妄执满了先按 E(念起时是锁妄念 = 进念深, 念深才解锁 R), 否则普攻一小段。"""
        self.task.next_frame()
        if self.so_forte_full(so):
            self.spam_key(so.send_resonance_key, 0.20, interval=0.06, tag=f'{tag}攒R:E#{rounds}')
            so.record_resonance_use()
        else:
            self.macro_spam(self.R_BUILD_SLICE, self.A_INTERVAL, tag=f'{tag}攒R:A#{rounds}')

    def so_on_field(self, so):
        """队伍 HUD 在场而且当前是 so(锁暝/谁都行; 刚切人那几帧技能栏还是上一个人的)。读当前帧。"""
        try:
            in_team, index, _count = self.task.in_team()
        except Exception:
            return False
        return bool(in_team) and index == so.index

    def so_wait_r_lit(self, so, tag):
        self.wait_r_lit(so, tag, self.SO_R_WAIT_CAP, self.SO_A_EVERY)

    def wait_r_lit(self, char, tag, cap, every):
        """R 还在 CD 上就边点普攻边每帧看, 连 2 帧亮了马上走(交给 ensure_r 按)。一进来就亮不点。
        只在读到"不亮"之后才点 A: 原来第一帧没凑够 2 帧就先点了一下(每次 A x1), 守b 多出一段普攻动作才 Q/R。"""
        start = time.time()
        taps = hits = 0
        next_tap = 0.0
        lit = False
        while time.time() - start < cap:
            self.task.next_frame()
            not_ready = False
            if self.so_on_field(char):
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                hits = hits + 1 if ready else 0
                if hits >= 2:
                    lit = True
                    break
                not_ready = not ready
            if not_ready and time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, every - self.A_TAP)
            self.macro_wait(0.01)
        if taps:
            self.macro_mark(f'{tag}等R亮({"亮" if lit else "cap"},A x{taps},{time.time() - start:.2f}s)')
        return lit

    def so_echo(self, so, tag):
        """一直按 Q 到声骸 CD 涨上来(比按之前高 SO_ECHO_RISE, 连 2 帧)。返回放出去没有。"""
        cd0 = self.read_cd('echo', so)
        start = time.time()
        n = hits = 0
        fired = False
        while time.time() - start < self.SO_ECHO_CAP:
            so.send_echo_key()
            n += 1
            self.task.next_frame()
            up = self.so_on_field(so) and self.read_cd('echo', so) > cd0 + self.SO_ECHO_RISE
            hits = hits + 1 if up else 0
            if hits >= 2:
                fired = True
                break
            self.macro_wait(0.06)
        if fired:
            so.record_echo_use()
        else:
            self.logger.info(f'{tag}: 按了 {n} 下声骸 CD 没涨(基线 {cd0:.1f}s) — 被收招吞了, 还是读不到数?')
        self.macro_mark(f'{tag}({"出" if fired else "cap"},x{n},{time.time() - start:.2f}s)')
        return fired

    def seg_so_r(self, so, xn, tag):
        """锁暝·第一次上场(响应同奏变奏, 进念深): R -> 演完 -> [Q(暗鸟), SO_ECHO_IN_KX 关时] -> 马上同奏切心。
        返回心带不带变奏(R 出没出)。

        R 给锁暝 5s 同奏: 带着同奏切走, 心变奏·照世相直接进统御众机, 锁暝放延奏。所以演完不能再干别的。
        """
        self.wait_until_time(self.switch_press_at + self.SO_R_LEAD)
        self.so_wait_r_lit(so, tag)
        fired = self.ensure_r(so, tag, self.SO_R_WINDOW, self.SO_R_ENSURE_CAP,
                              lambda rounds: self.so_build_energy(so, tag, rounds))
        if fired:
            self.so_tongzou_at = time.time()
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SO_R_ANIM_MIN, time_out=self.SO_R_ANIM_CAP)
        else:
            self.logger.warning(f'{tag}: 锁暝 R 没放出去(能量不够 / 没进念深) — 心拿不到同奏, 第二段走补救')
        if not self.SO_ECHO_IN_KX:
            self.so_echo(so, f'{tag}Q暗鸟')
        full = fired
        if not fired:
            full = self.read_con(1.0, settle=0.15) >= 1.0
        self.need(self.switch_retry(xn, f'{tag}切心', assume_con=full), 'suoming -> hsin')
        return full

    def so_4a_round(self, so, tag, stop=None):
        """一轮解伞形 4 段: 点到 SO_4A_TAP_UNTIL, 按住到 SO_4A_HOLD_UNTIL(都从第一下 A 起)。
        stop: 每帧看一次, 成立就提前收手(补妄执时用: 妄执一满就走)。返回 (提前收手没有, 耗时)。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hit = False
        while time.time() - start < self.SO_4A_TAP_UNTIL:
            if time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.SO_A_EVERY - self.A_TAP)
            if stop is not None:
                self.task.next_frame()
                if stop():
                    hit = True
                    break
            self.macro_wait(0.01)
        si = False
        if not hit:
            si = self.xn_attack_down()
            try:
                while time.time() - start < self.SO_4A_HOLD_UNTIL:
                    if stop is not None:
                        self.task.next_frame()
                        if stop():
                            hit = True
                            break
                    self.macro_wait(0.02)
            finally:
                self.release_attack()
        self.macro_mark(f'{tag}(A x{taps}{"+按住A4" + ("SI" if si else "PM") if not hit else ""},'
                        f'{"妄执满" if hit else "打完"},{time.time() - start:.2f}s)')
        return hit, time.time() - start

    def so_wz_settled(self, so, frames=5):
        """连读几帧妄执条取中位数(单帧会被特效染粉/闪白)。锁暝不在场返回 -1。"""
        vals = []
        for _ in range(frames * 2):
            self.task.next_frame()
            if self.so_on_field(so):
                vals.append(self.so_wz())
                if len(vals) >= frames:
                    break
            self.macro_wait(0.02)
        if not vals:
            return -1.0
        vals.sort()
        return vals[len(vals) // 2]

    def seg_so_4a(self, so, sk, tag):
        """锁暝·循环第一截(普通入场, 念深): 点 A1~A3 -> 按住出 A4 -> 松手 -> A4 冲刺那下妄执到账就切守(收尾后台打完)。

        为什么是完整 4 段: 解伞形 4 段打满妄执 ~600, 守开 R 满协奏后锁暝变奏碎霆 +200 = 800, 一进场 E 就是无舍念。
        A4 要在 A3 之后按住普攻(A2 之后按住是旋雷破), 所以前面只点、到 A3 出手之后才按住; A4 出手就松开,
        按着不放会接下一段把 A4 收尾顶掉。按段的时间点走。

        【被打断保底, 现在 SO_4A_REDO_MAX=0 关着】: 打完连读几帧妄执条取中位数, 明显不够(< SO_4A_REDO_BELOW, 正常打完 0.61~0.74)
        = 这一轮被怪打断/打空了, 再打一轮。条读数被特效染粉只会偏高, 所以低读数是可信的; 偏高漏判的交给锁b 的补妄执。
        """
        sw = self.switch_press_at
        self.wait_until_time(sw + self.SO_A_LEAD)
        first_a = time.time()
        self.so_4a_round(so, f'{tag}4A')
        self.wait_until_time(first_a + self.SO_4A_SWITCH_AT)
        for attempt in range(1, 1 + self.SO_4A_REDO_MAX):
            wz = self.so_wz_settled(so)
            if wz < 0 or wz >= self.SO_4A_REDO_BELOW:
                self.macro_mark(f'{tag}妄执条{wz:.2f}')
                break
            self.macro_mark(f'{tag}妄执条{wz:.2f}偏低(被打断?),再打#{attempt}')
            self.so_4a_round(so, f'{tag}4A补#{attempt}')
        self.need(self.switch_retry(sk, f'{tag}切守'), 'suoming -> shorekeeper')

    def so_tap_a_until(self, start, until, tag):
        """从 start 起每 SO_A_EVERY 点一下普攻, 点到 start + until(墙钟)。只点不按住(A2 之后按住是旋雷破)。"""
        taps = 0
        next_tap = 0.0
        while time.time() - start < until:
            if time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}(A x{taps})')

    def seg_so_a2(self, so, xn, tag):
        """锁暝·循环第一截(QY, 守 3A-E 切过来, 普通入场, 念深): 点出 A1A2 -> 闪避 -> 点出 A1A2 -> 切心(普通入场)。

        解伞形 A1A2 两段是攒妄执最快的(进场 ~1.2s 填满条左半), 闪避把连段重置回 A1 再来一遍, 不打慢的 A3/A4。
        教学3 切走时妄执条右半 0.76(4A 版 0.64), 守 R 后碎霆 +200 照样满。按段的时间点走, 不读条(特效会染粉)。
        """
        sw = self.switch_press_at
        self.wait_until_time(sw + self.SO_A_LEAD)
        first_a = time.time()
        self.so_tap_a_until(first_a, self.SO_QY_TAP1_UNTIL, f'{tag}A1A2')
        self.wait_until_time(first_a + self.SO_QY_DODGE_AT)
        self.dodge(tag)
        dodged = time.time()
        self.wait_until_time(dodged + self.SO_QY_TAP2_FROM)
        self.so_tap_a_until(dodged, self.SO_QY_TAP2_UNTIL, f'{tag}闪后A1A2')
        self.wait_until_time(dodged + self.SO_QY_SWITCH_AT)
        self.need(self.switch_retry(xn, f'{tag}切心'), 'suoming -> hsin')

    def so_tap_e(self, key):
        """点一下 E, 真的按住 SO_KX_E_TAP 秒。"""
        self.task.send_key_down(key)
        try:
            self.macro_wait(self.SO_KX_E_TAP)
        finally:
            self.task.send_key_up(key)

    def so_kx_taps(self, so, tag):
        """点 E 出无舍念 -> 点 A 出刻心念(不按住, 转圈最短) -> 不按键等协奏真满。返回协奏满没满。

        E 只在 E 位还是无舍念时点(刻心念收完 E 是破隙)。无舍念"出了"是读到的, 万一读错: 点 A 那段里
        E 位又连 2 帧是无舍念就改点 E。
        """
        key = so.get_resonance_key()
        start = time.time()
        e_taps = gone = 0
        next_e = 0.0
        out = False
        while time.time() - start < self.SO_KX_WUSE_CAP:
            self.task.next_frame()
            if self.so_on_field(so):
                if self.so_forte_full(so):
                    gone = 0
                    if time.time() >= next_e:
                        self.so_tap_e(key)
                        e_taps += 1
                        next_e = time.time() + max(0.0, self.SO_KX_E_EVERY - self.SO_KX_E_TAP)
                else:
                    gone += 1
                    if gone >= 2 and e_taps:
                        out = True
                        break
            self.macro_wait(0.01)
        so.record_resonance_use()
        t_w = time.time()
        self.macro_mark(f'{tag}无舍念({"出" if out else "cap"},E x{e_taps},{t_w - start:.2f}s)')

        a_taps = e_more = e_hits = wz_low = 0
        cleared_at = None
        next_a = t_w + self.SO_KX_A_FROM
        while time.time() - t_w < self.SO_KX_A_UNTIL:
            self.task.next_frame()
            on = self.so_on_field(so)
            e_hits = e_hits + 1 if on and self.so_forte_full(so) else 0
            if on and cleared_at is None:
                wz_low = wz_low + 1 if self.so_wz() < self.SO_KX_WZ_CLEAR else 0
                if wz_low >= 2:
                    cleared_at = time.time() - t_w
            if time.time() >= next_a:
                if e_hits >= 2:
                    self.so_tap_e(key)
                    e_more += 1
                else:
                    self.tap()
                    a_taps += 1
                next_a = time.time() + max(0.0, self.SO_KX_A_EVERY - self.A_TAP)
            self.macro_wait(0.01)
        cleared = f'妄执清空@{cleared_at:.2f}' if cleared_at is not None else '妄执清空没看到'
        self.macro_mark(f'{tag}刻心念点A(A x{a_taps}{f",补E x{e_more}" if e_more else ""},{cleared})')

        start3 = time.time()
        hits = 0
        samples = []
        full = False
        strict = self.glow_trusted()
        con_full_at = None
        while time.time() - start3 < self.SO_KX_FINISH_CAP:
            self.task.next_frame()
            if not self.hud_ok():
                self.macro_wait(0.02)
                continue
            if self.con_glow(so):
                full = True
                samples.append('光圈')
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX and (not samples or time.time() - start3 >= len(samples) * 0.3):
                samples.append(f'{time.time() - start3:.2f}:{con:.2f}')
            hits = hits + 1 if con >= self.SK_CON_ENOUGH else 0
            if hits >= self.SK_CON_FULL_CONFIRM:
                if not strict:
                    full = True
                    break
                # 光圈认得出却只有读数满: 再给光圈 SO_KX_GLOW_GRACE, 还没有就当没满, 去普攻补
                con_full_at = con_full_at or time.time()
                if time.time() - con_full_at >= self.SO_KX_GLOW_GRACE:
                    samples.append('读数满没光圈')
                    break
            self.macro_wait(self.SK_CON_POLL)
        glow = ',光圈' if samples and samples[-1] == '光圈' else (',读数满没光圈' if samples and samples[-1] == '读数满没光圈' else '')
        self.macro_mark(f'{tag}等协奏({"满" if full else "没满"}{glow},{time.time() - start3:.2f}s)')
        if not full:
            self.logger.info(f'{tag}: 刻心念点完 {self.SO_KX_FINISH_CAP:.1f}s 协奏没满 — {" ".join(samples)}')
        return full

    def seg_so_kx(self, so, xn, tag):
        """锁暝·循环第二截(守 R 后变奏碎霆, 妄执 +200 = 满): 点 E(无舍念) -> 点 A(刻心念) -> 等协奏满 -> Q(暗鸟) -> 变奏心。"""
        sw = self.switch_press_at
        self.wait_until_time(sw + self.SO_KX_E_LEAD)
        # 碎霆之后短按普攻会接旋雷破第 2 段, 视频是直接 E —— 这里先只看不点
        ok = False
        end = time.time() + self.SO_KX_FORTE_CAP
        hits = 0
        while time.time() < end:
            self.task.next_frame()
            if self.so_on_field(so):
                hits = hits + 1 if self.so_forte_full(so) else 0
                if hits >= 2:
                    ok = True
                    break
            self.macro_wait(0.02)
        if not ok:
            self.macro_mark(f'{tag}妄执没满(补普攻)')
            ok = False
            fill_start = time.time()
            rnd = 0
            while not ok and time.time() - fill_start < self.SO_KX_FILL_CAP:
                rnd += 1
                ok, _ = self.so_4a_round(so, f'{tag}补妄执#{rnd}', stop=lambda: self.so_on_field(so) and self.so_forte_full(so))
                if not ok:
                    self.task.next_frame()
                    ok = self.so_on_field(so) and self.so_forte_full(so)
        if ok:
            full = self.so_kx_taps(so, tag)
        else:
            # 妄执补不满: E 是破隙(冲刺), 不按; 普攻把协奏打满再交棒
            self.logger.warning(f'{tag}: 锁暝妄执 {self.SO_KX_FILL_CAP:.1f}s 补不满, 没有无舍念/刻心念, 普攻补协奏')
            full = False
        if not full:
            full = self.con_ready(so, 0.15, strict=True) or \
                self.wait_con_full('锁暝', self.SO_KX_CON_CAP, tag=f'{tag}补协奏', cur=so, strict=True)
        if self.SO_ECHO_IN_KX:
            self.so_echo(so, f'{tag}Q暗鸟')
        self.need(self.switch_retry(xn, f'{tag}切心', assume_con=full, time_out=self.SO_TO_XN_TIME_OUT),
                  'suoming -> hsin')
        return full

    # ==================== 一圈 ====================

    def run_cycle(self, so, sk, opener, tag):
        """启动: 守(开局 R) -> 心 -> 锁暝 -> 心 -> 守变奏入场。
        循环 QY: 守 3A[重击]E -> 锁暝 A2闪A2 -> 心 3A -> 守 Q R -> 锁暝 刻心念 暗鸟 -> 心 -> 锁暝 -> 心 -> 守变奏入场、HUD 回来。
        循环 4A: 守 3AE -> 锁暝 4A -> 守 重击 Q R -> 后面同 QY。"""
        marks = len(self.macro_marks)
        self.timeline_logged = False
        if opener:
            self.seg_sk_open(sk, self, tag=f'{tag}守')
        else:
            self.seg_sk_la(sk, so, tag=f'{tag}守a')
            if self.LOOP_KIND == 'QY':
                self.seg_so_a2(so, self, tag=f'{tag}锁a')
                self.seg_xn_mid(self, sk, tag=f'{tag}心i')
            else:
                self.seg_so_4a(so, sk, tag=f'{tag}锁a')
            self.seg_sk_lb(sk, so, tag=f'{tag}守b')
            self.seg_so_kx(so, self, tag=f'{tag}锁b')
        self.seg_xn1(self, so, tag=f'{tag}心1')
        intro = self.seg_so_r(so, self, tag=f'{tag}锁R')
        self.seg_xn2(self, intro, tag=f'{tag}心2', opener=opener)
        if self.SK_BREAK:
            self.note_break_prompt()
        self.need(self.switch_to_sk(sk, tag=f'{tag}切守'), 'hsin -> shorekeeper')
        self.logger.info(f'{tag} cycle timeline: {self.macro_timeline(marks)}')
        self.timeline_logged = True

    def macro_enter(self, entry_char):
        so = self.teammate('Suoming')
        sk = self.teammate('ShoreKeeper')
        if so is None or sk is None:
            return None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        for char in (self, so, sk):
            char.check_f_on_switch = False
        self.macro_start()
        self.timeline_logged = False
        self.hud_seen_at = time.time()
        self.hud_watch = True
        return so, sk, previous

    def macro_exit(self, previous):
        # 长按跨了好几个方法, 中途抛异常的话鼠标会一直按着。这里是唯一保证松手的地方
        self.release_attack()
        # 中途被停(关自动战斗/切出窗口)也要把时间轴写下来
        if not self.timeline_logged and self.macro_marks:
            self.logger.info(f'xss timeline (没跑完): {self.macro_timeline()}')
            self.timeline_logged = True
        self.hud_watch = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def perform_opener(self, entry_char=None):
        """启动轴: 切守岸人 -> 一圈(守岸人启动段)。返回时守岸人刚变奏入场、HUD 在场。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        so, sk, previous = got
        self.logger.info(f'xss opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            self.so_tongzou_at = -99.0
            if self.cur is not sk:
                self.need(self.switch_retry(sk, 'op'), 'opener: switch to shorekeeper')
            self.run_cycle(so, sk, opener=True, tag='op')
            self.logger.info(
                f'xss opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'xss opener broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循环轴一圈。场上不是守岸人(宏散过)就先把场子交给她。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        so, sk, previous = got
        try:
            if self.cur is not sk:
                self.need(self.switch_to_sk(sk, tag='L接守'), 'loop: hand the field to shorekeeper')
            self.loop_count += 1
            n = self.loop_count
            self.run_cycle(so, sk, opener=False, tag=f'L{n}')
            self.logger.info(
                f'xss loop #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'xss loop broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架接口 ====================

    def drive(self, entry):
        """三个人的 do_perform 都走这里。entry = 框架这次调的是谁(= 场上是谁)。"""
        # 【HUD 不在就什么都不做】: 关卡结束/结算/过场时框架还会接着调进来(F 开始战斗那边撑着不脱战)
        if not self.wait_hud_up(cap=self.DRIVE_HUD_CAP, tag='drive'):
            if time.time() - self.drive_log_at > 10:
                self.drive_log_at = time.time()
                self.logger.info('xss: 队伍 HUD 不在(结算/过场/窗口没了?), 宏不动')
            return None
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 标记要在跑之前落: 中途抛异常(脱战/任务被停)也不能让启动轴重跑
            self.opener_armed = False
            self.last_opener = time.time()
            return self.perform_opener(entry)
        self.logger.info(f'xss: opener not pending ({blocked}), running the loop')
        return self.perform_loop(entry)

    def do_perform(self):
        if not self.is_in_xss:
            return super().do_perform()
        self.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时让守岸人先上。"""
        if self.is_in_xss and self.opener_pending():
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        return super().on_combat_end(chars)
