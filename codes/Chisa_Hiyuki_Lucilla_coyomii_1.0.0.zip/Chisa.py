import time

from src.char.BaseChar import BaseChar, CharType, get_default_buff_time


class Chisa(BaseChar):
    SUPPORT_ACTION_DURATION = 1.2
    SUPPORT_LONG_ACTION_DURATION = 10.0
    INTRO_NORMAL_ATTACK_DURATION = 2.0

    @property
    def is_healer(self):
        """本队不把千咲作为治疗位，避免框架在战斗前后自动切入她。"""
        # 用属性覆盖，避免角色工厂复制状态后还原治疗定位。
        # 初始化时队伍可能尚未加载，缺少队友时沿用原生定位。
        members = {char.name for char in getattr(self.task, 'chars', ()) if char is not None}
        if {'Hiyuki', 'Lucilla'}.issubset(members):
            return False
        return super().is_healer

    def is_dps_config(self):
        return self.task and self.task.char_config.get("Chisa DPS")

    def get_char_type(self):
        if self.is_dps_config():
            return CharType.MAIN_DPS
        return super().get_char_type()

    def get_buff_time(self):
        if self.is_dps_config():
            return get_default_buff_time(CharType.MAIN_DPS)
        return super().get_buff_time()

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def on_combat_end(self, chars):
        driver = self.team_axis_driver()
        if driver is not None:
            driver.reset_team_axis()
        return super().on_combat_end(chars)

    def do_perform(self):
        driver = self.team_axis_driver()
        if driver is not None:
            driver.drive_team_axis(self)
            return
        if self.is_dps_config():
            return self.do_dps_perform()
        return self.do_support_perform()

    def team_axis_driver(self):
        if not {'Chisa', 'Hiyuki', 'Lucilla'}.issubset(
                {c.name for c in self.task.chars if c is not None}):
            return None
        return next((c for c in self.task.chars if c is not None
                     and c.name == 'Hiyuki' and hasattr(c, 'drive_team_axis')), None)

    def do_support_perform(self):
        needs_long_actions = self.has_intro and not self.has_buff()
        if self.has_intro:
            self.continues_normal_attack(self.INTRO_NORMAL_ATTACK_DURATION)

        duration = (self.SUPPORT_LONG_ACTION_DURATION
                    if needs_long_actions else self.SUPPORT_ACTION_DURATION)
        if self.flying() and not self.liberation_available() and not self.resonance_available():
            self.wait_down()
        self.click_echo(time_out=0)

        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < duration:
            self.cycle_start()
            if self.is_con_full():
                return self.switch_next_char()
            if self.liberation_available():
                self.click_liberation(wait_if_cd_ready=0)
            elif self.is_forte_full():
                if self.perform_forte():
                    break
            elif self.click_resonance(time_out=0)[0]:
                pass
            else:
                self.click()
            self.cycle_sleep()

        return self.switch_next_char()

    def do_dps_perform(self):
        timeout = 2.5
        self.check_f_on_switch = True
        if self.has_intro:
            self.continues_normal_attack(0.8)
            timeout = 2.3
        if self.flying() and not self.liberation_available() and not self.resonance_available():
            self.wait_down()
        self.click_echo()
        start = time.time()
        under_liber = False
        while time.time() - start < timeout:
            if time.time() - start < 0.5 and self.click_liberation():
                start = time.time()
                under_liber = True
                timeout = 10
                self.sleep(0.2)
            if time.time() - start < 0.5 and not self.is_forte_full() and self.click_resonance()[0]:
                start = time.time()
                if timeout != 10:
                    timeout = 1.7
            if (under_liber or self.is_dps_config()) and self.is_forte_full() and self.perform_forte():
                self.check_f_on_switch = False
                return self.switch_next_char()
            self.click()
            self.check_combat()
            self.task.next_frame()
        self.switch_next_char()

    def perform_forte(self):
        if self.flying():
            self.wait_down()
        self.task.send_key(self.get_resonance_key(), down_time=1.2)
        if self.is_forte_full():
            return False
        self.heavy_attack(3.5)
        return True
