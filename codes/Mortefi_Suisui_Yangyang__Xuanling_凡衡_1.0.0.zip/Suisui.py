# -*- coding: utf-8 -*-
"""秧莫穗 — 穗穗（速切副输出 / 宏驱动入口）

【开局规则】(用户 2026-10-11): "开局只限制非莫特斐开局; 穗穗开局则不再切秧秧,
直接切莫特斐, 打0链的轴; 秧秧开局则是按图标选择0链还是2链的轴"。
所以穗穗这里【自己就是入场角色之一】:
  · get_switch_priority: 启动轴待跑时给 NO(别让框架把她换上场, 场上是谁就谁跑);
  · do_perform: 启动轴待跑时【不让场】, 直接把自己当 entry_char 交给秧秧的 perform_opener ——
    宏的第一格"直接切莫特斐"就从她身上起跑, 走 0 链那套轴。

宏体在同目录的 YangYangSp.py 里; 宏在跑的时候她全程由宏按数字键切进切出(一轮 5 次),
这里一个动作都不用写。

走到 do_perform 而启动轴不待跑, 说明宏散了(切人失败/脱战重进): 打一轮原版,
打完框架会把场子交给秧秧, 从循环宏开头接上。

【跟参考代码的差别】: 参考代码那边入场角色只有穗穗一个, 千咲是"让场"
(switch_next_char)。本队的规则是"莫特斐不能让场、穗穗/秧秧谁在场上谁跑",
所以这里改成了"自己当入口"。
"""

from src.char.BaseChar import SwitchPriority
from src.char.Suisui import Suisui as NativeSuisui


class Suisui(NativeSuisui):
    """秧莫穗里的穗穗。非本队时整套走原版。"""

    @property
    def is_healer(self):
        """本队里穗穗是速切副C, 不按治疗位处理(用户明确要求)。

        工具 的内置数据把穗穗标成 HEALER, 于是「战斗前后切换治疗位」（switch_healer）
        会把她拎上场。秧莫穗的每一次上场都由宏按数字键安排, 框架那一手是多余的干扰。
        返回 False 后 工具 不会再切她(本队内有效, 她的原版治疗逻辑不受影响,
        因为本队根本不会走到那里)。

        【跟参考代码的差别】: 参考那份没有这个覆盖(它那边穗穗就是入场角色, 靠框架的
        switch_healer 拎上场正好)。本队现在是秧秧开局, 她的上场由框架按优先级安排,
        把治疗位关掉可以少一层干扰。
        """
        return False

    @property
    def is_in_yangmosui(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Mortefi', 'YangYangSp'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的秧秧。【按能力找】: 没启用自定义时返回 None。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'perform_opener') and hasattr(char, 'macro_switch'):
                return char
        return None

    def do_perform(self):
        if not self.is_in_yangmosui:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            self.logger.warning('yangmosui: YangYangSp custom code is off, '
                                'falling back to the native rotation')
            return super().do_perform()
        if macro.opener_pending():
            # 【穗穗开局: 不让场, 自己当入口跑启动宏】(用户 2026-10-11: "穗穗开局则不再切秧秧,
            # 直接切莫特斐, 打0链的轴")。把自己作为 entry_char 传进去, 启动宏第一格
            # "直接切莫特斐"就从她身上起跑(穗穗 -> 莫特斐), 走 0 链那套。
            # 【之前这里是 switch_next_char() 让场】: 秧秧的优先级是 MUST, 框架一定会把她换上来,
            # 结果变成"秧秧开局" -> 读图标 -> 走 2 链轴, 跟规则相反。
            self.logger.info('suisui: opener pending -> running it from here (entry = suisui)')
            if macro.run_opener_from(self):
                return
            self.logger.warning('yangmosui opener aborted, falling back to the native rotation')
        else:
            self.logger.info('suisui do_perform in yangmosui (macro fell apart) -> native rotation')
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时返回 NO —— 入场角色是秧秧, 别抢在她前面上场(会把表错开一格)。

        【要写在 super() 之前】: 原版在有变奏时会返回 MUST。
        """
        if self.is_in_yangmosui:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
