import logging
import time

import numpy as np

from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Phrolova(BaseChar):
    """弗坎嘉 25 秒进阶轴（BV1nAC6BRETp@77-144s）：弗洛洛，启动轴最后一个节点接循环轴。

    启动轴 Cantarella.f1 -> Phrolova.f1 -> Cantarella.f2 -> Phrolova.f2 -> 循环轴
    循环轴 Galbrena.s1 -> Cantarella.s1 -> Galbrena.s2 -> Cantarella.s2 -> Galbrena.s3 -> Cantarella.s3
           -> Galbrena.s4 -> Cantarella.s4 -> Phrolova.s1 -> Galbrena.s1
    """

    _axis_char = True

    # 本轴弗的两行和 30 秒轴同形，F1 / S1 沿用 30 秒轴视频实测（f1 7.0-21.1 / s1 47.9-61.9）；A 段待专题：普攻段数，暂按视频时长。
    # 本轴视频 f1 78.6 入场 -> 85.3 切坎（30 秒轴 f1 入场到强化重击 7.0s）；s1 114.0-128.0 共 14.0s，和 30 秒轴 s1 一样长
    #   open    开头 A 段：f1 AA 7.0-8.7；s1 A 48.0-50.2（含变奏入场）
    #   enh_a1  Q 后【A】：f1 8.8-9.6；s1 50.4-51.0
    #   e       按一次 E 后普攻到 E 格出现冷却数字的时限（_cast_e_once）：本轴视频 E 放出到冷却数字 0.7s
    #           （f1 80.9 -> 81.60），2.0.7 实测按 E 到放出最多 0.38s（test_2358 steps_ours.tsv），取 1.8s
    #   enh_a2  E 后【A】：f1 10.4-11.0；s1 52.0-52.6。_cast_e_once 返回时强化左键已用掉，2.0.10 实测 test_0707
    #           f1 E 冷却数字 10.80、第 4 音符 11.2-11.3，再打 0.6s 到 11.69 才闪，改 0.2（用户 2026-10-15：第 1 次闪按晚了）
    #   outro   R 动画结束到 ↓ 的间隔 × 1.5，最少 1s：s1 61.2->61.9
    # open 按本轴视频定（用户 2026-10-14：Q 可以提前）。技能栏换成弗到 Q 放出：本轴视频 f1 1.53s、s1 2.20s；
    # 2.0.7 实测 test_2358 f1 1.81s、s1 2.46s（open 1.5 / 2.2），各减 0.2（media/frames/v7check/steps/steps_ref.tsv、
    # media/harness-v6/test_2358/frames/steps/steps_ours.tsv）。
    # Q 的冷却确认、Q 后【A】、E 连按到冷却数字出现保持 2.0.7 的做法：2.0.8 改成 Q 只发键、f1 Q 后【A】0.6s、E 只连按 0.5s，
    # 实测 test_0056 f1 的 E 2.0s 没进冷却、第 5 音符和强化重击都没等到（用户：释放时机不对，吞音符）
    F1 = {'open': 1.3, 'enh_a1': 0.8, 'e': 1.8, 'enh_a2': 0.2}
    S1 = {'open': 2.0, 'enh_a1': 0.6, 'e': 1.8, 'enh_a2': 0.2, 'outro': 1.1}
    # 按 E 后到时限还没出冷却数字，就当按键被动作吞了、再按一次；最多按这么多次
    E_SENDS = 2
    # f2 R↓：本轴视频 R 演出结束 90.9 -> 切嘉 91.4，0.5s × 1.5 不足 1s 取 1s
    F2_OUTRO = 1.0
    # 第 2 次闪避按时间（2.0.19，用户 2026-10-22）：第 1 次闪避后普攻，从第 1 次闪避按键起满 DODGE2_AFTER 就闪，
    # 不看强化提示和第 5 音符。闪避早于第 5 音符显形，音符也不丢（用户）。2.0.18 实测 test_1332 五圈：第 1 次闪避 ->
    # 第 5 音符显形 2.53-2.61s，识别判闪避在显形后约 0.2s；2.50 比识别早约 0.3s。闪太早连段会重置、出不了强化提示
    # （v1 固定 1.4s，实测 run2 101.9-106.0 卡在 4 音符）。按提示和第 5 音符识别判闪避的做法与数据见语义卡 Phrolova_C0
    DODGE2_AFTER = 2.5
    # 第 5 音符格（1920x1080 录屏量的框）：格内高饱和像素（max-min >= 100 且 max >= 150）占比，空格约 0、有音符 0.12-0.20，
    # 特效尖峰 0.8-1.0。只在第 2 次闪避时写进日志，不作判据
    NOTE5_BOX = (1019, 980, 1045, 1014)
    NOTE_SAT_RANGE = (0.08, 0.40)
    # 第二次闪避后【A】打到 6 音符（mouse_forte）再【Z】：视频 闪 13.1 -> 14.0。何时重击由 mouse_forte 决定，这里只是上限：
    # 攒音符时被 boss 打断要多打一轮（用户确认），v3 实测 test_1053 s1 第 2 轮第 6 音符 146.9 比 3.0s 上限晚 0.3s
    HINT_TO_HEAVY = 6.0
    HEAVY_TO_R = 3.0  # 同上游 Phrolova.heavy_and_liber；视频【Z】14.0-16.8 -> R 16.9
    # 满 6 音符后按住左键一段时间才进重击，进了以后松手不打断、伤害不丢；重击打完 R 才亮（用户 2026-10-09）。
    # 上游 heavy_click_forte 认不到 mouse_forte 就松手，v13 实测 test_0110 按住只有 0.1-0.2s（第 6 音符 → cast heavy 0.14-0.28s），
    # 之后到 R 演出开始 2.44-3.10s 不等，用户看到进重击时快时慢（377s）。v14 起改为至少按住 1.0s。
    # 2.0.12 改回 0（同 f1）：按住 1.0s 时重击图标出现 -> R 演出 教程 2.8s（121.2 -> 124.0）、
    # 2.0.11 3.3s（100.4 -> 103.7，media/harness-v7/test_1142/frames/opus_hd/f11_s1_99.6-101.0.png）
    HEAVY_HOLD = 0
    HEAVY_HOLD_MAX = 2.0  # 同 heavy_click_forte 的上限：到这时鼠标图标还亮就算没放出
    # f1 不设最短按住，鼠标图标灭就松手切坎（同上游 heavy_click_forte，实测按住 0.14-0.28s 就进重击）。
    # 参考视频第 6 音符 84.7 -> 重击起手 84.9 -> 约 85.05 切坎（media/frames/intro/step3_hud_sheet.png）；
    # v2 按住 HEAVY_HOLD 才切，test_2304 弗离场协奏已满，坎 f2 变成变奏入场、没打出普攻（用户：切坎切晚了）
    F1_HEAVY_HOLD = 0
    # 【AZ】一次按住（s1 自 2.0.18、f1 自 2.0.19，用户 2026-10-22）：第 2 次闪避后强化左键亮着就按住左键，由这次按下
    # 打出强化普攻、接着进重击；鼠标图标亮过再灭就松手，s1 接着连按 R，f1 切坎。2.0.16 先点出强化普攻、鼠标图标亮了再按：
    # 强化普攻出手 -> 重击起手 0.47-0.55s，教程 0.07-0.17s。2.0.17 点出强化普攻、E 格出冷却当帧再按第二下：test_0137
    # 判闪避 -> R 放完与 2.0.16 持平，第二下没让重击提前。2.0.18 按到 R 亮才松：test_1332 R 在松手后 0.25-0.36s 才出；
    # C3 松手早（held_s 2.43，其余 3.36-3.40），第 6 音符 -> R 演出 2.77s、其余 3.02-3.08s，重击没断。
    # 按下落在闪避动作里时按住不出招、松手才出（旧轴 v9 test_1842 三次），所以每按 AZ_REPRESS 还没出冷却就松开重按。
    # 按住时没认到图标要等 R 亮才知道重击出没出（mode=hold_unseen），f1 这时切坎会晚
    AZ_TAP_MAX = 1.0  # 打出强化普攻的上限：test_0034 判闪避 -> E 格出冷却 0.36-0.38s
    AZ_REPRESS = 0.1  # 每次按下等 E 格出冷却的时长，同 click_with_interval 的间隔
    AZ_REPRESS_GAP = 0.03  # 重按前松开的时长，免得松开和按下落在同一帧
    AZ_HOLD_TO_FULL = 1.0  # 按住等鼠标图标的上限：test_0034 强化普攻出手 -> 第 6 音符 0.30-0.45s，没亮多半音符不够
    _HOLD_IN = ()  # 带着按住的左键切进来时接着按的节点

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        self._heavy_ok = False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        self._heavy_ok = False

    def f_break(self, check_f_on_switch=False, force=False):
        # 只放行显式 force（工具-charcode-dev workshop.md 9b），弗洛洛离场时框架不再按 F。v4 实测 test_1208 三场：
        # boss 2 击破圈恰在 s1 R 后亮起，弗在 R 状态离 boss 远、F 按不出，框架连按 F 不切人，
        # 拖过 2s 不查战斗窗口后被判脱战、重走启动轴。击破留给在 boss 身边的嘉贝莉娜、坎特蕾拉打（v13 嘉 s1 的挪到坎 s1 开局）
        if force:
            return self.task.f_break()
        return False

    def skip_combat_check(self):
        # 同上游 Phrolova：R 后赫卡忒视角抬高、锁定丢失，2s 内不查战斗
        # （v2 实测 test_1002 两遍 s1 都在 R 后约 3s target_enemy failed，被判脱战、回到启动轴）
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 2

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        held, self._held_switch = self._held_switch, False
        if target is None:
            if held:
                self.task.mouse_up()
            self._raw_logger.warning(f'[{(self._node or "-").upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        if held and self._switch_holding(target):
            return True
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _switch_holding(self, target):
        """Switch by number key with the left button still held (set _held_switch before the switch), so the
        target enters mid-heavy: the framework switch and its F-break both click, which releases the button.
        Bookkeeping mirrors BaseCombatTask.switch_next_char for a switch without intro. On failure release the
        button and return False; the caller then uses the framework switch."""
        tag = self._node or '-'
        start = time.time()
        switched = False
        try:
            if self.is_con_full():
                # 协奏满切人会带变奏，交给框架切人记 has_intro
                self._raw_logger.warning(f'[{tag.upper()}] fallback: framework_switch reason=con_full')
                return False
            last_send = 0
            # 按键到技能栏换人约 0.17s（v3 实测 test_2352），上限取 1.0s
            while time.time() - start < 1.0:
                self.check_combat()
                if time.time() - last_send > 0.1:
                    self.task.send_key(target.index + 1)
                    last_send = time.time()
                self.task.next_frame()
                if self.task.in_team()[1] == target.index:
                    switched = True
                    break
        finally:
            if not switched:
                self.task.mouse_up()
        if not switched:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: framework_switch reason=held_switch_timeout')
            return False
        self.task.in_liberation = False
        self.switch_out(con_full=False)
        target.has_intro = False
        target.has_sub_dps_intro = False
        target.is_current_char = True
        target.last_switch_in_time = time.time()
        target._held_in = True
        self._trace(tag, 'switch', ok=True, held=True, next=target.__class__.__name__, switch_s=time.time() - start)
        return True

    # 战斗结束到重进战斗不超过这么久，就当作误判脱战、接着走记下的节点：
    # 误判 0.02s 就重进（v6 实测 test_2342），真实换场最短 8.8s（v1-v5 日志）
    _RESUME_S = 1.0

    def on_combat_end(self, chars):
        # 切人那一帧编号角标全被挡住时，框架判脱战、清空节点状态，重进战斗又从启动轴开始
        # （v6 实测 test_2342 v44.78 坎 s4 切弗 s1，弗被打断去走坎 f1）。记下已强切、还没进场的节点
        pending = [c for c in self.task.chars if c is not None and getattr(c, '_entry_mode', None)]
        self.task._axis_resume = (pending[0].__class__.__name__, pending[0]._entry_mode, time.time()) if pending else None
        # 按住左键等着切人、或带着按住切进来时战斗结束，左键不能留在按下状态
        if self._held_switch or self._held_in or self._entry_held:
            self.task.mouse_up()
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        super().on_combat_end(chars)

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _take_resume(self):
        """Pop the node on_combat_end recorded; use it only when this combat started within _RESUME_S."""
        resume, self.task._axis_resume = getattr(self.task, '_axis_resume', None), None
        if resume is None or time.time() - resume[2] > self._RESUME_S:
            return None
        return resume[:2]

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        held, self._held_in = self._held_in, False
        if held and mode not in self._HOLD_IN:
            # 带着按住的左键切进来，但这个节点不接着按：先松开
            self.task.mouse_up()
            held = False
        self._entry_held = held
        resume = self._take_resume() if mode is None else None
        if resume and resume[0] != self.__class__.__name__:
            # 误判脱战时切人没成，记下的节点不归在场角色：强切过去
            self._trace(None, 'interrupt', reason='resume', next=f'{resume[0]}.{resume[1]}')
            return self._force_switch_to(self._find_teammate(resume[0]), resume[1])
        if resume:
            mode, entry = resume[1], 'resume'
        elif mode is None:
            if not self.started and not self._startup_done:
                # 启动轴从坎 E 开始，别人先在场就直接强切坎特蕾拉（视频 77.0 嘉在场，77.9 切坎）
                if self.__class__.__name__ != 'Cantarella':
                    self._trace(None, 'interrupt', reason='not_axis_head', next='Cantarella.f1')
                    return self._force_switch_to(self._find_teammate('Cantarella'), 'f1')
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _ready_or_skip(self, tag, skill, ready, time_out, settle_time=-1):
        """Normal-attack until ready() holds (for settle_time seconds when given); on timeout log a fallback
        warning and return False."""
        if self.task.wait_until(ready, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out, settle_time=settle_time):
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_{skill} reason=not_ready')
        return False

    def _cast_e(self, tag, ready_time_out=1.0, time_out=1.0, skill=None, settle_time=-1):
        """E that shows a CD after the cast: press until the CD appears (1-6).
        skill names which E it is when one key casts several (fallback name and log field)."""
        if not self._ready_or_skip(tag, skill or 'e', self.resonance_available, ready_time_out, settle_time):
            return False
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                       pre_action=self.check_combat if time_out > 1 else None,
                                       post_action=self.send_resonance_key, time_out=time_out))
        if ok:
            self.record_resonance_use()
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', **data)
        return ok

    def _cast_echo(self, tag, ready_time_out=1.0, time_out=1.0):
        if not self._ready_or_skip(tag, 'echo', self.echo_available, ready_time_out):
            return False
        ok = self.click_echo(time_out=time_out)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit')
        return ok

    def _cast_r(self, tag, ready_time_out=1.0, click_f=True):
        if not self._ready_or_skip(tag, 'r', self.liberation_available, ready_time_out):
            return False
        ok = self.click_liberation(click_f=click_f)
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok

    def _dodge(self):
        self.task.send_key(self.task.key_config.get('Dodge Key'))

    def _outro(self, tag, time_out):
        """↓: leave at full concerto; otherwise attack until it fills, and leave anyway on timeout."""
        if self.task.wait_until(self.is_con_full, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out):
            self._trace(tag, 'decide: outro', con_full=True)
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_outro reason=timeout con_full=False')
        return False

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        self._action_f1('f1', 'Cantarella.f2')
        self._force_switch_to(self._find_teammate('Cantarella'), 'f2')

    def perform_f2(self):
        self._action_f2('f2', 'Galbrena.s1')
        self._force_switch_to(self._find_teammate('Galbrena'), 's1')

    def perform_s1(self):
        self._action_s1('s1', 'Galbrena.s1')
        self._force_switch_to(self._find_teammate('Galbrena'), 's1')

    # ---------------- 动作体（tag = 日志节点，nxt = exit 行去向） ----------------
    # 启动轴“弗 AAQ【A】E【A】闪 / 弗 AAA闪【AZ】”，视频 78.6-85.3（坎 E 后强切、无变奏）：
    # 强化重击放出就切坎，重击在后台打完（字幕@84），R 留到 f2
    def _action_f1(self, tag, nxt):
        self.last_liberation = -1  # 同上游 do_perform：只认本次上场的 R
        self._heavy_ok = self._action_notes(tag, self.F1, heavy_hold=self.F1_HEAVY_HOLD)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 启动轴“弗 R↓”，视频 86.9-91.4（坎 AAAE 后强切）：R 87.5，演出 87.6-90.9，随后延奏嘉
    def _action_f2(self, tag, nxt):
        self.last_liberation = -1
        if self._heavy_ok:
            self._cast_r_after_heavy(tag)
        else:
            # R 在强化重击之后才解锁（卡片）
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r reason=no_heavy')
        self._heavy_ok = False
        self._outro(tag, self.F2_OUTRO)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“弗 AQ【A】E【A】闪 / 弗 AAA闪【AZ】R↓”，视频 114.0-128.0（坎 E↓ 带变奏切入）
    def _action_s1(self, tag, nxt):
        self.last_liberation = -1
        if self._action_notes(tag, self.S1):
            self._cast_r_after_heavy(tag)
        else:
            # R 在强化重击之后才解锁（卡片），不再空等 3s（30 秒轴 v2 实测 test_1002 f1 两遍 cast R: fail）
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r reason=not_ready')
        self._outro(tag, self.S1['outro'])
        self._trace(tag, 'exit', reason='done', next=nxt)

    # “AQ【A】E【A】闪 / AAA闪【AZ】”两行是同一次上场；【A】是强化左键，强化期间的普攻即强化 A。返回强化重击是否放出
    def _action_notes(self, tag, t, heavy_hold=None):
        self.continues_normal_attack(t['open'])
        self._cast_echo(tag)
        self.continues_normal_attack(t['enh_a1'])
        self._cast_e_once(tag, t['e'])
        self.continues_normal_attack(t['enh_a2'])
        start = time.time()
        self._dodge()
        self.task.wait_until(lambda: time.time() - start >= self.DODGE2_AFTER, pre_action=self.check_combat,
                             post_action=self.click_with_interval, time_out=self.DODGE2_AFTER)
        after_s = time.time() - start
        self._dodge()
        # 帧没换，记的是闪避那一刻强化提示和第 5 音符格亮没亮
        self._trace(tag, 'decide: dodge', after_s=after_s, hint=self.resonance_available(), note5=self.is_note5_lit())
        return self._cast_heavy(tag, self.HEAVY_HOLD if heavy_hold is None else heavy_hold)

    def _cast_e_once(self, tag, time_out):
        """E【A】: press the normal E once, then normal-attack (the enhanced left click) until the E slot shows a CD.
        After the normal E the slot turns into the enhanced E with no CD, so pressing until the CD appears
        (_cast_e) casts the enhanced E as well and the 4th note comes from it, not from the enhanced left click
        (用户 2026-10-15). The CD shows once the enhanced left click is used: 本轴视频 f1 81.50 左键强化态、E 格无数字，
        81.60 左键复原、E 格 11.3（media/frames/v7check/steps/fine_onsets_f1_s4.png）。
        No CD within time_out: the press was likely swallowed by an animation, press once more (E_SENDS)."""
        if not self._ready_or_skip(tag, 'e', self.resonance_available, 1.0):
            return False
        start, ok, sends = time.time(), False, 0
        while not ok and sends < self.E_SENDS:
            self.send_resonance_key()
            sends += 1
            ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                           post_action=self.click_with_interval, time_out=time_out))
        if ok:
            self.record_resonance_use()
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit',
                    cd_s=time.time() - start, sends=sends)
        return ok

    def is_note5_lit(self):
        """五线谱左起第 5 个音符格亮着。"""
        box = self.task.box_of_screen_scaled(1920, 1080, *self.NOTE5_BOX, name='phrolova_note5', hcenter=True)
        crop = box.crop_frame(self.task.frame)[:, :, :3].astype(np.int16)
        top = crop.max(axis=2)
        ratio = np.count_nonzero((top >= 150) & (top - crop.min(axis=2) >= 100)) / max(top.size, 1)
        self.logger.debug(f'note5 ratio={ratio:.3f}')
        return self.NOTE_SAT_RANGE[0] <= ratio <= self.NOTE_SAT_RANGE[1]

    def _cast_heavy(self, tag, hold):
        """【A】【Z】. With the enhanced left click lit (mode=hold): press the left button and keep it down, so the press
        casts the enhanced attack and runs on into the heavy; re-press every AZ_REPRESS until the E slot shows its CD
        (AZ_TAP_MAX at most), then hold until the mouse_forte icon shows (AZ_HOLD_TO_FULL at most) and is gone again
        (HEAVY_HOLD_MAX at most). Otherwise, or when the icon does not show (mode=tap): attack until the 6th note,
        then hold heavy for at least hold seconds and until the icon is gone (HEAVY_HOLD_MAX at most)."""
        held = False
        if self.resonance_available():
            start, presses, down, full = time.time(), 0, False, False
            try:
                while not held and time.time() - start < self.AZ_TAP_MAX:
                    if down:
                        self.task.mouse_up()
                        down = False
                        self.sleep(self.AZ_REPRESS_GAP)
                    self.task.mouse_down()
                    down, presses = True, presses + 1
                    held = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                                     time_out=self.AZ_REPRESS))
                fire_s = time.time() - start
                full = held and bool(self.task.wait_until(self.is_mouse_forte_full, time_out=self.AZ_HOLD_TO_FULL))
                if full:
                    # 图标灭就是进了重击，松手不打断（用户 2026-10-09）
                    ok = bool(self.task.wait_until(lambda: not self.is_mouse_forte_full(),
                                                   time_out=self.HEAVY_HOLD_MAX))
                    held_s = time.time() - start
            finally:
                if down:
                    self.task.mouse_up()
            if full:
                self._trace(tag, 'cast heavy', ok=ok, reason=None if ok else 'not_consumed', mode='hold',
                            presses=presses, fire_s=fire_s, held_s=held_s)
                return ok
        ready = self.is_mouse_forte_full
        if held:
            # 按住期间没认到鼠标图标：可能图标只亮了一两帧、重击已经出了，那样重击打完 R 会亮
            ready = lambda: self.is_mouse_forte_full() or self.liberation_available()
        if not self._ready_or_skip(tag, 'heavy', ready, self.HINT_TO_HEAVY):
            return False
        if held and not self.is_mouse_forte_full():
            self._trace(tag, 'cast heavy', ok=True, mode='hold_unseen')
            return True
        self.task.mouse_down()
        try:
            self.sleep(hold)
            ok = bool(self.task.wait_until(lambda: not self.is_mouse_forte_full(),
                                           time_out=self.HEAVY_HOLD_MAX - hold))
        finally:
            self.task.mouse_up()
        self._trace(tag, 'cast heavy', ok=ok, reason=None if ok else 'not_consumed', mode='tap')
        return ok

    def _cast_r_after_heavy(self, tag):
        # 重击收招前按 R 不出：同上游，不另设就绪门槛，反复 click_liberation 直到放出
        # （v1 先等 liberation_available 1s，实测 run3' 151.73 Z 后 152.74 跳过 R）
        ok = bool(self.task.wait_until(lambda: self.click_liberation(wait_if_cd_ready=0),
                                       pre_action=self.check_combat, time_out=self.HEAVY_TO_R))
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok
