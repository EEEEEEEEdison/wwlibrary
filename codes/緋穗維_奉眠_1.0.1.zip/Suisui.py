import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements, SwitchPriority


class NoEnemy(Exception):
    """場上沒怪 / 鎖不到怪: 這一圈到此為止, 交回框架(見 check_enemy_gone)。"""



class Suisui(BaseChar):
    """穗穗: 效應體系專輔, 本體幾乎無傷害, 全部價值壓在「延奏」那一下。

    濯雨時只有 15 秒(遊戲側計時, 不受動畫凍結影響), 退出時芳菲信直接清零 ——
    這是整套代碼最硬的約束。延奏 600 檔才給下一個角色 50% 攻擊, 400 檔只有 12%。

    站場分兩條軸, 只有開頭不同, 從"等第一格迴路能量滿"起完全一樣:
      啟動軸  按住攻擊鍵 -> 等E亮 -> 按E「醒春潮」直到圖標消失(被打斷就補按)進濯雨時 -> v
      循環軸  (維里奈延奏後變奏入場, 變奏技能本身已把她推進濯雨時) 按住攻擊鍵 -> v
      啟動軸等E的過程中還盯著芳菲信: 它漲了就說明這次其實是帶變奏進來的(記帳丟了),
      當場認領那段濯雨時並跳過醒春潮 —— 否則會白攢 6 秒水雲息、濯雨時的計時基準
      也跟著晚記那麼多, 保底閘會一路等到芳菲信被清零
      v  等第一格滿 -> 按E落地 -> 等0.95秒 -> 切主C入場, 到位立刻狂點把場子要回來
         -> 回到穗穗: Q -> [保底: 三格迴路能量滿才準放R] -> R -> 切緋雪(延奏給緋雪)
      三格沒打滿濯雨時就要結束: 不放 R, 等濯雨時結束 -> 醒春潮重開 -> 再打滿三格 -> R(見 REFILL_WITH_XCC)

    攻擊鍵是鼠標、E/Q/數字鍵是鍵盤, 互不衝突, 所以到三格保底之前一次都不鬆手; 保底按住 1 秒還沒滿才鬆開改點普攻。
    切人期間也保持按住 —— 點擊落在誰身上就由誰打出來, 主C出場那兩下A就是這麼來的。

    大招壓到最後放: 30 秒領域幾乎全部覆蓋後面兩個角色的輸出窗口。

    隊伍: 維里奈 / 穗穗 / 緋雪。輪轉 維里奈 -> 穗穗 -> 緋雪 -> 維里奈, 每場戰鬥強制維里奈起手。
    沒帶變奏上場時: 本場維里奈還沒起過手就直接切她(hand_to_opener); 起過了才走啟動軸(醒春潮)。
    """

    MISTY_WINDOW = 15.0  # 濯雨時總時長, 用牆鐘
    LIB_CAST_RESERVE = 3.0  # 窗口末尾預留給"放大招+切人"

    OPEN_E_WAIT_TIMEOUT = 10.0
    OPEN_POLL = 0.1
    # 醒春潮要按到 suisui_e1 消失才算放出去 —— 被 boss 打中/擊倒那一下的按鍵直接丟棄不排隊。
    # 10-04~10-08 實機 10 次啟動軸 5 次芳菲信沒攢滿(misty closing), 等E一次都沒超時:
    # 敗點全在"按了一次就當成功", 後面 15 秒在一段不存在的濯雨時上空轉。
    XCC_THRESHOLD = 0.80  # 等E亮和確認放出用同一張圖同一個閾值(也是框架 find_one 的默認值)
    # 每按一下先等圖標反應這麼久, 等不到才補下一下。不能照心雷穗的 0.05 連發: 那邊開場是
    # 點普攻, 這條軸全程按住左鍵, 每發一次鍵都投 WM_ACTIVATE, 發密了按住就鬆了。
    # 醒春潮第1F就清水雲息, 圖標 0.4 秒內必然變; 下一發落在醒春潮演出裡會被丟棄, 不會按出第二個E
    XCC_CONFIRM_WAIT = 0.40
    XCC_CAST_CAP = 8.0  # 一直按不出來的上限; 超了說明這輪進不了濯雨時
    # 醒春潮之後隔多久按落地E。醒春潮把她頂上天, E 只在上升/滯空有效, 進入下落就沒反應。
    # 標定: 3.0/3.1 已在下落段完全不出; 2.0/2.2/2.4 能出但偏早。窗口夾在 2.4~3.0
    FIRST_BAR_TIME = 2.8
    # 循環軸按落地E的時機。【計時起點和啟動軸不同】: 這裡從她被切上場那一刻算起,
    # 中間沒有醒春潮, 開頭約 0.9 秒是變奏入場動畫, 兩個值沒有可比性。
    # 標定: 3.1/2.9/2.7 已在下落段完全沒反應; 2.6 能出但只比失敗區低 0.1 秒。
    # 早了只是第一格沒攢滿(wait_forte3 兜得住), 晚了是整輪報廢(E沒生效->人還在空中
    # ->切主C超時2秒), 兩邊不對稱, 所以往早的一側靠
    # 【這個值是緋雪交棒時標定的】: 換成維里奈交棒後錨點(last_switch_in_time)寫入的時機略有不同,
    # 日誌出現"按E落地沒反應 -> 切主C超時"就往 2.4 調
    FIRST_BAR_TIME_INTRO = 2.6
    # 用【頭像認出切人完成那一刻】當循環軸的計時錨點, 而不是 do_perform 被調用那一刻 ——
    # 兩者之間隔著框架的交接記帳、上個角色 leave() 的返回、任務循環再調到穗穗, 這段是變長的。
    # 這個上限只保留"防時間戳過期"的本職: 實測 gap 是雙峰的(0.04~0.12 和 0.74~0.98),
    # 試過壓到 0.35 去掐掉大的那一簇, 結果證明方向錯了 —— 那一簇的錨點是對的
    SWITCH_ANCHOR_MAX = 1.5
    # 按E落地到開始切主C的間隔。要夠長按攻擊鍵真的A出去一段 —— 切走時連段已經起來了,
    # 切回來才會接著往下打, 而不是從第一段重新開始
    E_LAND_TO_SWITCH = 0.95
    BACK_TO_R = 0.1  # 切回來按完Q到開R; 保底閘(wait_forte3)排在這後面
    POST_LIB_SETTLE = 0.15  # 大招動畫剛結束時能量環沒渲染回來, 立刻切人會把協奏讀成0

    # 借主C一下: 切過去到位立刻把場子要回來。框架的 current_char 不跟著變,
    # 所以必須自己確認 index 歸位; 任何一步沒切成就當沒發生過
    DPS_TOUCH_OUT_TIMEOUT = 2.0
    DPS_TOUCH_BACK_TIMEOUT = 3.0  # 回程給得寬: 可能撞上游戲的切人硬直, 得一直重發等放行
    # 重發數字鍵的間隔。太小(0.12): 切換生效到 in_team() 讀出來之間有兩三幀延遲,
    # 這期間多發的鍵會排隊, 等切回穗穗之後再觸發一次(表現是主C在錯誤的節點又切進來)。
    # 太大(0.35): 第一次沒生效要多等 0.35 秒才補發, 來回從 1.2~1.3 漲到 1.4~1.5。
    # 【別再加密】: 試過 0.08, 回程快了 0.1 秒但 forte3 從 0.4 退化到 1.9 —— PostMessage 的
    # send_key() 每次都投一條 WM_ACTIVATE, 窗口收到就會把按住的左鍵鬆開
    SWITCH_KEY_RESEND = 0.22
    SWITCH_KEY_RESEND_BACK = 0.22
    SWITCH_POLL = 0.05  # 查 in_team 要比重發密, 好儘快發現切成了

    # 循環軸三格滿了 R 還沒亮時, 接著按住打的上限。10-04~10-08 實機循環軸距上次放 R
    # 51.4s 以上都開得出來, 50.1/50.9s 兩次沒開(緋雪短版啟動軸讓第一輪早了 4~5 秒), 差一秒左右
    R_READY_WAIT = 2.0
    # 等 R 時濯雨時至少還得剩這麼多: R 演出 4.3s + 切人要在濯雨時關之前做完(芳菲信延奏時才結算);
    # 循環軸的 misty_start 是 do_perform 那一刻記的, 比真正的變奏入場晚 ~1.2s, 所以給寬
    R_MISTY_RESERVE = 6.0
    FORTE3_WAIT = 8.0  # 等三格滿的上限, 超了照放不誤
    # 進三格保底後先保持按住這麼久再改點普攻。切回穗穗時按住的攻擊會接上之前的連段直接打滿,
    # 這是這條軸的設計: 10-08 實機啟動軸 6 次三格都是 0.6~1.0s 內滿的, 這段不能鬆。
    # 過了還沒滿(循環軸大多 1.8~3.2s)才是一下接一下地出重擊, 改點普攻
    FORTE3_HOLD_GRACE = 1.0
    A_TAP = 0.06  # 普攻按住這麼久才算一下; task.click() 那 10ms 會被吞(心雷穗同款)
    A_TAP_INTERVAL = 0.12
    # 循環軸放 R 前協奏要到這麼多: 穗穗大招只回 20, 放之前不到 80 放完一定不滿, 切下一個人就沒有變奏
    # (延奏整個不出, 芳菲信白攢)。100-20=80 再留 2 點讀數誤差。心雷穗/心卜穗 10-06 實機同款,
    # 那邊記著"迴路滿了協奏也可能才七十幾"。三格保底改成點普攻之後重擊少了, 協奏更容易差這一截
    CON_BEFORE_R = 0.82
    CON_TOP_UP_CAP = 4.0  # 補協奏的上限; 濯雨時只剩 LIB_CAST_RESERVE 也停(過了芳菲信清零)
    # 【10-26 log】到了放 R 的時候 R 偶爾讀成沒亮(03:04:23: 1.3 秒前才讀到"亮了", 補完協奏再看卻是暗的),
    # 就這樣不放 R 直接走, 協奏差 R 那 20 點 -> 緋雪空手上場, 心念要從 0 攢, 那輪多花十幾秒。
    #   1. 放 R 之前多等一下: 邊點普攻邊等 R 亮, 最多 R_CAST_GRACE 秒
    #   2. 真的沒有 R(冷卻/能量不夠): 改成把協奏直接打滿 100% 再走, 至少讓緋雪帶變奏上場。
    #      這時濯雨時可能已經過了, 芳菲信清零只是延奏弱一點; 緋雪沒變奏損失大得多
    R_CAST_GRACE = 1.0
    # 【10-26 第三次 log】03:39:21 讀到 R 亮、03:39:22 放 R 時又是暗的(R 剛好卡在冷卻最後一兩秒),
    # 等了 1 秒寬限沒等到就補協奏切走了。現在 R 在冷卻中、剩下不到 R_CD_WAIT_MAX 秒就邊打邊等到好
    R_CD_WAIT_MAX = 4.0
    # 【10-26 第四次 log】03:56:47 / 03:59:27 兩次: 等到"R 亮了"去按, 框架回 clicked liberation but no effect,
    # 就直接放棄 R 去補協奏切走。亮的那一下多半是讀屏閃一下、冷卻其實還沒轉完。
    # 現在按了沒反應不放棄: 在等待期限內邊打邊重按, 冷卻剩不到 R_CD_WAIT_RETRY 秒都照等
    R_CD_WAIT_RETRY = 6.0
    NO_R_CON_CAP = 6.0  # 沒 R 時補滿協奏的上限
    # 【10-30 用戶: 三格回路(芳菲信 600)有時候沒打滿就消失, 以前就無腦放 R 切人】
    # 濯雨時 15 秒一到芳菲信直接清零。10-30 log 裡 11 輪有 6 輪是"濯雨時剩 3 秒還沒三格"就放 R 走人,
    # 協奏只有 0.38~0.73。現在沒打滿就不放 R:
    #   1. 先等這段濯雨時結束(芳菲信圖標消失), 等的時候照打, 中途打滿就直接往下走
    #   2. 按住攻擊攢水雲息, 等強化 E「醒春潮」亮了按下去, 重新進濯雨時(三格回路重新出來)
    #   3. 照啟動軸的節奏按 E 落地, 再打到三格滿 -> 等 R 亮 -> 補協奏 -> 放 R -> 切緋雪
    # REFILL_WITH_XCC = False 就退回舊行為(沒打滿照樣放 R)
    REFILL_WITH_XCC = True
    REFILL_TRIES = 1  # 最多重開幾次濯雨時
    REFILL_GAUGE_GONE_WAIT = 1.5  # 濯雨時預計結束之後, 再多等芳菲信消失這麼久
    REFILL_E_WAIT = 10.0  # 等醒春潮亮的上限(水雲息要攢滿, 空手開場實測 4~6 秒)
    CON_CONFIRM = 3  # 連著幾幀讀到夠才算, 單幀特效閃一下不算
    FORTE3_THRESHOLD = 0.75  # 原來 0.6 太鬆會誤判
    FORTE2_THRESHOLD = 0.75
    FORTE3_CONFIRM = 2  # 連續命中這麼多次才認, 單幀誤判不算
    MIN_MISTY_BEFORE_LIB = 3.0  # 剛進濯雨時物理上不可能滿, 這時的命中一定是誤判
    # 芳菲信見過之後連續這麼多幀讀不到, 就認定濯雨時已經關了。
    # 這條判據不依賴 misty_start 記得對不對, 是唯一能兜住"計時基準整個記錯"的東西
    GAUGE_GONE_CONFIRM = 4
    # 啟動軸裡發現"其實已經在濯雨時"要連續命中幾次。寧可晚半秒也不能誤判 ——
    # 誤判的代價是整輪不放醒春潮, 濯雨時壓根沒進
    GAUGE_CONFIRM = 2
    # 開場頭這一段不信芳菲信: 變奏進場時它從 0 開始漲, 物理上到不了 400,
    # 這時的命中只可能是上一個角色的HUD殘影
    MISTY_DETECT_MIN = 1.0
    # 交接標記在 task 上的保質期。只用來兜住"打完標記到 do_perform 之間夾了一次
    # 重進戰鬥", 超過這個就當是上一輪的陳跡
    INTRO_HANDOFF_TTL = 4.0

    SWITCH_TARGET_NAME = 'char_hiyuki'
    # 名字找不到時退回的槽位(1 起算)。隊伍排法: 1 穗穗 / 2 維里奈 / 3 緋雪
    DIRECT_SWITCH_INDEX = 3
    # 誰帶延奏下場時穗穗必須接棒
    FOLLOW_AFTER_NAME = 'char_verina'
    # 強制起手的角色。本場它還沒上過場時, 穗穗空手上場就直接切給它
    OPENER_NAME = 'char_verina'
    # 濯雨時中途借緋雪進場一下再切回來(dps_touch)。改 False 就整段跳過, 穗穗從頭到尾不離場,
    # 但三格回路能量要靠穗穗自己打滿, 循環軸 wait_forte3 會變慢
    DPS_TOUCH = True
    HANDOFF_CON_WAIT = 0.8
    # 上一次延奏後多久內不讓別人把她切回來。取自上游實測: 25秒軸下隊裡有主C時24秒, 沒有時26秒
    MAIN_DPS_OUTRO_LOCKOUT = 24.0
    OUTRO_LOCKOUT = 26.0
    # 【10-30 用戶: 開場沒強制維里奈起手, 緋雪直接打】
    # 起手標記(verina_opener_done)和"本場放過 R2"(hiyuki_r2_used)以前只在 on_combat_end 清,
    # 但 on_combat_end 只有戰鬥結束時在場的那一個人會被叫到, 自動戰鬥中途被停掉/重開(log 07:52 那次)
    # 根本不會走到 —— 標記留著上一場的值: 不強制維里奈、緋雪直接走循環軸。
    # 現在三個角色上場時都先看"全隊上一次有動作是多久以前": 超過 NEW_FIGHT_GAP 秒 = 新的一場,
    # 標記全部重置。輪轉中途是直接切人, 兩個人之間幾乎沒有空檔, 不會誤判
    NEW_FIGHT_GAP = 8.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_outro = -1
        self.misty_start = -1  # 本次進入濯雨時的牆鐘時間
        self._forte3_hits = 0
        # 別人用 handoff_to() 直接切給我時打的標記。不能只靠 has_intro ——
        # reset_state() 每次重讀隊伍都會清它, 而戰鬥判定一抖動就會重進戰鬥重讀隊伍,
        # 於是穗穗以為自己空手入場, 跑去走開場流程(表現就是切過去一直在蓄力重擊)
        self.intro_pending = False
        if self.ring_index < 0:
            # CharFactory 裡穗穗沒寫 ring_index, 環色會被現場猜; 萬一第一次判定發生在
            # 濯雨時特效糊住能量環時會鎖死錯值, 而離場判定完全依賴 is_con_full()
            self.ring_index = Elements.ICE

    def reset_state(self):
        super().reset_state()
        # 【同 __init__ 裡那段註釋, v3.5.32 起必須在這裡重申】: apply_team_char_classes()
        # 的 __dict__.update 會把 ring_index 打回 CharFactory 給的 -1, 環色又變成現場猜,
        # 而穗穗的離場判定完全依賴 is_con_full()。
        if self.ring_index < 0:
            self.ring_index = Elements.ICE
        # 全隊的處決只歸緋雪軸上那一處; direct_switch 失敗退回框架切人時別讓框架替她按 F
        self.check_f_on_switch = False

    # ==================== 鎖定丟失自動重鎖 / 沒怪自動收手 ====================
    # (11-04 用戶, 照心鎖守/心鎖維 v1.0.1 那套搬過來)
    # 站場期間每 NO_ENEMY_CHECK_EVERY 秒讀一次畫面(掛在每一個等待裡: macro_wait / sleep):
    #   Boss 圖示 / 鎖定框在            -> 正常
    #   沒鎖定、但畫面上有怪物血條      -> 每 RELOCK_EVERY 秒按一次中鍵重鎖; 連續 RELOCK_GIVE_UP 秒鎖不到就收手
    #   Boss、鎖定框、血條都讀不到      -> 也每 RELOCK_EVERY 秒按中鍵試著鎖(沒血條的怪); 連續 NO_ENEMY_ABORT 秒就收手
    # Boss 戰只看 Boss 圖示, 不按中鍵(首領挑戰裡鎖定框整局都讀不到)。
    # 按住普攻 / 按住技能鍵的期間不按中鍵: PostMessage 每發一次鍵都投 WM_ACTIVATE, 會把按住打斷。
    # HUD 不在(大招演出 / 變奏入場 / 時停)讀不到, 計時全部從頭算。
    # 收手 = 丟 NoEnemy 例外, 這一圈到此為止, 按住的鍵由各自的 finally 鬆開, 交回框架(脫戰判定由框架接手)。
    # 切人(leave)期間不查: 緋雪 R2 後那段"等下一波再切"有自己的等待邏輯
    NO_ENEMY_ABORT = 5.0         # 0 = 關掉"沒怪自動收手"(重鎖照按)
    NO_ENEMY_CHECK_EVERY = 0.25
    RELOCK_EVERY = 0.40
    RELOCK_GIVE_UP = 4.00

    def enemy_watch_start(self):
        """這一圈開始盯怪。每次 do_perform 呼叫一次。"""
        now = time.time()
        self.enemy_watch = True
        self.enemy_seen_at = now
        self.enemy_check_at = 0.0
        self.unlocked_since = None
        self.relock_n = 0
        self.relock_at = 0.0
        self.attack_held = False
        self.keys_held = 0

    def enemy_watch_stop(self):
        self.enemy_watch = False

    def attack_down(self):
        """按住普攻(記下來, 按住期間不按中鍵)。"""
        self.attack_held = True
        self.task.mouse_down()

    def attack_up(self):
        self.task.mouse_up()
        self.attack_held = False

    def key_down(self, key):
        """按住技能鍵(記下來, 按住期間不按中鍵)。"""
        self.keys_held = getattr(self, 'keys_held', 0) + 1
        self.task.send_key_down(key)

    def key_up(self, key):
        self.task.send_key_up(key)
        self.keys_held = max(0, getattr(self, 'keys_held', 0) - 1)

    def sleep(self, sec, check_combat=True):
        """框架的 sleep, 睡完順手查一次場上還有沒有怪(check_enemy_gone)。"""
        super().sleep(sec, check_combat)
        self.check_enemy_gone()

    def heavy_attack(self, duration=0.6):
        """框架的重擊, 改成按住期間記下來(不按中鍵), 中途收手也一定鬆開。"""
        self.check_combat()
        self.attack_down()
        try:
            self.sleep(duration)
        finally:
            self.attack_up()
        self.sleep(0.01)

    def relock(self, now):
        """按一下中鍵重鎖。按住普攻/技能鍵的時候不按。"""
        if getattr(self, 'attack_held', False) or getattr(self, 'keys_held', 0) > 0:
            return
        if now - self.relock_at < self.RELOCK_EVERY:
            return
        self.relock_at = now
        self.relock_n += 1
        try:
            self.task.middle_click()
        except Exception as e:
            self.logger.info(f'{self.char_name}: middle click failed ({e})')

    def check_enemy_gone(self):
        """見上面那段說明。不刷新畫面, 讀當前幀(等待裡本來就一直在讀畫面)。"""
        if not getattr(self, 'enemy_watch', False):
            return
        now = time.time()
        if now - self.enemy_check_at < self.NO_ENEMY_CHECK_EVERY:
            return
        self.enemy_check_at = now
        t = self.task
        try:
            hud = bool(t.in_team()[0])
        except Exception:
            hud = False
        if not hud:
            self.enemy_seen_at = now
            self.unlocked_since = None
            return
        try:
            boss = bool(t.is_boss())
        except Exception:
            boss = False
        if boss or self.target_visible():
            self.enemy_seen_at = now
            if self.unlocked_since is not None:
                self.logger.info(f'{self.char_name}: 重新鎖定(中鍵 x{self.relock_n}, '
                                 f'{now - self.unlocked_since:.2f}s)')
            self.unlocked_since = None
            self.relock_n = 0
            return
        try:
            bar = bool(t.has_health_bar())
        except Exception:
            bar = False
        if self.unlocked_since is None:
            self.unlocked_since = now
            self.relock_n = 0
        self.relock(now)
        if bar:
            self.enemy_seen_at = now
            if now - self.unlocked_since >= self.RELOCK_GIVE_UP:
                self.enemy_watch = False
                raise NoEnemy(f'有血條但 {now - self.unlocked_since:.1f}s 鎖不到怪'
                              f'(中鍵 x{self.relock_n}, 怪太遠/血條誤讀?)')
            return
        if self.NO_ENEMY_ABORT > 0 and now - self.enemy_seen_at >= self.NO_ENEMY_ABORT:
            self.enemy_watch = False
            raise NoEnemy(f'場上 {now - self.enemy_seen_at:.1f}s 讀不到怪(這一波打完了), 收手')

    def target_visible(self):
        """鎖定目標在不在。照 CombatCheck.has_target() 的前三個讀框, 去掉它最後那個兜底分支 ——
        那個分支會 sleep(1) 再連按兩次 ESC, 不能在軸裡呼叫(同緋雪那份)。"""
        t = self.task
        try:
            has_name, no_name = t.get_target_names()
            for box in (t.get_box_by_name(has_name).scale(1.1), t.get_box_by_name('box_target_enemy_long'),
                        t.get_box_by_name('target_box_long2')):
                best = t.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception as e:
            # 別的 工具 版本這幾個讀框/方法可能改名了: 當成有怪, "沒怪自動收手"失效但不會誤收手
            if not getattr(self, '_target_visible_warned', False):
                self._target_visible_warned = True
                self.logger.warning(f'{self.char_name}: target_visible unsupported in this 工具 version ({e!r}), '
                                    f'assuming a target is there')
            return True
        return False

    def do_perform(self):
        try:
            self._do_perform()
        except NoEnemy as e:
            self.logger.warning(f'suisui turn aborted ({e})')
        finally:
            self.enemy_watch_stop()
            self.mark_team_active()

    def _do_perform(self):
        if self.check_new_fight():
            # 新的一場: 上一場留下來的變奏記號、濯雨時計時全部作廢
            self.has_intro = False
            self.intro_pending = False
            self.misty_start = -1
        if self.flying():
            self.wait_down()

        if self.has_intro or self.intro_pending or self.took_intro_handoff():
            # 變奏技能已經消耗水雲息把她推進濯雨時了, 不用再攢
            self.clear_intro_handoff()
            self.enter_misty_state()
            self.enemy_watch_start()
            return self.hold_axis(opening=False)

        self.clear_intro_handoff()
        if self.in_misty():
            # 上一輪被中途切走但濯雨時還在走: 第一格早就滿了, 直接接後半段
            self.logger.info(f'suisui resuming misty, {self.misty_left():.1f}s left')
            self.enemy_watch_start()
            return self.hold_axis(opening=False, skip_first_bar=True)

        # 強制維里奈起手: 空手上場、本場維里奈還沒起過手 -> 一下都不打, 直接讓給她
        if self.opener_pending() and self.hand_to_opener():
            return

        self.enemy_watch_start()
        return self.hold_axis(opening=True)

    def hold_axis(self, opening=False, skip_first_bar=False):
        """啟動軸 / 循環軸。攻擊鍵從頭按到三格保底, 保底裡沒滿才鬆開改點普攻。

        【按住期間絕對不要再調 mouse_down()】—— 哪怕只是"補按一下保險"。
        PostMessage 後端的 mouse_down() 內部會走 update_mouse_pos() -> try_activate(),
        每次都投一條 WM_ACTIVATE, 窗口收到就會把已經按住的狀態打斷。
        實測代價: 在切人循環裡每發一次切人鍵補按一次, forte3 從 0.5 秒退化到 2 秒往上。
        一次 mouse_down 就夠了, 它會一直有效, 包括跨過切人。
        """
        axis = 'opening' if opening else 'loop'
        self.logger.info(f'suisui {axis} axis: hold attack -> E(land) -> dps touch -> Q -> forte3 -> R')
        axis_start = time.time() if opening else self.switch_in_anchor()
        self.attack_down()
        try:
            # 沒放醒春潮就沒上天, 那一下"按E落地"會變成把她重新頂上天。
            # skip_first_bar(接著上一輪沒走完的濯雨時)這條路這次進場既沒醒春潮也沒變奏, 人在地上
            airborne = not skip_first_bar
            has_misty = True
            if opening:
                if self.hold_until_e_or_misty(self.OPEN_E_WAIT_TIMEOUT) == 'misty':
                    self.adopt_running_misty(axis_start)
                    airborne = False
                else:
                    cast_at = self.cast_xcc()  # 醒春潮: 消耗水雲息進濯雨時
                    if cast_at is None:
                        # 沒進濯雨時: 人在地上, 芳菲信根本不存在, 後面那道保底閘等不到任何東西
                        airborne = False
                        has_misty = False
                    else:
                        # 計時基準是【起作用的那一下】而不是第一下: 被打斷補按過的話兩者差好幾秒,
                        # 按第一下算, 按E落地會掉進下落段(>=3.0 秒完全不出)
                        self.enter_misty_state(at=cast_at)
                        self.sleep(max(0.0, cast_at + self.FIRST_BAR_TIME - time.time()),
                                   check_combat=False)
            elif not skip_first_bar:
                # 循環軸用絕對時刻: FIRST_BAR_TIME_INTRO 是慢放量出來的
                # "變奏入場 -> 該按E"的間隔, 基準必須是上場那一刻
                self.sleep(max(0.0, axis_start + self.FIRST_BAR_TIME_INTRO - time.time()),
                           check_combat=False)
            if airborne:
                self.send_resonance_key()  # 按E落地
                self.sleep(self.E_LAND_TO_SWITCH, check_combat=False)

            touch = self.dps_touch() if self.DPS_TOUCH else 'none'
            if touch == 'out' and airborne:
                # 【只在 'out' 這一種失敗上補】: 沒切過去 = 人還在空中、也還在自己身上,
                # 這時補一發E是安全的。平時不能盲補 —— 地面補E會把她重新頂上天;
                # 'back' 那種失敗人已經在主C身上, 發鍵就是發給主C。
                # airborne=False 那條路根本沒上過天, 'out' 另有原因, 補E只會把她頂飛
                self.logger.info('suisui: still airborne, re-sending E and retrying the touch')
                self.send_resonance_key()
                self.sleep(self.E_LAND_TO_SWITCH, check_combat=False)
                self.dps_touch()

            self.send_echo_key()  # Q
            self.sleep(self.BACK_TO_R, check_combat=False)
            if has_misty:
                full = self.wait_forte3()  # 保底: 三格迴路能量滿才準放R
                refills = 0
                while not full and self.REFILL_WITH_XCC and refills < self.REFILL_TRIES:
                    # 沒打滿三格: 不放 R, 等濯雨時結束後用醒春潮重開一段再打滿
                    refills += 1
                    full = self.refill_with_xcc()
                if not opening or refills:
                    self.wait_r_ready()  # 保底: R 能量偶爾差一點, 接著打到 R 亮
                    self.top_up_con()  # 保底: 放 R 前協奏不到 80 就點普攻補, 否則放完不滿切人沒有變奏
        finally:
            self.attack_up()

        cast = self.cast_field()
        if cast:
            self.sleep(self.POST_LIB_SETTLE, check_combat=False)
            self.leave(assume_intro=True)
            return
        self.logger.warning('suisui: liberation not ready at R time, filling con to full instead')
        self.leave(assume_intro=self.fill_con_without_r())

    def refill_with_xcc(self):
        """三格回路沒打滿: 等這段濯雨時結束 -> 按住攻擊攢水雲息 -> 醒春潮重開濯雨時 -> E 落地 -> 再打三格。
        Returns: 三格滿了沒有。"""
        start = time.time()
        self.logger.warning(f'suisui: forte3 not reached ({self.misty_left():.1f}s misty left), '
                            f'waiting for misty to end, then re-entering with xingchunchao')
        # 1. 等這段濯雨時結束(芳菲信圖標連續讀不到), 等的時候照點普攻; 中途打滿就不用重開
        self.attack_up()
        deadline = time.time() + max(0.0, self.misty_left()) + self.REFILL_GAUGE_GONE_WAIT
        gone = 0
        while time.time() < deadline:
            self.tap_attack()
            self.sleep(max(0.0, self.A_TAP_INTERVAL - self.A_TAP), check_combat=False)
            self.task.next_frame()
            if self.forte3_available():
                self.logger.info(f'suisui: forte3 full while waiting for misty to end '
                                 f'({time.time() - start:.1f}s)')
                return True
            if self.gauge_present():
                gone = 0
            else:
                gone += 1
                if gone >= self.GAUGE_GONE_CONFIRM:
                    break
        self.misty_start = -1
        # 2. 按住攻擊攢水雲息, 等醒春潮亮了放出去, 重新進濯雨時
        self.attack_down()
        try:
            lit_start = time.time()
            while not self.xcc_lit():
                if time.time() - lit_start >= self.REFILL_E_WAIT:
                    self.logger.warning(f'suisui refill: xingchunchao never lit in {self.REFILL_E_WAIT:.0f}s, '
                                        f'giving up ({time.time() - start:.1f}s)')
                    return False
                self.sleep(self.OPEN_POLL)
            cast_at = self.cast_xcc()
            if cast_at is None:
                return False
            self.enter_misty_state(at=cast_at)
            # 3. 跟啟動軸一樣: 醒春潮把她頂上天, FIRST_BAR_TIME 之後按 E 落地, 再打三格
            self.sleep(max(0.0, cast_at + self.FIRST_BAR_TIME - time.time()), check_combat=False)
            self.send_resonance_key()
            self.sleep(self.E_LAND_TO_SWITCH, check_combat=False)
            full = self.wait_forte3()
        finally:
            self.attack_up()
        log = self.logger.info if full else self.logger.warning
        log(f'suisui refill: forte3 {"full" if full else "still not full"} after re-entering misty '
            f'({time.time() - start:.1f}s total)')
        return full

    def fill_con_without_r(self):
        """沒放 R 時把協奏直接點普攻打滿(原本留 20 點給 R 補)。Returns: 打滿了沒有。"""
        start = time.time()
        taps = 0
        while time.time() - start < self.NO_R_CON_CAP:
            self.task.next_frame()
            if self.is_con_full():
                self.logger.info(f'suisui: con full without R (A x{taps}, {time.time() - start:.1f}s)')
                return True
            self.tap_attack()
            taps += 1
            self.sleep(max(0.0, self.A_TAP_INTERVAL - self.A_TAP), check_combat=False)
        full = self.wait_con_full()
        self.logger.warning(f'suisui: con still {self.get_current_con():.2f} after {self.NO_R_CON_CAP:.0f}s '
                            f'without R (A x{taps}), full={full}')
        return full

    def leave(self, assume_intro=False):
        """離場: 優先按數字鍵直接切, 繞開 switch_next_char() 內部那一下多餘的普攻。

        Args:
            assume_intro: 直接認定協奏是滿的。只有"剛放完R"那條路能這麼認 ——
                那時協奏基本一定滿, 而能量環讀數滯後會把 has_intro 誤判成 False。
        """
        self.enemy_watch_stop()
        if not self.direct_switch(assume_intro=assume_intro):
            self.switch_next_char()

    def wait_forte3(self):
        """保底: 三格迴路能量(芳菲信600)沒滿就接著打, 滿了立刻停手。先保持按住 FORTE3_HOLD_GRACE, 還沒滿再改點普攻。

        但等待有物理上限: 濯雨時一關芳菲信【直接清零】, 再等永遠等不到。
        所以窗口只剩 LIB_CAST_RESERVE 時必須停手去放R —— 那不是放棄保底,
        是繼續等已經不可能成功了。
        """
        start = time.time()
        gauge_seen = False
        gauge_gone = 0
        tapping = False
        next_tap = 0.0
        taps = 0
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE3_WAIT:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if not tapping and elapsed >= self.FORTE3_HOLD_GRACE:
                # 按住還沒打滿: 鬆開改點普攻。一直按著就是一下接一下地出重擊
                self.attack_up()
                tapping = True
            # 先點再讀: 讀屏一幀幾十毫秒, 放在點擊前面, 這一格的第一下A就被壓後(心卜穗 09-22"卡頓一下才A")
            if tapping and time.time() >= next_tap:
                self.tap_attack()
                taps += 1
                next_tap = time.time() + self.A_TAP_INTERVAL
            if self.forte3_available():
                how = f' (held {self.FORTE3_HOLD_GRACE:.1f}s, then A x{taps})' if tapping else ''
                self.logger.info(f'suisui forte3 full after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s{how}')
                return True
            # 【不依賴 misty_start 的那道閘】: 芳菲信只在濯雨時存在, 一退出直接清零。
            # 見過又不見了 = 窗口已經關了, 再等永遠等不到。下面那道閘算的是"我記的
            # 開始時刻 + 15 秒", 記錯了(比如變奏進場沒記帳, 起點晚記了好幾秒)就會
            # 一路等到 FORTE3_WAIT 超時, R 落在濯雨時外面 —— 這一條兜的就是那種情況
            if self.gauge_present():
                gauge_seen = True
                gauge_gone = 0
            elif gauge_seen:
                gauge_gone += 1
                if gauge_gone >= self.GAUGE_GONE_CONFIRM:
                    self.logger.warning('suisui: forte gauge wiped, misty is already over '
                                        '(misty_start was wrong), casting R now')
                    return False
            left = self.misty_left()
            if 0 < self.misty_start and left <= self.LIB_CAST_RESERVE:
                self.logger.warning(f'suisui: misty closing ({left:.1f}s left) without forte3, '
                                    f'casting R now before the gauge wipes')
                return False
            self.sleep(0.02 if tapping else 0.1, check_combat=False)
        self.logger.warning(f'suisui forte3 still not full after {self.FORTE3_WAIT:.1f}s, casting anyway')
        return False

    def tap_attack(self):
        """點一下普攻。task.click() 按下和抬起之間一幀都沒有, 遊戲讀不到, 要自己按住幾十毫秒。"""
        self.attack_down()
        try:
            time.sleep(self.A_TAP)
        finally:
            self.attack_up()

    def wait_r_ready(self):
        """三格滿了 R 還沒亮: 接著點普攻打到 R 亮(和 wait_forte3 一樣不按住, 按住會一直出重擊)。

        Returns: R 亮了沒有。沒亮就照原來的路走(不放 R 直接切)。
        """
        if self.liberation_available():
            return True
        self.attack_up()  # wait_forte3 在按住期間就滿了的話, 這裡才鬆開; 已經鬆開了就是空操作
        start = time.time()
        next_tap = 0.0
        taps = 0
        while time.time() - start < self.R_READY_WAIT and self.misty_left() > self.R_MISTY_RESERVE:
            if time.time() >= next_tap:
                self.tap_attack()
                taps += 1
                next_tap = time.time() + self.A_TAP_INTERVAL
            if self.liberation_available():
                self.logger.warning(f'suisui: liberation ready after {time.time() - start:.1f}s more attacking '
                                    f'(A x{taps})')
                return True
            self.sleep(0.02, check_combat=False)
        self.logger.warning(f'suisui: liberation still not ready after waiting {time.time() - start:.1f}s '
                            f'({self.misty_left():.1f}s misty left)')
        return False

    def read_con(self, want, settle):
        """現讀協奏: 自己刷幀, 連著 CON_CONFIRM 幀到 want 就返回, 最多讀 settle 秒。返回讀到的最大值。
        用 task.get_current_con() 每次現讀, 別用角色身上那個讀到過一次滿就一直緩存成滿的。"""
        start = time.time()
        best = 0.0
        hits = 0
        while True:
            self.task.next_frame()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.CON_CONFIRM or time.time() - start >= settle:
                return best
            self.sleep(0.03, check_combat=False)

    def top_up_con(self):
        """放 R 前協奏不到 CON_BEFORE_R 就點普攻補到夠。夠了一下都不點(也不鬆開按住)。

        Returns: 補夠了沒有。沒補夠照樣放 R(總比連 R 都不放強), 日誌裡會留讀數。
        """
        con = self.read_con(self.CON_BEFORE_R, settle=0.15)
        if con >= self.CON_BEFORE_R:
            self.logger.info(f'suisui: con {con:.2f} before R')
            return True
        self.attack_up()
        start = time.time()
        taps = 0
        why = 'cap'
        while time.time() - start < self.CON_TOP_UP_CAP:
            if self.misty_left() <= self.LIB_CAST_RESERVE:
                why = 'misty closing'
                break
            self.tap_attack()
            taps += 1
            self.sleep(max(0.0, self.A_TAP_INTERVAL - self.A_TAP), check_combat=False)
            con = self.read_con(self.CON_BEFORE_R, settle=0.03)
            if con >= self.CON_BEFORE_R:
                why = 'ok'
                break
        log = self.logger.info if why == 'ok' else self.logger.warning
        log(f'suisui: con topped up to {con:.2f} before R (A x{taps}, {time.time() - start:.1f}s, {why})')
        return why == 'ok'

    def switch_in_anchor(self):
        """循環軸的計時基準: 頭像認出"切人完成"的那一刻(handoff_to 寫的 last_switch_in_time)。

        日誌裡那個 gap 就是它和 do_perform 被調用之間的延遲。
        gap 忽大忽小 = 錨對了; gap 每輪都差不多 = 方差另有來源。
        """
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            self.logger.info(f'suisui: anchored on switch-in, {gap:.2f}s ago')
            return anchored
        self.logger.info(f'suisui: switch-in timestamp unusable (gap {gap:.2f}s), using now')
        return now

    def xcc_lit(self):
        """醒春潮可放沒有 —— E 圖標那張強化態模板。

        【只認這一張, 不再和框架通用的 e_forte 取或】: 10-04~10-08 實機 8 次啟動軸,
        E 在 2.0s 前就"亮"的 4 次全是 e_forte 先亮、醒春潮圖標還沒讀到, 之後芳菲信
        6.1~6.7s 才滿; 2.0s 後才亮的 4 次芳菲信 0.6~2.0s 就滿。e_forte 先亮時按出去的
        多半不是醒春潮。心雷穗/心卜穗(10-06 實機)判醒春潮也只認這一張。
        """
        return bool(self.task.find_one(Labels.suisui_e1, threshold=self.XCC_THRESHOLD))

    def cast_xcc(self):
        """按醒春潮, 按到 suisui_e1 消失為止 —— 消失才等於真的放出去了。

        正常情況下按一下就滅, 和原來的單發一模一樣; 只有一下沒滅(被打中/擊倒, 按鍵被丟棄)
        才補下一下。圖標一滅立刻停手, 所以補按落不到濯雨時那個E上。

        Returns:
            起作用那一下的發鍵時刻(濯雨時和按E落地都從它算), 沒放出來返回 None。
        """
        if not self.xcc_lit():
            # 等E超時進來的(10 秒都沒讀到醒春潮圖標): 沒見過"亮"就判不了"滅", 退回原來的單發
            self.send_resonance_key()
            self.logger.info('suisui opening: xingchunchao sent once (suisui_e1 not matched, unverified)')
            return time.time()
        start = time.time()
        n = 0
        while time.time() - start < self.XCC_CAST_CAP:
            self.send_resonance_key()
            pressed = time.time()
            n += 1
            while time.time() - start < self.XCC_CAST_CAP:
                self.sleep(0.03, check_combat=False)
                # HUD 不在(演出/被抓/處決時停)時圖標天然讀不到, 既不能當成"滅了", 也不能接著
                # 盲按 —— 看不見期間補的那一下要是出手了, 認不出是哪一下, 計時基準就錯了
                if not self.task.in_team()[0]:
                    continue
                if not self.xcc_lit():
                    if n == 1:
                        self.logger.info('suisui opening: xingchunchao out')
                    else:
                        self.logger.warning(f'suisui opening: xingchunchao out on press #{n}, '
                                            f'{pressed - start:.1f}s after the first (interrupted)')
                    return pressed
                if time.time() - pressed >= self.XCC_CONFIRM_WAIT:
                    break  # 看得見、還亮著、等夠了: 這一下確實被吞了, 補下一下
        self.logger.warning(f'suisui opening: xingchunchao still lit after {n} presses / '
                            f'{self.XCC_CAST_CAP:.0f}s, not in misty this round')
        return None

    def hold_until_e_or_misty(self, timeout):
        """啟動軸開頭按住攻擊鍵攢水雲息, 等兩件事裡先發生的那個。按下/鬆開由調用方管。

        第二個條件是這次改動的重點。空手開場時芳菲信不可能漲 —— 它只在濯雨時存在。
        所以"等E的過程中芳菲信漲起來了"只有一個解釋: 這次進場其實是帶變奏的,
        只是記帳沒傳過來。框架的 switch_healer() -> switch_other_char() 就是這麼一條
        路: 它只改 is_current_char, 既不設 has_intro 也不走 handoff_to(), 誰被它切上場
        誰就以為自己是空手進的。

        Returns:
            'e'      E亮了 —— 正常的空手開場, 接著放醒春潮
            'misty'  已經在濯雨時裡了, 醒春潮不能按
            ''       兩個都沒等到, 按超時處理(照原樣放醒春潮)
        """
        start = time.time()
        gauge_hits = 0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= timeout:
                break
            if self.xcc_lit():
                self.logger.info(f'suisui opening: e ready after {elapsed:.1f}s')
                return 'e'
            if elapsed >= self.MISTY_DETECT_MIN and self.gauge_present():
                gauge_hits += 1
                if gauge_hits >= self.GAUGE_CONFIRM:
                    self.logger.warning(f'suisui opening: forte gauge filling at {elapsed:.1f}s '
                                        f'-> already in misty, the intro handoff was lost')
                    return 'misty'
            else:
                gauge_hits = 0
            self.sleep(self.OPEN_POLL)
        self.logger.info(f'suisui opening: timed out waiting for e ({timeout:.1f}s)')
        return ''

    def gauge_present(self):
        """芳菲信到沒到 400 檔。兩張圖取或: 400 和 600 在圖上是兩個狀態,
        只查 forte2 會在滿 600 的那幾秒讀成"沒有"。"""
        return bool(self.task.find_one(Labels.suisui_forte2, threshold=self.FORTE2_THRESHOLD)) \
            or bool(self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD))

    def adopt_running_misty(self, started_at):
        """認領一段已經在跑的濯雨時(帶變奏進來但記帳丟了的那種)。

        起點只能取"上場那一刻"這個近似 —— 真正的起點是變奏技能生效那一瞬, 拿不到。
        寧可估早不估晚: 估早了最多提前去放R, 估晚了會一路等到芳菲信被清零, 整輪報廢。
        """
        self.misty_start = started_at
        self._forte3_hits = 0
        self.logger.info(f'suisui: adopting the misty already running, '
                         f'{self.misty_left():.1f}s left counting from switch-in')

    def enter_misty_state(self, at=None):
        self.misty_start = time.time() if at is None else at
        self._forte3_hits = 0

    def in_misty(self):
        return self.misty_start > 0 and self.misty_left() > self.LIB_CAST_RESERVE

    def misty_left(self):
        """濯雨時還剩多少秒。用牆鐘: 這是遊戲側的15秒, 不能扣動畫凍結時間。"""
        if self.misty_start <= 0:
            return -1
        return self.MISTY_WINDOW - (time.time() - self.misty_start)

    def dps_touch(self):
        """切主C入場, 到位之後立刻把場子要回來。

        要的只是"主C進場"這個事件本身, 不是讓她打輸出 —— 所以切過去一幀都不等。
        回程可能撞上切人硬直, switch_to_index 會一直重發直到放行。整個來回攻擊鍵都按住。

        Returns:
            'ok'   來回都成功
            'out'  沒切過去。幾乎只有一個原因: 落地E沒生效人還在空中。
                   這是【唯一】可以補一發E重試的情況 —— 人還在自己身上
            'back' 切過去了但沒切回來。這時發任何鍵都是發給主C的, 絕對不能補E
            'none' 隊裡沒有主C
        """
        dps = self.main_dps_teammate()
        if dps is None:
            return 'none'

        start = time.time()
        here = self.index
        if not self.switch_to_index(dps.index, timeout=self.DPS_TOUCH_OUT_TIMEOUT):
            self.logger.info('suisui: failed to switch to dps, skip')
            return 'out'
        out_done = time.time()
        if not self.switch_to_index(here, timeout=self.DPS_TOUCH_BACK_TIMEOUT,
                                    resend=self.SWITCH_KEY_RESEND_BACK):
            self.logger.warning('suisui: failed to switch back from dps, leave it to the framework')
            return 'back'
        # 來回兩程分開記: 總時長兩條軸一樣, 想知道慢的是哪一程
        self.logger.info(f'suisui: dps touch done in {time.time() - start:.1f}s '
                         f'(out {out_done - start:.2f}s, back {time.time() - out_done:.2f}s)')
        return 'ok'

    def switch_to_index(self, index, timeout=None, resend=None):
        """按數字鍵切到指定隊伍位置, 重發到 in_team 確認切過去了為止。

        【輪詢快、重發慢】: 以前共用一個 0.12 秒的節奏, 於是切換已經生效但 in_team()
        還沒反映出來的那兩三幀裡又多發了幾次同一個鍵, 那些鍵排在隊裡會在已經切回穗穗
        之後再觸發一次。不管攻擊鍵 —— 調用方全程按住, 這裡不該動它。
        """
        timeout = self.DPS_TOUCH_OUT_TIMEOUT if timeout is None else timeout
        resend = self.SWITCH_KEY_RESEND if resend is None else resend
        start = time.time()
        last_send = 0.0
        while time.time() - start < timeout:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                return True
            if time.time() - last_send >= resend:
                self.task.send_key(index + 1)
                last_send = time.time()
            self.sleep(self.SWITCH_POLL, check_combat=False)
        return False

    def direct_switch(self, assume_intro=False):
        """按數字鍵直接切給交棒對象, 並按框架約定標記離場。"""
        target = self.switch_target()
        if target is None or target is self:
            return False
        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'suisui direct switch to slot {target.index + 1} failed')
            return False
        self.logger.info(f'suisui direct switched to slot {target.index + 1} (intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def handoff_to(self, target, has_intro):
        """復刻 switch_next_char() 內部那套交接記帳。直接按數字鍵切人繞開了框架邏輯,
        不補的話沒人的 is_current_char 是 True, get_current_char() 返回 None 會崩。

        Args:
            has_intro: 離場時協奏是否滿, 必須在按切人鍵之前讀好 ——
                切走之後能量環顯示的已經是新角色的了。
        """
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        # 這一行是框架 _choose_switch_target() 裡設的, 漏了它接場角色的 has_intro
        # 永遠是 False
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暫輪詢協奏是否滿。不能只讀一次: 放完大招那一刻協奏其實已經滿了,
        但能量環讀數滯後, 讀成 0 就會把 has_intro 判成 False。"""
        if self.task.wait_until(self.is_con_full, time_out=self.HANDOFF_CON_WAIT):
            return True
        self.logger.info('suisui: con not full before switch, next char gets no intro')
        return False

    def switch_target(self):
        """交棒對象: 先按角色名找(不假設隊伍順序), 找不到再退回寫死的槽位。"""
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == self.SWITCH_TARGET_NAME:
                return char
        index = self.DIRECT_SWITCH_INDEX - 1
        return next((c for c in self.task.chars if c is not None and c.index == index), None)

    def cast_field(self):
        """共鳴解放「山河水境」: 30秒領域, 效應上限+3。
        R 沒亮或按了沒反應, 就邊點普攻邊等、亮了再按: 冷卻剩不到 R_CD_WAIT_RETRY 秒就等到冷卻好(+0.5 秒),
        讀不到冷卻就最多等 R_CAST_GRACE 秒。"""
        start = time.time()
        cd = self.task.get_cd('liberation')
        deadline = start + (cd + 0.5 if 0 < cd <= self.R_CD_WAIT_RETRY else self.R_CAST_GRACE)
        tries = 0
        while True:
            self.task.next_frame()
            if self.liberation_available():
                tries += 1
                # click_f=False: 這個參數默認 True, 意思是"大招動畫期間每 0.1 秒發一次F"。
                # 她的R動畫 4.3 秒, 等於替全隊按掉四十來次處決 —— 主C軸上那個F位就是被這些
                # 自動F提前吃掉的。全隊的處決只歸主C自己那一個點管
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    note = f' after {time.time() - start:.1f}s (press #{tries})' if tries > 1 or \
                        time.time() - start > 0.3 else ''
                    self.logger.info(f'suisui field deployed{note}')
                    return True
                # 按了沒反應: 冷卻其實沒好, 重讀一次冷卻把期限往後推
                cd = self.task.get_cd('liberation')
                if 0 < cd <= self.R_CD_WAIT_RETRY:
                    deadline = max(deadline, time.time() + cd + 0.5)
            if time.time() >= deadline:
                self.logger.warning(f'suisui: liberation not out after {time.time() - start:.1f}s '
                                    f'({tries} presses, cd {self.task.get_cd("liberation"):.1f}s)')
                return False
            self.tap_attack()
            self.sleep(max(0.0, self.A_TAP_INTERVAL - self.A_TAP), check_combat=False)

    def forte3_available(self):
        """芳菲信是否滿600。兩道保險防誤判導致提前開R: 連續命中才認;
        剛進濯雨時不足 MIN_MISTY_BEFORE_LIB 秒直接判否(物理上不可能滿)。"""
        if 0 < self.misty_start and (time.time() - self.misty_start) < self.MIN_MISTY_BEFORE_LIB:
            return False
        if not self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD):
            self._forte3_hits = 0
            return False
        self._forte3_hits += 1
        return self._forte3_hits >= self.FORTE3_CONFIRM

    def switch_out(self, con_full=False):
        if con_full or self.current_con == 1:
            self.last_outro = time.time()  # 只有協奏滿離場才真的放出了延奏
            self.misty_start = -1  # 延奏會退出濯雨時
        super().switch_out(con_full=con_full)

    def check_new_fight(self):
        """全隊上一次有動作超過 NEW_FIGHT_GAP 秒 = 新的一場: 重置起手標記和"本場放過 R2"。Returns: 是不是新的一場。"""
        now = time.time()
        last = getattr(self.task, 'team_last_active', 0) or 0
        new = last <= 0 or now - last > self.NEW_FIGHT_GAP
        if new:
            self.task.verina_opener_done = False
            self.task.hiyuki_r2_used = False
            self.task.hiyuki_intro_handoff = 0
            self.task.suisui_intro_handoff = 0
            idle = f'{now - last:.0f}s' if last > 0 else 'first run'
            self.logger.info(f'{self.char_name}: new fight (team idle {idle}), opener re-armed')
        self.task.team_last_active = now
        return new

    def mark_team_active(self):
        self.task.team_last_active = time.time()

    def note_intro_handoff(self):
        """被別人用直接切人的方式交接進場時調用 —— 記下"我是帶著變奏上來的"。

        標記同時寫在 task 上: 掛在 self 上的那份只扛得住 reset_state()(它不清自定義字段),
        扛不住 load_chars() 把角色對象整個換掉 —— 頭像識別一抖動就會重建實例,
        新實例的 intro_pending 是 __init__ 裡那個 False。task 活得比角色對象長。
        """
        self.intro_pending = True
        self.task.suisui_intro_handoff = time.time()

    def took_intro_handoff(self):
        stamp = getattr(self.task, 'suisui_intro_handoff', 0) or 0
        return 0 < stamp and time.time() - stamp <= self.INTRO_HANDOFF_TTL

    def clear_intro_handoff(self):
        self.intro_pending = False
        self.task.suisui_intro_handoff = 0

    def on_combat_end(self, chars):
        # 只清當前這場戰鬥的狀態, 不清 last_outro 這類時間戳(它自己會過期,
        # 主動清零反而會讓鎖定期失效)。也不要放進 reset_state(): 那個鉤子每次
        # 重新識別隊伍都會觸發, 會在戰鬥中途把濯雨時的計時和鎖定期一起抹掉
        self.misty_start = -1
        # 緋雪的"本場放過R2"存在 task 上, 戰鬥結束時誰在場誰負責清
        self.task.hiyuki_r2_used = False
        # 下一場重新強制維里奈起手
        self.task.verina_opener_done = False

    def opener_char(self):
        return next((c for c in self.task.chars if c is not None and c is not self
                     and c.char_name == self.OPENER_NAME), None)

    def opener_pending(self):
        """本場維里奈還沒起過手(她 do_perform 一開始就會把標記設成 True)。隊裡沒有她就不強制。"""
        if getattr(self.task, 'verina_opener_done', False):
            return False
        return self.opener_char() is not None

    def hand_to_opener(self):
        """一下都不打, 直接切給維里奈起手。切不過去就返回 False, 照原流程走啟動軸。"""
        target = self.opener_char()
        if target is None:
            return False
        self.logger.info('suisui: opener pending, handing the field to verina')
        if not self.switch_to_index(target.index):
            self.logger.warning(f'suisui: switch to verina (slot {target.index + 1}) failed, playing on')
            return False
        self.handoff_to(target, False)
        return True

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        lockout = self.MAIN_DPS_OUTRO_LOCKOUT if self.main_dps_teammate() else self.OUTRO_LOCKOUT
        if self.time_elapsed_accounting_for_freeze(self.last_outro) < lockout \
                and self.has_other_candidate(current_char):
            return SwitchPriority.NO
        # 只接維里奈的延奏。要求 has_intro 是有意的 ——
        # 她的變奏技能本身就把她推進濯雨時, 沒有變奏的入場要先花 4~6 秒攢水雲息。
        # 其他情況讓位, 尤其是緋雪那一棒: 緋雪的延奏是留給維里奈的
        if current_char is not None and current_char.char_name == self.FOLLOW_AFTER_NAME and has_intro:
            return SwitchPriority.MUST
        if self.has_other_candidate(current_char):
            return SwitchPriority.NO
        return SwitchPriority.MUST

    def main_dps_teammate(self):
        return next((char for char in self.task.chars
                     if char is not None and char is not self and char.is_main_dps), None)

    def has_other_candidate(self, current_char):
        """返回 NO 之前確認還有別人能上, 否則切人邏輯會卡在原地空轉。"""
        return any(char is not None and char is not self and char is not current_char
                   for char in self.task.chars)