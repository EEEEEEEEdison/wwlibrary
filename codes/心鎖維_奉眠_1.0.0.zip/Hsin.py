import base64
import ctypes
import threading
import time

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Hsin import Hsin as NativeHsin

# ==================== 物理 F 鍵監視 ====================
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按鍵按住的時間遠大於這個, 不會漏採
F_LOG_DEBOUNCE = 1.0     # 按住不放時別刷日誌
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """讀介面上的(開關, F 之後等待秒數)。沒裝那張卡片就返回預設值(開, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自動戰鬥開關監視 ====================
# 【玩家手動開關自動戰鬥, 必須從啟動軸重跑】。手動停任務不走 combat_end(), opener_armed 會跨局留在
# False, 而角色物件常被黏性複用、reset_state() 不跑。只有獨立執行緒能觀察到 enabled 的 True->False->True。
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳變, 把時刻記到 task._ww_task_restarted_at。每個 task 只啟一次。"""
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='tool_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 鍵按下的牆鐘時間記到 task._f_last_press。每個 task 只啟一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # -1 = 從沒按過, 跟 last_opener 的「沒跑過」對齊(給 0 的話開局第一次判定恆成立)
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    # 宏正在跑 = 正在戰鬥, 這下 F 是玩家手動處決, 不是重開副本
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='tool_f_watch', daemon=True).start()


# ==================== SendInput 左鍵(心的兩段長按用) ====================
_INPUT_MOUSE = 0
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong),
                ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong),
                ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamH', ctypes.c_ushort), ('wParamL', ctypes.c_ushort)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [('ki', _KEYBDINPUT), ('mi', _MOUSEINPUT), ('hi', _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('u', _INPUTUNION)]


def send_input_left(up):
    """系統級左鍵按下/抬起。返回是否發出去了(發不出去呼叫端退回 PostMessage)。"""
    try:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(0, 0, 0, _MOUSEEVENTF_LEFTUP if up else _MOUSEEVENTF_LEFTDOWN, 0, 0)
        return ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) == 1
    except Exception:
        return False


class MacroBroken(Exception):
    """某一步切人沒成功 / HUD 長時間不在 / 場上沒怪了, 後面的按鍵會落空或落在錯的人身上 —— 整圈放棄, 交回框架。"""


class Hsin(NativeHsin):
    """心。心鎖維(心/鎖暝/維里奈)裡她兼任【整條軸的持宏者】, 三個人的 do_perform 都轉到 drive()。

    ================= 出處 =================
    11-02 從心鎖守 LQ 版(長風ei 11w 輪切軸)改出來: 守岸人的位置換成維里奈, 心/鎖暝兩段原樣。
    心鎖守的 V1 軸、守岸人段落都刪了(這隊用不到)。程式【按角色切人】, 編隊怎麼排都行。
    11-03 加【鎖定丟了就重鎖 / 沒怪就收手】(check_enemy_gone): 宏跑的時候 skip_combat_check=True,
    框架的脫戰偵測和中鍵重鎖整圈都關著, 怪死了後面「打到條件滿為止」的步驟會一路空揮到各自上限。
    11-04 讀不到怪(沒鎖定 + 沒血條)時也按中鍵試著鎖定, 鎖到就照打, NO_ENEMY_ABORT 內鎖不到才收手。
    11-03 刻心念按住上限 4.0 -> 2.4(光圈只在鬆手收招後才出, 按滿 4s 是白轉)。
    心的形態(心1/心2)不在程式裡檢查: 大世界連打換場前人工確認心的 R 位是轉相圖示再開自動戰鬥。

    ================= 軸的形狀 =================
    啟動軸: 維 Q-E-R -> 打到協奏真滿 -> 變奏鎖暝 (seg_vr)
    循環軸: 維(變奏入場) Q-E-R -> [有處決提示就處決] -> 打到協奏真滿 -> 變奏鎖暝 (seg_vr)
    之後兩條一樣:
      鎖暝 (變奏·閃裂, 念起 -> 念深) [R 沒好就一直 A 到好] R -> 演完 -> 點一下 A -> Q(暗鳥) -> 【同奏】切心 (seg_lq_so_a)
      心   (變奏·應世相) 聲骸 -> 花圖示亮了就按住, 沒亮先點 A -> 步紅塵 -> 連按 R 轉相 -> 演完照世相 E -> 【同奏】切鎖暝 (seg_xn1)
      鎖暝 (旋雷破·同奏 +200 妄執) 點 A 到妄執滿 -> 點 E(無捨念) -> 【按住普攻】刻心念轉滿 -> 協奏滿變奏心 (seg_lq_so_b)
           【協奏不滿不切】: 接著 A, 妄執滿了再出無捨念/刻心念, 光圈出來才變奏心 (so_ensure_intro)
      心   (變奏·照世相, 統御眾機) A 到第 5 顆雕像 -> 閃避 -> A 到第 7 顆 -> 按住(臨寰宇) -> [沒怪就中鍵鎖敵等 <=3s]
           -> 萬闕垂天 -> 按過白屏時停出重擊 -> E -> 協奏滿變奏維 (seg_xn2)
    宏在【維里奈變奏入場、HUD 回來】時返回, 下一次框架呼叫的就是她。返回點不落在任何演出裡。

    ================= 為什麼這麼打 =================
    - 【鎖暝靠同奏串】: 維交棒協奏要真滿 -> 鎖暝變奏·閃裂進念深, 念深才有 R; 鎖暝 R 給 5s 同奏 -> 心變奏·應世相;
      心轉相給同奏 -> 鎖暝旋雷破·同奏(+200 妄執); 鎖暝刻心念協奏滿 -> 心變奏·照世相直接進統御眾機(+300 照世心)。
      任何一棒協奏不滿 = 下一個人普通入場, 這一圈後面全散。所以每一棒交棒都只認頭像光圈。
    - 【心要共鳴模態·同奏】(電磁模態沒有同奏那兩樣)。鎖暝帶暗鳥。
    - 【維里奈不吃輪軸時間】她只負責 QER + 補協奏, 交棒點全看光圈; 打滿協奏的動作照使用者其他配對的維里奈:
      E/R 能放就放 -> 迴路滿就重擊 -> 普攻 5 下 -> 跳 + 空中 3 下, 循環。

    ================= 心的判據 =================
    - 應世心條: 迴路條中間徽記兩邊的紫色格子, 左半 0~50、右半 50~100。變奏入場給 60(左半滿)。
    - 【應世心滿 = hsin_h1(重擊位的花圖示)】: 滿了條變成粉紅高柱, 紫色判據讀成 0.4 上下, 只能認圖示。
    - 【照世相裡 R 一直是亮的】(借相·應世), 萬闕垂天解鎖【只能認 hsin_lib2 模板】 —— 拿「R 亮了」去按會放出借相。
    - 臨寰宇出手 = 隊伍 HUD 消失(~2.0s)。照世心雕像計數照抄心雷穗 v1.1.0。

    ================= 鎖暝的判據 =================
    - 妄執滿 = 框架的 suoming_forte_e 模板(E 位換成鎖妄念/無捨念)。妄執條的顏色讀數被特效污染, 不用。

    ================= 改這個檔案之前先讀 =================
    - 【自訂 __init__ 裡跟內建版不同的欄位會被打回內建值】, 要保住就在 reset_state() 裡重申。
    - 普攻一律走 tap()(按住 A_TAP 秒): task.click() 只按 10ms, 打不出來。
    - 長按期間不呼叫 click()/mouse_down()/send_key() —— 它們先投 WM_ACTIVATE, 會把按住打斷(中鍵重鎖也一樣, 會讓開)。
    - 名字帶 SK_ / sk 的常數和函式是從心鎖守沿用的通用部分(切人等入場演出、處決、協奏判定), 這隊裡指的是維里奈。
    """

    # ==================== 全域節奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10
    A_TAP = 0.06                 # 普攻按住這麼久才算一下; task.click() 的 10ms 會被吞

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True

    # ---- 大招 / 演出 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_ANIM_TIME_OUT = 8.0
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 連續這麼多幀不在 = 演出真的開始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在場的上限(防假成功)
    # 【演出中途 HUD 會閃一兩幀】等「HUD 回來」時要連讀到這麼多幀才算, 演出開始後不到 min_gone 秒的「回來」一律不認
    HUD_BACK_CONFIRM = 2

    # ---- 雜項 ----
    CON_SAMPLE_MAX = 24
    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40      # 剛切進來多久沒見過技能亮就當它在 CD 上

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0
    # 【物理 F 重新武裝啟動軸】True = 啟動軸跑過之後按 F 也會重跑啟動軸(重開副本用)。
    # 宏不在跑的空檔按 F(撿東西/對話)也會被當成重開; 遇到誤觸就改 False, 只靠「關/開自動戰鬥」重跑
    F_REARM_OPENER = True

    # ==================== 保底 ====================
    SWITCH_RETRIES = 2           # 切人逾時後先等 HUD 回來再切, 最多再試這麼多次(被擊飛/硬直時遊戲不放人)
    SWITCH_RETRY_TIME_OUT = 3.00
    HUD_LOST_ABORT = 8.00        # 隊伍 HUD 連續這麼久沒見過 = 關卡結束/過場/視窗沒了, 整圈放棄(最長的演出 4.3s)
    DRIVE_HUD_CAP = 1.50         # 框架呼叫進來時 HUD 這麼久都不在就什麼都不做(結算畫面上框架還會一直呼叫進來)
    # 【沒怪就收手 / 鎖定丟了就重鎖】宏跑的時候 skip_combat_check=True, 框架的脫戰偵測和中鍵重鎖整圈都關著。
    # has_health_bar() 是整個畫面找紅色血條: 鎖定的那隻死了、遠處還有別的怪 -> 讀成「有怪」, 但沒人重鎖, 對空氣打。
    # 鎖到之後鏡頭自己轉過去, 攻擊的位移會把人帶回怪那邊, 不用另外走。
    # Boss 戰不重鎖: 首領挑戰裡 target_visible() 整局都是 False(10-25 錄屏), 只看 is_boss()
    NO_ENEMY_ABORT = 5.0         # HUD 在場、連續這麼久什麼怪都讀不到 = 這一波打完了, 整圈放棄; 0 = 關(海墟換波要留時間)
    NO_ENEMY_CHECK_EVERY = 0.25
    RELOCK_EVERY = 0.40          # 有血條沒鎖定: 每這麼久按一次中鍵(按住普攻期間不按, 會把按住打斷)
    RELOCK_GIVE_UP = 4.00        # 有血條、連續這麼久鎖不到(怪太遠/血條誤讀) = 整圈放棄, 交回框架
    # 【協奏真滿看頭像光圈】協奏滿(切人能變奏)那一幀, 另外兩個人的頭像外面套上一圈細白環往外擴。
    # 框架的協奏環讀數快滿就報 1.00(比真滿早 0.5~1.8s), 光圈跟真滿同一幀出來。只看另外兩格。
    GLOW_BOTH = 0.15             # 兩格都 >= 這個, 而且有一格 >= GLOW_ONE
    GLOW_ONE = 0.35
    GLOW_SOLO = 0.60             # 一格就夠
    GLOW_CONFIRM = 2
    # ---- 協奏讀數(名字沿用心鎖守) ----
    SK_CON_ENOUGH = 1.0          # 0.99 是環沒閉合的哨兵值, 要真滿
    SK_CON_FULL_CONFIRM = 3
    SK_CON_POLL = 0.03

    # ==================== 切給維里奈(心2 -> 維) ====================
    # 沿用心鎖守的 switch_to_sk: 切人後不管判沒判到到場, 都等 HUD 回來再認一次場上是誰(變奏入場可能藏 HUD)
    SK_INTRO_ANIM_CAP = 6.0
    SK_INTRO_NOANIM = 0.35
    SK_SWITCH_ANIM_HINT = 1.00   # quick_switch 超過這麼久才判到到場 = 變奏入場的演出已經在裡面演完
    SK_TO_TIME_OUT = 4.00        # 心 -> 維: 萬闕垂天收招沒完遊戲不放人

    # ==================== 處決(維里奈上場時) ====================
    # 只在怪身上的 F 提示(螢幕中間 f_break >= 0.90, 不是拾取 F)在的時候按 F。
    # 外圈滿著(或者切人前心身上讀到過提示)才盯到 HUD 回來後 SK_BREAK_UNTIL; 都沒有只讀 BREAK_READS 幀。
    # BREAK_ANIM 是按守岸人處決動畫量的, 維里奈不一定一樣; 處決後動作接不順就先關 SK_BREAK
    SK_BREAK = True
    SK_BREAK_UNTIL = 1.20
    BREAK_READS = 3
    BREAK_CENTER_MIN = 0.90
    BREAK_RING_MIN = 0.92
    BREAK_SEEN_FRESH = 5.00      # 切維之前心身上讀到的提示, 到維 HUD 回來這麼久之內算數
    BREAK_RESEND = 0.30          # 按完這麼久提示還在 = 被吞了, 再按
    BREAK_PRESSES = 5
    BREAK_GONE_FRAMES = 3        # 提示單幀會掉到 0.85~0.88(特效閃), 連這麼多幀不見才算處決起手了
    BREAK_ANIM = 1.55
    BREAK_ROUNDS = 2             # 等完動畫提示還在 = 那一下沒處決上, 再來一輪

    # ==================== 維里奈 ====================
    # 啟動軸、循環軸同一套: Q -> E -> R -> [處決] -> 打到協奏真滿 -> 變奏鎖暝
    VR_ENTRY_LEAD = 0.30         # 切人鍵 -> 開始按技能(變奏入場的動作裡按的被吞, press_*_until_cd 會一直按到進 CD)
    VR_JUMP_KEY = 'space'
    VR_A_EVERY = 0.23            # 地面普攻間隔
    VR_PRE_JUMP_A = 5            # 每輪跳躍前的地面普攻段數
    VR_JUMP_RISE = 0.15          # 起跳後多久出手(確保判定為空中攻擊)
    VR_AIR_COUNT = 3             # 空中普攻段數(遊戲上限 3)
    VR_AIR_EVERY = 0.20
    VR_LAND = 0.30               # 空中 3 下打完等落地
    VR_HEAVY_HOLD = 0.70         # 迴路滿時的重擊按住時長
    VR_HEAVY_GAP = 2.00          # 兩次重擊最短間隔(防迴路讀數誤判連按)
    VR_SKILL_CAP = 1.00          # E/R 按到進 CD 的上限
    VR_Q_CAP = 0.60              # 聲骸按到進 CD 的上限(循環軸變奏入場裡按的被吞, 讀不到進 CD 也別站著等; 11-02 實機 L1/L2 撞 1.0s 上限)
    VR_R_ANIM_CAP = 5.00         # R 若有演出(藏 HUD), 等它回來的上限
    VR_CON_CONFIRM = 2           # 協奏讀數 1.00 連這麼多次才算(光圈另算)
    # 【交棒只認光圈】鎖暝要變奏入場(閃裂進念深)才有 R。光圈本局認出過: 讀數不算; 還沒認出過(第一次交棒):
    # 讀數滿了再接著打 VR_CON_READ_GRACE 光圈還不出來才信讀數(認不出光圈的機器)
    VR_GLOW_ONLY = True
    VR_CON_READ_GRACE = 1.50
    VR_OPEN_CON_CAP = 10.0       # 啟動軸打協奏上限(開局從 0 起)
    VR_LOOP_CON_CAP = 8.0        # 循環軸打協奏上限

    # ==================== 鎖暝第一次上場(維變奏進來 = 變奏·閃裂, 念起 -> 念深) ====================
    # R -> 演完 -> 點一下 A -> 暗鳥 -> 同奏切心
    SO_R_LEAD = 0.25             # 切人鍵 -> 開始按 R
    SO_R_ANIM_MIN = 2.50         # 鎖暝大招藏 HUD(實機 4.9s)
    SO_R_ANIM_CAP = 8.00
    LQ_SO_A_TAPS = 1             # R 演完點幾下普攻再放暗鳥
    # R 沒好(CD / 能量不夠)不站著等(so_r_asap): 一直點 A, 每下 A 後順手按一下 R, 讀到亮再連按一小段
    LQ_SO_R_CAP = 9.00
    LQ_SO_R_ENTRY = 1.70         # 切人鍵起這麼久是閃裂入場動作(實機 R 在切人後 ~1.55s 才出得來): 讀到亮就一直按 R
    LQ_SO_R_BURST = 0.30         # 入場之後讀到亮: 連按 R 這麼久, HUD 沒消失 = 其實還沒好
    LQ_SO_R_BACKOFF = 0.40       # 第 n 次連按沒出之後 n 倍這麼久只點 A
    LQ_SO_R_E_FROM = 1.50        # 沒變奏入場(念起, R 不解鎖)時: 進場這麼久後妄執滿就點 E(鎖妄念進念深)
    # 暗鳥一直按到聲骸進 CD(R 收招裡按的被吞); 同奏 5s 按遊戲時間算
    SO_ECHO_CAP = 1.00
    SO_ECHO_RISE = 1.0           # CD 比按之前高出這麼多秒才算放出去
    SO_A_EVERY = 0.20            # 鎖暝普攻點按間隔

    # ==================== 心第一次上場(鎖暝 R 的同奏 -> 變奏·應世相) ====================
    # 聲骸 -> [普攻補滿應世心] 按住步紅塵 -> 轉相 -> 照世相 E -> 同奏切鎖暝
    LQ_XN1_ECHO = True           # 進場先放聲骸
    LQ_XN1_ECHO_AT = 0.30        # 從切人鍵起: 剛切進來那幾幀技能欄還是鎖暝的
    LQ_XN1_ECHO_CAP = 0.80
    LQ_XN1_E = True              # 轉相演完按一下照世相 E 再切(照世相 E 跟應世相 E 冷卻分開, 不記 last_res)
    LQ_XN1_E_CAP = 1.20
    # ---- 應世心條(4K 座標, hcenter): 迴路條中間徽記左右兩半的紫色格子 ----
    XN_GAUGE_L = (1627, 1999, 1837, 2011)
    XN_GAUGE_R = (1965, 1999, 2175, 2011)
    XN_GAUGE_VALID = 0.50        # 左半 >= 這個才算「在應世相、讀數可信」
    XN_YING_READY = 0.70         # 右半到這麼多就按重擊
    XN_YING_LATE = 0.58          # 到了 XN1_LATE_AT 右半 >= 這個也按
    XN_CONSUMED = 0.15           # 按住之後左半掉到這個以下 = 整條清空 = 步紅塵出手
    XN_FULL_THRESHOLD = 0.70     # hsin_h1(花圖示)模板閾值
    XN_HOLD_SENDINPUT = True     # 心兩段長按走 SendInput(遊戲在前台時)
    # 【上場就滿/差一點】只認花圖示(連 2 幀、場上是心): 沒亮就從切人鍵 XN1_ENTRY_TAP_FROM 起點普攻, 亮了就按住
    XN1_SKIP_A_WHEN_FULL = True
    XN1_FULL_FROM = 0.20
    XN1_FULL_HOLD_AT = 0.50
    XN1_ENTRY_TAP_FROM = 0.70
    # XN1_SKIP_A_WHEN_FULL 關掉時走宏表: 切人鍵後 XN1_A1_AT 第一下, 之後連點到應世心到線
    XN1_A1_AT = 1.05
    XN1_A_HOLD = 0.08
    XN1_TAP_EVERY = 0.25
    XN1_MIN_A = 2
    XN1_LATE_AT = 2.15
    XN1_BLIND_AT = 2.15          # 到這一刻條一次都沒讀出來: 不猜, 照按
    XN1_FILL_CAP = 4.00          # 條一直不夠的上限, 到了照按
    XN1_FILL_EVERY = 0.40
    XN1_GAUGE_CONFIRM = 2
    XN1_HOLD_NOT_BEFORE = 1.50
    XN1_HOLD = 1.80              # 按住時長。步紅塵免疫打斷, 演出裡一直按著沒有壞處
    XN1_RETRIES = 2              # 按滿 XN1_HOLD 條都沒清空(= 出的是普通重擊) -> 補 A 再按
    XN1_RETRY_A = 2
    # 按住期間花圖示才亮 = 這一下多半已經是普通重擊 -> 立刻鬆開重按
    XN1_STALE_MIN = 0.95
    XN1_STALE_FULL = 0.45
    XN1_STALE_MAX = 1
    # 【不認轉相圖示, 步紅塵鬆手就連按 R 到演出出來】應世相裡轉相沒解鎖時按 R 什麼都不發生
    XN1_R1_SPAM = 2.50
    XN1_R1_UNLOCK = 2.06         # 補救裡用: 應世心清空後 ~2.06s 轉相解鎖
    XN1_R1_MARGIN = 0.08
    XN1_R1_READS = 2
    XN_R_WINDOW = 1.50           # R 連按到 HUD 消失的窗口
    XN1_ECHO = False             # 轉相前不放聲骸(LQ 聲骸在進場放)
    # 【轉相一定要放出來】第一次沒出就補到出為止: 轉相亮 -> 按; 應世心滿 -> 再按住出步紅塵; 都不是 -> 普攻攢應世心
    XN1_R1_RESCUE_CAP = 8.00
    XN1_R1_RESCUE_A = 0.80
    XN1_R1_LOST_ROUNDS = 3       # 連著這麼多輪既看不到轉相圖示也讀不到應世心條 = 已經不在應世相(轉相其實出了)
    XN_R_ANIM_MIN = 3.90         # 轉相/萬闕垂天演出藏 HUD 4.3s, 中途會閃一幀
    XN_R_ANIM_CAP = 7.00

    # ==================== 鎖暝第二次上場(心轉相的同奏 -> 旋雷破·同奏, 念深 +200 妄執) ====================
    # 點 A 到妄執滿 -> 無捨念 -> 按住刻心念 -> 協奏滿變奏心
    LQ_SO_B_A_LEAD = 0.10
    LQ_SO_B_FILL_CAP = 7.00      # 實機正常 A x18~20, 4.2~4.3s
    SO_KX_E_EVERY = 0.10         # E 位還是無捨念就這麼密地點 E
    SO_KX_E_TAP = 0.05           # 一下 E 按住這麼久(10ms 的會被吞)
    SO_KX_WUSE_CAP = 2.50        # 無捨念點不出來的上限
    SO_KX_A_FROM = 0.30          # 無捨念出來後這麼久按住普攻(刻心念)
    # 【刻心念按住】按住普攻 = 一直轉陀螺, 轉圈是時停; 光圈出來就鬆, 按下時協奏已經滿著就按滿 LQ_SO_KX_HOLD_BLIND
    LQ_SO_KX_HOLD_MIN = 0.50
    # 4.00 -> 2.40: 光圈只在鬆手收招後才出(11-03 實機 L1~L3 按滿 4.0s 都沒等到, 鬆手後 0.46s 光圈), 影片刻心念 ~2.0s
    LQ_SO_KX_HOLD_CAP = 2.40
    LQ_SO_KX_HOLD_BLIND = 2.40
    # 按住期間 E 位又連 2 幀是無捨念 = 沒放出來: 鬆開, 連點 E 到放出來, 再重新按住
    LQ_SO_KX_E_MAX = 3
    LQ_SO_KX_E_RESCUE_CAP = 6.00
    LQ_SO_KX_FINISH_CAP = 1.00   # 鬆手後不按鍵等協奏真滿的上限, 沒滿走 so_ensure_intro
    SO_KX_GLOW_GRACE = 0.50      # 光圈認得出過時, 讀數滿了再等這麼久沒光圈 = 沒滿
    # 【一定要變奏心】協奏不滿不切, 普攻 + 妄執滿了再出無捨念/刻心念, 光圈出來才走
    LQ_SO_B_ENSURE_CAP = 15.00
    LQ_SO_B_KX_MAX = 2
    LQ_SO_B_READ_GRACE = 2.00
    SO_TO_XN_TIME_OUT = 4.00     # 刻心念收招沒完遊戲不放人

    # ==================== 心第二次上場(鎖暝協奏滿 -> 變奏·照世相, 統御眾機) ====================
    # 3A(第 5 顆)-閃避-2A(第 7 顆按住)-臨寰宇-[沒怪就鎖敵]-萬闕垂天-重擊-E
    XN2_LEAD = 2.50              # 切人後這麼久才開始 A(變奏入場 + 樓閣升起那段打不了)
    LQ_XN2_DODGE_COUNT = 5
    XN2_DODGE_MIN = 1.00         # 從第一下 A 起這麼久之前不認(入場閃光會讓幾顆雕像一起「亮」)
    LQ_XN2_DODGE_CAP = 3.00
    XN2_DODGE_HOLD = 0.07        # 閃避 = 右鍵
    XN2_DODGE_TO_A = 0.03
    XN2_POST_DODGE_A_EVERY = 0.10
    XN2_EMPTY_CAP = 2.80         # 閃避之後普攻到 XN2_HOLD_AT 顆 / 人像出來的上限
    # 【第 7 顆翻完就按住(預輸入)】按住只接著打已經出手的那段, 所以只剩最後 1 顆才按, 再加 XN2_HOLD_STALL 兜底
    XN2_HOLD_AT = 7
    XN2_HOLD_STALL = 1.00
    # 雕像座標/閾值照抄心雷穗 v1.1.0: 4K x, 下半紅菱形 y / 上半亮白 y, 半寬
    XN_STATUE_XS = (1647, 1719, 1794, 1866, 1938, 2013, 2085, 2160)
    XN_STATUE_Y = 1980
    XN_STATUE_UP_Y = 1953
    XN_STATUE_HW = 9
    XN_STATUE_RED = 0.08
    XN_STATUE_GLOW = 0.30
    XN_STATUE_CONFIRM = 2
    XN_STATUE_BURST = 3          # 同一幀新亮 >= 這麼多顆 = 閃光, 這一幀不算
    XN2_HOLD_CAP = 3.00
    XN2_READY_REPRESS = 0.60     # 按住時人像出來這麼久還沒出手就鬆開重按
    XN2_REPRESS_MAX = 2
    XN2_TY_A_EVERY = 0.18
    XN2_READY_CONFIRM = 2
    XN_READY_MIN = 0.80
    XN_READY_GLYPH = (
        'AAAAAAAGGDxjHgwAAAAAAAAAABQoWcH31Vg3Jg0AAAAAACGmh+r9+X82NzlcMgAAAAZ47tD9/c06R2NGZ2cWAAA32P38/f2+N0xtaDY3MQIa'
        '3/v9/v3x4DhNbFk2OEcVYf39/f34yMM4RGJWQjmCKmH9+vW6sa2FPT09WGFLyjZ5/c7E4fWaQD0/UHOX0POeYfmXotjqXz09PkBvmojMUTfc'
        'vZnUhD08PDw9mcfbvzMBauG+pJZJREA9P9L05XAFACb1+/38refMZD3D+oQjAAAAbfn9/tDY/LQ7tOMxAgAAAABU2f7is/y+QMd0AgAAAAAA'
        'AAhcpG3GgygPAAAAAA=='
    )
    XN_TY_MIN = 0.60
    XN_TY_GLYPH = (
        'AAAAAAAMJCEsJBYBAAAAAAAAABiR1cJ40tzbpyYAAAAAABK+4+Pt2unk48BaJAAAAAhQg6aMnN1/l6RzUVEbAAAzV3Dw9crHyvngXlFQRQIJ'
        'VFqs8dbtovLV8JdRUFAdIlmK7ZPT7IT7v6Dtbk9bOzdhj5en/O2E/PmHoXdelTpIsV1Xrv3thPz7iE9XwJuUJsCvW6797YX9+4dTsfjxriWy'
        '9KGQ++2E/fqGnvfU33sBpvjsmt/thPzfmeylk9cPADOnpLzM7IT4tc54Y+FhAAAASGKt+eyD5uiKUbyiBQAAAAAkjf3tg/j6h3aCCQAAAAAA'
        'AAZbpFvGrUwKAAAAAA=='
    )
    XN_TY_SLOT = (2826, 1893, 82, 79)   # 重擊位(4K, 跟 hsin_h1 的標註框一樣)
    XN2_READY_HOLD = 1.20
    XN2_BLIND_HOLD = 2.00
    XN2_RELEASE_AFTER_GONE = 0.30
    XN2_ANIM_MIN = 1.40          # 臨寰宇藏 HUD ~2.0s
    XN2_ANIM_CAP = 4.00
    XN2_RETRIES = 2              # 按住沒出 -> 普攻到人像再按, 最多這麼多次
    XN2_RETRY_CAP = 1.50
    XN2_LIB2_CAP = 0.30          # 臨寰宇演完不點普攻乾看 hsin_lib2 的上限
    XN2_R2_BUILD_CAP = 5.00      # 萬闕垂天圖示沒認出 = 能量不夠, 普攻攢的上限; 撞上限這一輪不放
    XN2_LIB2_READS = 1
    XN2_R2_BLIND = False         # True = 不認圖示盲按(能量不滿會放成借相)
    # 開大前協奏低於 XN2_PRE_R2_CON 就照世相普攻補(實機補不太上, 預設關)
    XN2_PRE_R2 = False
    XN2_PRE_R2_CON = 0.80
    XN2_PRE_R2_CAP = 2.00
    # 【開大前沒怪: 中鍵重新鎖敵, 等新怪最多 XN2_PRE_R2_WAVE_CAP, 時間到照放】
    # 等過之後再認一次萬闕垂天圖示: 認不出 = 已經不是萬闕垂天(按了是借相), 這一輪不放
    XN2_PRE_R2_WAVE = True
    XN2_PRE_R2_LOOK = 0.30
    XN2_PRE_R2_WAVE_CAP = 3.00
    LQ_XN2_ECHO = False          # 心的聲骸在心1 進場放
    XN2_CON_READ = 0.20
    XN2_CON_CAP = 1.50
    XN_E_CD = 12.0               # 共鳴技能·應世相冷卻
    XN2_E_AFTER_R2 = True        # 萬闕垂天演完按一下 E
    # 【萬闕垂天後: 按過白屏時停出重擊 -> E】(下一圈心1 少補應世心)
    # HUD 回來後還有 ~0.6s 白屏時停: 演出藏 HUD 後 XN2_R2_HOLD_FROM 起按住, 解凍後 XN2_R2_HEAVY_HOLD 鬆, XN2_R2_E_AT 按 E
    LQ_XN2_R2_HEAVY = True
    LQ_XN2_R2_HEAVY_OPENER = True
    XN2_R2_HOLD_FROM = 3.60
    XN2_R2_FREEZE = 0.60
    XN2_R2_HEAVY_HOLD = 0.45
    XN2_R2_E_AT = 0.85
    XN2_E_CAP = 1.20
    # 【萬闕垂天把這一波打死了 -> 等新怪再重擊 + E】實機誤判多, 預設關
    XN2_R2_WAVE_WAIT = False
    XN2_R2_TARGET_BY = 0.40
    XN2_R2_FRESH_HOLD = 0.45
    XN2_R2_FRESH_E_AT = 0.40
    XN2_WAVE_WAIT = 9.0
    TARGET_GONE_CONFIRM = 2      # 連著這麼多幀沒讀到怪才算沒怪
    ENEMY_CONFIRM = 2            # 新怪連著這麼多幀讀到才算出來
    WAVE_LOCK_INTERVAL = 0.3     # 中鍵鎖敵間隔
    # 【收尾給下一圈心1 墊應世心】實機 1s 只漲 0.06~0.10, 預設關
    XN2_TAIL_A = False
    XN2_TAIL_YING = 0.30
    XN2_TAIL_CAP = 2.00


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.si_holding = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.hud_seen_at = 0.0         # 最後一次讀到隊伍 HUD 在場的時刻(HUD_LOST_ABORT 用)
        self.hud_watch = False         # 宏跑著的時候才查 HUD 丟沒丟、場上有沒有怪
        self.drive_log_at = 0.0
        self.timeline_logged = True
        self.sk_intro_done_at = 0.0
        self.so_tongzou_at = -99.0     # 鎖暝 R 出手的時刻
        self.enemy_seen_at = 0.0       # 最後一次讀到怪(Boss 圖示/鎖定框/血條)的時刻
        self.enemy_check_at = 0.0
        self.unlocked_since = None     # 有血條但沒鎖定, 從什麼時候開始
        self.relock_n = 0
        self.relock_at = 0.0
        # reset_state() 只在 load_chars() 時跑, 而角色物件會被黏性複用 —— 這裡也要啟一次
        try:
            start_enable_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        # 內建非治療角色預設 True, 換類時會被打回, 所以在這裡重申(這條軸不在切人時按處決)
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 隊伍判定 ====================

    @property
    def is_in_xss(self) -> bool:
        """本隊 = 心 + 鎖暝 + 維里奈。按類名判。"""
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Verina', 'Suoming'}:
                members += 1
        return members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """啟動軸不跑的原因; 返回 None 表示該跑。不查任何技能可用性(場下讀數是舊的)。"""
        if not self.is_in_xss:
            return 'team is not hsin/suoming/verina'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener and (self.opener_armed or self.F_REARM_OPENER):
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            self.opener_armed = True
            return None
        if not self.opener_armed:
            restarted = getattr(self.task, '_ww_task_restarted_at', -1)
            if restarted > self.last_opener:
                self.logger.info('自動戰鬥重開過 — 啟動軸重新武裝, 從頭跑')
                self.opener_armed = True
                return None
            return 'already armed-down (ran once this combat)'
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原語(引擎) ====================

    def macro_wait(self, sec):
        """精確等待, 【不點擊】。切成 0.1 秒一片, 片間檢查任務是否被停用、場上還有沒有怪(check_enemy_gone)。"""
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            self.check_enemy_gone()
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)
            self.check_enemy_gone()

    def check_enemy_gone(self):
        """宏跑著的時候(hud_watch)每 NO_ENEMY_CHECK_EVERY 讀一次當前幀:
          Boss 圖示 / 鎖定框在          -> 正常
          沒鎖定但畫面上有血條          -> 中鍵重鎖(不在按住普攻時按), RELOCK_GIVE_UP 鎖不到就收手
          什麼都讀不到(含沒血條的怪)    -> 一樣按中鍵試著鎖, NO_ENEMY_ABORT 還鎖不到就收手
        HUD 不在(演出/變奏入場/時停)讀不到, 全部從頭計時。收手 = 丟 MacroBroken, macro_exit 負責鬆鍵。"""
        if not self.hud_watch or self.NO_ENEMY_ABORT <= 0:
            return
        now = time.time()
        if now - self.enemy_check_at < self.NO_ENEMY_CHECK_EVERY:
            return
        self.enemy_check_at = now
        t = self.task
        try:
            hud = bool(t.in_team()[0])
        except Exception:
            hud = False
        if not hud:
            self.enemy_seen_at = now
            self.unlocked_since = None
            return
        try:
            boss = bool(t.is_boss())
        except Exception:
            boss = False
        if boss or self.target_visible():
            if self.unlocked_since is not None or self.relock_n:
                self.macro_mark(f'重新鎖定(x{self.relock_n},{now - (self.unlocked_since or self.enemy_seen_at):.2f}s)')
            self.enemy_seen_at = now
            self.unlocked_since = None
            self.relock_n = 0
            return
        try:
            bar = bool(t.has_health_bar())
        except Exception:
            bar = False
        if bar:
            self.enemy_seen_at = now
            if self.unlocked_since is None:
                self.unlocked_since = now
                self.relock_n = 0
            if now - self.unlocked_since >= self.RELOCK_GIVE_UP:
                self.hud_watch = False
                raise MacroBroken(f'有血條但 {now - self.unlocked_since:.1f}s 鎖不到怪'
                                  f'(中鍵 x{self.relock_n}, 怪太遠/血條誤讀?), 收手')
            if (not self.holding_attack and not self.si_holding
                    and now - self.relock_at >= self.RELOCK_EVERY):
                self.relock_at = now
                self.relock_n += 1
                t.middle_click()
            return
        self.unlocked_since = None
        # 什麼都讀不到(沒鎖定 + 沒血條的怪也會落在這裡): 也按中鍵試著鎖定, 鎖到了下一次就讀得到鎖定框、計時歸零
        if (not self.holding_attack and not self.si_holding
                and now - self.relock_at >= self.RELOCK_EVERY):
            self.relock_at = now
            self.relock_n += 1
            t.middle_click()
        if now - self.enemy_seen_at >= self.NO_ENEMY_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'場上 {now - self.enemy_seen_at:.1f}s 讀不到怪(中鍵 x{self.relock_n}, 這一波打完了), 收手')

    def wait_until_time(self, deadline):
        self.macro_wait(deadline - time.time())

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')
        # 【看門狗】HUD 很久沒出現 = 關卡結束/過場/視窗沒了, 再按下去就是在結算畫面上亂按
        if self.hud_watch and time.time() - self.hud_seen_at > self.HUD_LOST_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'隊伍 HUD {time.time() - self.hud_seen_at:.1f}s 沒出現(關卡結束/過場/視窗沒了?)')

    def hud_ok(self):
        """隊伍 HUD 在不在(讀當前幀)。見到就記下時刻, 給看門狗用。"""
        ok = bool(self.task.in_team()[0])
        if ok:
            self.hud_seen_at = time.time()
        return ok

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A'):
        """連點一個窗口(動畫期間的點擊被丟掉, 連點保證總有一下落在動畫剛結束時)。"""
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        while time.time() - start < window and n < cap:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=False, presses=None):
        """在一個窗口裡反覆發同一個技能鍵(動畫期間的按鍵被丟掉、不排隊, 單發必丟)。"""
        interval = self.KEY_INTERVAL if interval is None else interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - time.time()))
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def game_foreground(self):
        try:
            return bool(self.task.executor.interaction.hwnd_window.is_foreground())
        except Exception:
            return False

    def attack_down(self, direct):
        """按下左鍵。direct = 走 SendInput(失敗自動退回 PostMessage)。返回實際走沒走 SendInput。"""
        if direct and send_input_left(False):
            self.si_holding = True
        else:
            direct = False
            self.task.mouse_down()
        self.holding_attack = True
        return direct

    def release_attack(self):
        # 【SendInput 按下的必須 SendInput 鬆開】: PostMessage 的 mouse_up 只進遊戲視窗的訊息佇列,
        # 系統裡那個左鍵會一直按著 —— 宏異常退出時整台電腦的左鍵都是按住的
        if self.si_holding:
            if not send_input_left(True):
                self.logger.warning('SendInput 左鍵鬆開沒發出去 — 如果左鍵卡住, 手動點一下')
            self.si_holding = False
            self.holding_attack = False
        elif self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def tap(self, hold=None):
        """點一下普攻, 【真的按住 hold 秒】。"""
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本隊裡所有的 self.click() 都改成按住 A_TAP(BaseChar.click 強制 10ms, 等於沒點)。不在本隊走原版。"""
        if not self.is_in_xss:
            return super().click(*args, **kwargs)
        self.tap()

    def quick_switch(self, target, click_during=False, time_out=None, read_con=False, assume_con=False):
        """按數字鍵直切給指定角色(不走 switch_next_char 選人)。

        read_con: 按鍵之後讀一次協奏決定按不按「帶變奏」記帳; assume_con: 不讀屏直接按滿協奏記。
        Returns: 是否真的切過去了。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        self.switch_press_at = time.time()
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            try:
                con_full = float(self.task.get_current_con()) >= 1.0
            except Exception:
                con_full = False
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace and time.time() - entry > 0.4:
                    self.logger.info(f'slow switch trace -> {target.name}: {" ".join(trace)}')
                return True
        # 一直是舊角色的 index = 遊戲在拒絕切人; 帶 ? 的都是目標 = count 判據擋住了; 全是 x = HUD 不在
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """複刻 switch_next_char() 尾部那套交接記帳。不補的話 get_current_char() 返回 None, 主迴圈當場崩。"""
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_retry(self, target, tag, **kw):
        """quick_switch, 逾時了先等 HUD 回來再切, 最多再試 SWITCH_RETRIES 次。只花時間。"""
        if self.quick_switch(target, **kw):
            return True
        for i in range(self.SWITCH_RETRIES):
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
            self.macro_mark(f'{tag}切{target.name[:3]}重試#{i + 1}')
            kw2 = dict(kw)
            kw2['time_out'] = self.SWITCH_RETRY_TIME_OUT
            if self.quick_switch(target, **kw2):
                return True
        return False

    def wait_hud_back(self, tag='anim', time_out=None, min_gone=0.0, tail=0.0, hold_from=None):
        """等演出結束(隊伍 HUD 回來), 【期間一下都不點】。先確認消失過。

        min_gone: 從第一次讀到消失起, 這麼久之內讀到的「回來」不認(演出中途 HUD 會閃一兩幀)。
        hold_from: 消失後這麼久按住普攻(預輸入重擊), 返回時還按著, 呼叫端負責鬆開。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_at = None
        back_hits = 0
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if (hold_from is not None and gone_at is not None and not self.holding_attack
                    and time.time() - gone_at >= hold_from):
                si = self.xn_attack_down()
                self.macro_mark(f'{tag}按住預輸入({"SI" if si else "PM"},{time.time() - gone_at:.2f}s)')
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        back = True
                        break
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_at is not None else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等隊伍 HUD 【現在】在場。按 R 之前用 —— HUD 本來就不在的時候判「演出開始了」是假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在場({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def on_field_char(self, time_out=None):
        """現在場上是誰 —— 只在拿不到入口角色時才用(開局 HUD 漸入時 in_team() 會說謊, 要 count 達標)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def mark_busy(self, busy):
        """F 鍵監視執行緒靠它區分「戰鬥中手動處決」和「重開副本」。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某個技能鍵到它進 CD。返回放出去了沒有(本來就在 CD 上返回 False)。

        【先見過「亮」才認「暗」】: 剛切人那幾幀技能欄還是上一個人的, 讀到的是上一個人的 CD。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.hud_ok())
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    self.macro_mark(f'{tag}_沒見過亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    def fire_r(self, char, tag, window):
        """發大招到隊伍 HUD【連續】消失 LIB_GONE_CONFIRM 幀。返回放出去沒有。

        發鍵之前先等 HUD 在場(HUD 本來就不在會假成功)。確認期間繼續按 R 沒有副作用 —— 演出裡的按鍵被丟掉。
        """
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        # lit=True: 鍵被上一個動作吞了; lit=False: 能量不夠
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def lib_ready_reads(self, char, frames):
        """HUD 在場時連續 frames 幀讀到 char 的 R 可用。HUD 不在的幀不算, 最多讀 frames*3 幀。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def read_cd(self, name='resonance', char=None):
        """讀技能框裡的 CD 數字(秒)。不在 CD / 讀不到都返回 0。"""
        try:
            index = None if char is None else char.index
            return max(0.0, float(self.task.get_cd(name, index)))
        except Exception:
            return 0.0

    def read_con(self, want, settle=None, click=False, tag=None):
        """讀協奏: 自己刷幀、給結算留時間, 連著幾幀達到 want 就立刻返回。返回期間讀到的最大值。"""
        settle = 0.50 if settle is None else settle
        start = time.time()
        best = 0.0
        hits = 0
        next_click = 0.0
        while True:
            now = time.time()
            if click and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.SK_CON_FULL_CONFIRM or time.time() - start >= settle:
                break
            self.macro_wait(self.SK_CON_POLL)
        if tag:
            self.macro_mark(f'{tag}(con{best:.2f},{time.time() - start:.2f}s)')
        return best

    def glow_slot(self, frame, slot):
        """隊伍欄第 slot 格(0 起)頭像外面那圈細白環 -> 落在同一半徑上的上半圈角度佔比(0~1)。"""
        H, W = frame.shape[:2]
        s = H / 2160
        cx = W - (3840 - 3586.5) * s
        cy = (500 + 264 * slot) * s
        R = int(round(125 * s)) + 3
        xa, ya = int(cx) - R, int(cy) - R
        if xa < 0 or ya < 0 or xa + 2 * R + 1 > W or ya + 2 * R + 1 > H:
            return 0.0
        crop = frame[ya:ya + 2 * R + 1, xa:xa + 2 * R + 1, :3]
        white = np.ascontiguousarray(crop.min(axis=2)).astype(np.float32)
        polar = cv2.warpPolar(white, (R, 360), (cx - xa, cy - ya), R, cv2.WARP_POLAR_LINEAR)
        rows = polar[225:331]
        d = max(1, int(round(4.5 * s)))
        r = np.arange(int(80 * s), int(118 * s))
        ridge = rows[:, r] - np.maximum(rows[:, r - d], rows[:, r + d])
        k = ridge.argmax(axis=1)
        hit = ridge[np.arange(len(rows)), k] > 40
        if not hit.any():
            return 0.0
        hist = np.bincount(r[k][hit], minlength=int(r[-1]) + 2)
        win = max(2, int(round(4 * s)))
        return float(np.convolve(hist, np.ones(win), 'valid').max()) / len(rows)

    def glow_now(self, cur):
        """當前幀 cur 以外兩格的光圈夠不夠「協奏滿」。同一幀只算一次, 順手數連著幾幀(換人從頭數)。"""
        frame = self.task.frame
        if frame is None:
            return False
        same_cur = getattr(self, 'glow_cur', None) == cur.index
        if same_cur and getattr(self, 'glow_frame', None) is frame:
            return self.glow_last
        others = [self.glow_slot(frame, i) for i in range(3) if i != cur.index]
        lo, hi = min(others), max(others)
        on = (lo >= self.GLOW_BOTH and hi >= self.GLOW_ONE) or hi >= self.GLOW_SOLO
        self.glow_hits = ((getattr(self, 'glow_hits', 0) if same_cur else 0) + 1) if on else 0
        self.glow_frame, self.glow_cur, self.glow_last = frame, cur.index, on
        return on

    def con_glow(self, cur):
        """光圈連著 GLOW_CONFIRM 幀都在 = 協奏真滿。讀當前幀(呼叫端負責 next_frame)。
        認出過一次就記下「這台機器光圈認得出」(glow_trusted), 之後 strict 的地方不再信讀數。"""
        self.glow_now(cur)
        ok = getattr(self, 'glow_hits', 0) >= self.GLOW_CONFIRM
        if ok:
            self.glow_ok = True
        return ok

    def glow_trusted(self):
        return getattr(self, 'glow_ok', False)

    def con_ready(self, cur, settle, tag=None, strict=False):
        """讀協奏: 光圈連 GLOW_CONFIRM 幀 = 滿; 認不出光圈時讀數連 SK_CON_FULL_CONFIRM 幀 1.00 也算滿
        (strict 且光圈認得出過: 讀數不算, 只認光圈)。settle 內都沒有 = 不滿。讀數最大值留在 self.con_last(給日誌)。"""
        strict = strict and self.glow_trusted()
        start = time.time()
        best = 0.0
        hits = 0
        why = None
        while True:
            self.task.next_frame()
            self.hud_ok()
            if self.con_glow(cur):
                why = '光圈'
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= self.SK_CON_ENOUGH else 0
            if hits >= self.SK_CON_FULL_CONFIRM and not strict:
                why = f'con{best:.2f}'
                break
            if time.time() - start >= settle:
                break
            self.macro_wait(self.SK_CON_POLL)
        self.con_last = best
        self.con_why = why
        if tag:
            self.macro_mark(f'{tag}({why or f"沒滿con{best:.2f}"},{time.time() - start:.2f}s)')
        return why is not None

    # ==================== 切給維里奈 / 處決 ====================

    def switch_to_sk(self, sk, tag):
        """切給維里奈(名字沿用心鎖守)並等她的變奏入場演完。返回時 HUD 在場、場上是她。"""
        for attempt in range(1 + self.SWITCH_RETRIES):
            got = self.switch_to_sk_once(sk, tag if attempt == 0 else f'{tag}重切#{attempt}')
            if got is not None:
                return got
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
        return False

    def switch_to_sk_once(self, sk, tag):
        """切一次。返回 True/False(到場了, HUD 回沒回來), None = 沒上場。

        帶演出的變奏入場一切進來 HUD 就藏了, quick_switch 讀不到到場會逾時 ——
        所以不管切人判沒判到, 都等 HUD 回來再認一次場上是誰。演出裡一下都不點。
        """
        src = self.cur
        sw_at = time.time()
        full = False
        try:
            full = float(self.task.get_current_con()) >= 1.0
        except Exception:
            pass
        arrived = self.quick_switch(sk, assume_con=full, time_out=self.SK_TO_TIME_OUT)
        anim_in_switch = arrived and time.time() - sw_at >= self.SK_SWITCH_ANIM_HINT
        start = time.time()
        gone_at = None
        hits = 0
        back = False
        while time.time() - start < self.SK_INTRO_ANIM_CAP:
            self.task.next_frame()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                hits = 0
            elif gone_at is not None or anim_in_switch:
                hits += 1
                if hits >= self.HUD_BACK_CONFIRM:
                    back = True
                    break
            elif time.time() - start >= self.SK_INTRO_NOANIM:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}入場({"anim" if gone_at is not None or anim_in_switch else "noanim"},'
                        f'{"ok" if back else "timeout"},{time.time() - start:.2f}s)')
        if not arrived:
            who = self.on_field_char(time_out=1.0)
            if who is not sk:
                self.macro_mark(f'{tag}沒上場({who.name if who else "?"})')
                return None
            self.handoff(src if src is not None else self, sk, full)
            self.macro_mark(f'{tag}>{sk.name[:3]}(演出裡到場)')
        self.sk_intro_done_at = time.time()
        return back

    def sk_forte_full_once(self, char):
        """迴路滿(滑鼠指示亮)。讀當前幀。"""
        try:
            return bool(char.is_mouse_forte_full())
        except Exception:
            return False

    def break_prompt(self):
        """怪身上有處決提示(螢幕中間那個 F, 排除拾取 F)。讀當前幀。"""
        task = self.task
        try:
            hit = task.find_one('f_break', box=task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True),
                                target_height=720, threshold=self.BREAK_CENTER_MIN)
            return bool(hit) and not task.is_pick_f()
        except Exception as e:
            self.logger.info(f'處決提示讀失敗 {e}')
            return False

    def break_ring(self):
        """boss 頭像外圈滿了(共振度滿, 能處決)。讀當前幀。沒有 boss 血條的怪永遠 False。"""
        try:
            return bool(self.task.find_one('f_break_full', threshold=self.BREAK_RING_MIN))
        except Exception:
            return False

    def note_break_prompt(self):
        """切給維里奈之前讀一幀處決提示: 小怪沒有外圈, 靠這一下決定維入場後要不要等提示回來。"""
        self.task.next_frame()
        if self.hud_ok() and self.break_prompt():
            self.break_seen_at = time.time()

    def break_press(self, tag):
        """提示在就按 F, 按完 BREAK_RESEND 提示還在再按; 提示連 BREAK_GONE_FRAMES 幀不見 = 起手了。
        返回(起手前最後一下 F 的時刻 或 None, 按了幾下)。"""
        presses = 0
        last_f = 0.0
        gone = 0
        while True:
            if gone == 0 and time.time() - last_f >= self.BREAK_RESEND:
                if presses >= self.BREAK_PRESSES:
                    return None, presses
                self.task.send_key('f', down_time=0.05)
                presses += 1
                last_f = time.time()
            self.macro_wait(0.03)
            self.task.next_frame()
            if self.hud_ok() and self.break_prompt():
                gone = 0
            else:
                gone += 1
                if gone >= self.BREAK_GONE_FRAMES:
                    return last_f, presses

    def sk_break(self, tag, t_in, seen_before, press_not_before=0.0):
        """處決。外圈滿著 / 切人前讀到過提示 -> 盯提示到 t_in + SK_BREAK_UNTIL; 都沒有 -> 只讀 BREAK_READS 幀。
        按到提示消失, 從生效那一下起等 BREAK_ANIM; 等完提示還在就再來一輪。返回處決了沒有。"""
        ring = self.break_ring()
        armed = ring or seen_before
        deadline = t_in + self.SK_BREAK_UNTIL if armed else 0.0
        start = time.time()
        reads = 0
        while True:
            self.task.next_frame()
            if self.hud_ok() and self.break_prompt():
                break
            reads += 1
            if reads >= self.BREAK_READS and time.time() >= deadline:
                if armed:
                    self.macro_mark(f'{tag}處決提示沒出來(圈{int(ring)},{time.time() - start:.2f}s)')
                return False
            self.macro_wait(0.02)
        waited = time.time() - start
        self.wait_until_time(press_not_before)
        total = 0
        for rnd in range(self.BREAK_ROUNDS):
            hit_at, n = self.break_press(tag)
            total += n
            try:
                self.task.can_break = False
            except Exception:
                pass
            if hit_at is None:
                self.macro_mark(f'{tag}處決?(F x{total},提示一直在)')
                self.logger.warning(f'{tag}: 處決 F 按了 {total} 下提示一直沒消失(一直被吞?), 不等了')
                return False
            self.wait_until_time(hit_at + self.BREAK_ANIM)
            self.wait_hud_up(cap=1.0, tag=f'{tag}處決後HUD')
            again = False
            for _ in range(2):
                self.task.next_frame()
                if self.hud_ok() and self.break_prompt():
                    again = True
                    break
            if not again:
                self.macro_mark(f'{tag}處決(F x{total},等提示{waited:.2f}s,圈{int(ring)}->{int(self.break_ring())})')
                return True
            self.macro_mark(f'{tag}處決沒上(提示還在, 第{rnd + 2}輪)')
        self.logger.warning(f'{tag}: 處決按了 {self.BREAK_ROUNDS} 輪提示還在, 不等了')
        return False

    # ==================== 維里奈 ====================

    def vr_e(self, vr, tag):
        """E 按到進 CD。不可用/沒放出去返回 False。"""
        if self.press_res_until_cd(vr, self.VR_SKILL_CAP, f'{tag}E', ready_grace=0.15):
            vr.record_resonance_use()
            return True
        return False

    def vr_q(self, vr, tag):
        """聲骸按到進 CD(上限 VR_Q_CAP)。"""
        if self.press_key_until_cd(vr.send_echo_key, vr.echo_available, self.VR_Q_CAP,
                                   f'{tag}Q', ready_grace=0.15):
            vr.record_echo_use()
            return True
        return False

    def vr_r(self, vr, tag):
        """R: 連 2 幀亮才按; 按到 HUD 消失(有演出, 等它演完)或圖示變暗(沒演出)就算放出去。"""
        self.task.next_frame()
        if not (self.hud_ok() and self.so_on_field(vr) and self.lib_ready_reads(vr, 2)):
            self.macro_mark(f'{tag}R(不可用)')
            return False
        self.wait_hud_up(tag=f'{tag}R前HUD')
        start = time.time()
        n = 0
        while time.time() - start < self.VR_SKILL_CAP:
            vr.send_liberation_key()
            n += 1
            self.macro_wait(0.06)
            self.task.next_frame()
            if not self.hud_ok():
                vr.record_liberation_use()
                self.macro_mark(f'{tag}R_fired(x{n},演出)')
                self.wait_hud_back(tag=f'{tag}R演出', time_out=self.VR_R_ANIM_CAP)
                return True
            try:
                lit = bool(vr.liberation_available())
            except Exception:
                lit = True
            if self.so_on_field(vr) and not lit:
                vr.record_liberation_use()
                self.macro_mark(f'{tag}R_ok(x{n})')
                return True
        self.macro_mark(f'{tag}R_NOFIRE(x{n})')
        return False

    def vr_heavy(self, vr, tag):
        """迴路滿的重擊(按住 VR_HEAVY_HOLD)。"""
        self.attack_down(False)
        try:
            self.macro_wait(self.VR_HEAVY_HOLD)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}重擊')

    def vr_fill_con(self, vr, tag, cap):
        """維里奈打到協奏真滿。每輪: E/R 能放先放(各一次) -> 迴路滿就重擊 -> 普攻 VR_PRE_JUMP_A 下
        -> 跳躍 + 空中 VR_AIR_COUNT 下 -> 落地。每一下普攻之後都看一次協奏, 滿了立刻返回。返回滿沒滿。

        滿 = 光圈連 GLOW_CONFIRM 幀。VR_GLOW_ONLY 且本局光圈認得出過: 讀數不算;
        還沒認出過: 讀數 1.00 連 VR_CON_CONFIRM 次後再打 VR_CON_READ_GRACE 光圈還沒出來才信讀數。"""
        start = time.time()
        hits = [0]
        read_full_at = [None]
        why = ['cap']
        taps = jumps = heavies = 0
        e_tried = r_tried = False
        last_heavy = -99.0

        def full():
            self.task.next_frame()
            if not self.hud_ok():
                return False
            if self.con_glow(vr):
                why[0] = '光圈'
                return True
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            hits[0] = hits[0] + 1 if con >= self.SK_CON_ENOUGH else 0
            if hits[0] < self.VR_CON_CONFIRM:
                return False
            if not self.VR_GLOW_ONLY:
                why[0] = f'讀數{con:.2f}'
                return True
            if self.glow_trusted():
                return False
            read_full_at[0] = read_full_at[0] or time.time()
            if time.time() - read_full_at[0] >= self.VR_CON_READ_GRACE:
                why[0] = '讀數滿沒光圈'
                return True
            return False

        def done():
            self.macro_mark(f'{tag}協奏({why[0]},A x{taps},跳x{jumps},重擊x{heavies},{time.time() - start:.2f}s)')

        while time.time() - start < cap:
            if full():
                done()
                return True
            if self.so_on_field(vr):
                if not e_tried and vr.resonance_available():
                    e_tried = True
                    self.vr_e(vr, tag)
                    continue
                if not r_tried and vr.liberation_available():
                    r_tried = True
                    self.vr_r(vr, tag)
                    continue
                if time.time() - last_heavy >= self.VR_HEAVY_GAP and self.sk_forte_full_once(vr):
                    heavies += 1
                    last_heavy = time.time()
                    self.vr_heavy(vr, tag)
                    continue
            for _ in range(self.VR_PRE_JUMP_A):
                self.tap()
                taps += 1
                self.macro_wait(max(0.0, self.VR_A_EVERY - self.A_TAP))
                if full():
                    done()
                    return True
            self.task.send_key(self.VR_JUMP_KEY)
            jumps += 1
            self.macro_wait(self.VR_JUMP_RISE)
            for _ in range(self.VR_AIR_COUNT):
                self.tap()
                taps += 1
                self.macro_wait(max(0.0, self.VR_AIR_EVERY - self.A_TAP))
                if full():
                    done()
                    return True
            self.macro_wait(self.VR_LAND)
        done()
        self.logger.warning(f'{tag}: 維里奈打了 {cap:.1f}s 協奏還是沒滿(打不到怪?), 鎖暝拿不到變奏')
        return False

    def seg_vr(self, vr, so, tag, opener=False):
        """維里奈(啟動軸 / 循環軸變奏入場, HUD 回來之後): Q -> E -> R -> [有處決提示就處決] -> 打到協奏真滿
        -> 變奏鎖暝(閃裂進念深, 念深才有 R)。協奏不滿就切 = 鎖暝普通入場, 鎖a 走「妄執滿點 E 進念深」補救。"""
        t_in = time.time()
        if not opener and not vr.has_intro:
            self.macro_mark(f'{tag}無變奏')
        seen = getattr(self, 'break_seen_at', None)
        seen_before = seen is not None and t_in - seen < self.BREAK_SEEN_FRESH
        self.break_seen_at = None
        self.wait_until_time(self.switch_press_at + self.VR_ENTRY_LEAD)
        self.vr_q(vr, tag)
        self.vr_e(vr, tag)
        self.vr_r(vr, tag)
        if self.SK_BREAK and not opener:
            self.sk_break(tag, t_in, seen_before)
        full = self.vr_fill_con(vr, tag, self.VR_OPEN_CON_CAP if opener else self.VR_LOOP_CON_CAP)
        if not full:
            self.logger.warning(f'【協奏沒滿就交棒】維 -> 鎖暝: 鎖暝普通入場, R 要靠妄執滿點 E 進念深')
        self.need(self.switch_retry(so, f'{tag}切鎖暝', assume_con=full), 'verina -> suoming')
        return full

    # ==================== 心 ====================

    def xn_gauge(self):
        """應世心條 -> (左半, 右半) 有紫色的列佔比。讀當前幀, 呼叫端負責 next_frame。"""
        frame = self.task.frame
        out = []
        for x1, y1, x2, y2 in (self.XN_GAUGE_L, self.XN_GAUGE_R):
            box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
            if crop.size == 0:
                return 0.0, 0.0
            hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            purple = (h >= 125) & (h <= 160) & (sat >= 70) & (v >= 90)
            out.append(float(purple.any(axis=0).mean()))
        return out[0], out[1]

    def xn_ying(self):
        """應世心 -> (滿沒滿, 左半紫, 右半紫)。滿 = 重擊位的花圖示 hsin_h1; 沒滿時條是紫色格子。讀當前幀。"""
        try:
            full = bool(self.task.find_one('hsin_h1', threshold=self.XN_FULL_THRESHOLD))
        except Exception:
            full = False
        L, R = self.xn_gauge()
        return full, L, R

    def xn_icon(self, name):
        """心技能欄的圖示模板(hsin_lib1 = 轉相 / hsin_lib2 = 萬闕垂天解鎖)。讀當前幀。"""
        try:
            return bool(self.task.find_one(name, threshold=0.7))
        except Exception:
            return False

    def xn_attack_down(self):
        return self.attack_down(self.XN_HOLD_SENDINPUT and self.game_foreground())

    def xn_fill_until_ready(self, tag, not_before=0.0):
        """(XN1_SKIP_A_WHEN_FULL 關掉時用) 連續點普攻, 每幀讀應世心條, 打滿 XN1_MIN_A 下、到線、過了 not_before 就返回。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hits = 0
        valid_seen = False
        last_r = 0.0
        trace = []
        while True:
            now = time.time()
            if now >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            el = time.time() - start
            if self.hud_ok():
                full, L, R = self.xn_ying()
                if len(trace) < 30:
                    trace.append(f'{el:.2f}:{"滿" if full else ""}{L:.2f}/{R:.2f}')
                if full or L >= self.XN_GAUGE_VALID:
                    valid_seen = True
                    last_r = 1.0 if full else R
                    hits = hits + 1 if (full or R >= self.XN_YING_READY) else 0
                    if taps >= self.XN1_MIN_A and hits >= self.XN1_GAUGE_CONFIRM and time.time() >= not_before:
                        self.macro_mark(f'{tag}應世心到線({R:.2f},A x{taps},{el:.2f}s)')
                        return 'ready'
                    if el >= self.XN1_LATE_AT and R >= self.XN_YING_LATE:
                        self.macro_mark(f'{tag}應世心將滿({R:.2f},A x{taps},{el:.2f}s)')
                        return 'late'
            if el >= self.XN1_BLIND_AT and not valid_seen:
                self.macro_mark(f'{tag}應世心讀不到(A x{taps}, 照按)')
                self.logger.info(f'{tag}: 應世心條讀不出來 — {" ".join(trace)}')
                return 'blind'
            if el >= self.XN1_FILL_CAP:
                self.macro_mark(f'{tag}應世心不夠(cap,{last_r:.2f},A x{taps})')
                self.logger.info(f'{tag}: 應世心補到上限還沒到線 — {" ".join(trace)}')
                return 'cap'
            self.macro_wait(0.02)

    def xn1_entry_fill(self, xn, tag, sw):
        """心1 進場: 花圖示(應世心滿)連 2 幀就按住; 沒亮就從 XN1_ENTRY_TAP_FROM 起點普攻補, 亮了再按住。"""
        self.wait_until_time(sw + self.XN1_FULL_FROM)
        tap_from = sw + self.XN1_ENTRY_TAP_FROM
        next_tap = tap_from
        taps = hits = 0
        valid_seen = False
        L = R = 0.0
        why = 'cap'
        while time.time() < tap_from + self.XN1_FILL_CAP:
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            ok = False
            if self.hud_ok() and self.so_on_field(xn):
                full, L, R = self.xn_ying()
                valid_seen = valid_seen or full or L >= self.XN_GAUGE_VALID
                ok = full
            hits = hits + 1 if ok else 0
            if hits >= 2:
                why = 'full'
                break
            if not valid_seen and time.time() >= tap_from + self.XN1_BLIND_AT:
                why = 'blind'
                break
            self.macro_wait(0.02)
        el = time.time() - sw
        if why == 'full' and taps == 0:
            self.macro_mark(f'{tag}上場應世心就滿({el:.2f}s)')
            self.wait_until_time(sw + self.XN1_FULL_HOLD_AT)
        elif why == 'full':
            self.macro_mark(f'{tag}普攻補滿應世心(A x{taps},{el:.2f}s)')
        else:
            self.macro_mark(f'{tag}應世心{"讀不到" if why == "blind" else "不夠"}(照按,{L:.2f}/{R:.2f},A x{taps},{el:.2f}s)')

    def xn_hold_burn(self, tag):
        """按住重擊 XN1_HOLD 秒, 期間看應世心條有沒有被清空(= 步紅塵出手)。

        返回 (狀態, 清空時刻, 按下時刻)。狀態:
          'burned'  清空了
          'full'    鬆手後條還在 = 出的是普通重擊 -> 呼叫端補 A 再按
          'unknown' 條一次都沒讀出來 -> 不重按(重按落在步紅塵演出裡會再起一個重擊)
        """
        si = self.xn_attack_down()
        start = time.time()
        press_at = start
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        seen_full = False
        burned_at = None
        low_at = None
        icon_since = None
        stale = 0
        lit_at_press = None
        lit_hits = 0
        trace = []
        try:
            while time.time() - press_at < self.XN1_HOLD:
                self.task.next_frame()
                if self.hud_ok() and burned_at is None:
                    now = time.time()
                    full, L, R = self.xn_ying()
                    if len(trace) < 30:
                        trace.append(f'{now - start:.2f}:{"滿" if full else ""}{L:.2f}/{R:.2f}')
                    if lit_at_press is None:
                        lit_at_press = full
                    lit_hits = lit_hits + 1 if full else 0
                    if not lit_at_press and lit_hits >= 2 and stale < self.XN1_STALE_MAX:
                        stale += 1
                        self.release_attack()
                        self.macro_wait(0.05)
                        self.xn_attack_down()
                        press_at = time.time()
                        lit_at_press = True
                        icon_since = None
                        self.macro_mark(f'{tag}按下後才滿,重按({now - start:.2f}s)')
                        continue
                    icon_since = (icon_since or now) if full else None
                    if (full and stale < self.XN1_STALE_MAX and now - press_at >= self.XN1_STALE_MIN
                            and now - icon_since >= self.XN1_STALE_FULL):
                        stale += 1
                        self.release_attack()
                        self.macro_wait(0.05)
                        self.xn_attack_down()
                        press_at = time.time()
                        icon_since = None
                        self.macro_mark(f'{tag}滿了沒出,重按({now - start:.2f}s)')
                        continue
                    if full or L >= self.XN_GAUGE_VALID:
                        seen_full = True
                        low_at = None
                    elif seen_full and L < self.XN_CONSUMED:
                        # 連著兩幀空才算(特效閃一下會壓暗一幀); 時刻記第一幀 —— 轉相解鎖從這一刻算
                        if low_at is None:
                            low_at = now
                        else:
                            burned_at = low_at
                            self.macro_mark(f'{tag}步紅塵出手({burned_at - start:.2f}s)')
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        if burned_at is not None:
            self.macro_mark(f'{tag}鬆開')
            return 'burned', burned_at, start
        # 按住期間沒讀到清空: 鬆手後再讀兩幀, 條還在 = 真沒出步紅塵
        full = empty = 0
        for _ in range(6):
            self.task.next_frame()
            if self.hud_ok():
                is_full, L, R = self.xn_ying()
                if is_full or L >= self.XN_GAUGE_VALID:
                    full += 1
                    seen_full = True
                elif seen_full and L < self.XN_CONSUMED:
                    empty += 1
                if full >= 2 or empty >= 2:
                    break
            self.macro_wait(0.02)
        state = 'full' if full >= 2 else ('burned' if empty >= 2 else 'unknown')
        self.macro_mark(f'{tag}鬆開({state})')
        self.logger.info(f'{tag}: 按住 {self.XN1_HOLD:.1f}s 沒讀到應世心清空 -> {state} — {" ".join(trace)}')
        return state, None, start

    def xn_r1_ready(self):
        """轉相能不能按: R 圖示是轉相(hsin_lib1)而且亮著。讀當前幀。"""
        try:
            lit = bool(self.available('liberation', check_color=True, check_cd=False))
        except Exception:
            lit = False
        return lit and self.xn_icon('hsin_lib1')

    def seg_xn1(self, xn, so, tag):
        """心·第一段(變奏·應世相): 聲骸 -> 花圖示亮就按住(沒亮先點 A) -> 步紅塵 -> 連按 R 轉相 -> 演完照世相 E
        -> 同奏切鎖暝。"""
        sw = self.switch_press_at
        if self.LQ_XN1_ECHO:
            self.xn_echo(xn, tag, sw)
        if self.XN1_SKIP_A_WHEN_FULL:
            self.xn1_entry_fill(xn, tag, sw)
        else:
            self.wait_until_time(sw + self.XN1_A1_AT)
            self.xn_fill_until_ready(tag, not_before=sw + self.XN1_HOLD_NOT_BEFORE)

        state = 'unknown'
        burned_at = None
        for attempt in range(1 + self.XN1_RETRIES):
            if attempt > 0:
                # 上一次鬆手後條還在 = 出的是普通重擊: 花圖示亮著就直接重按, 沒亮補兩下 A 再按
                self.task.next_frame()
                lit = self.hud_ok() and self.xn_ying()[0]
                if not lit:
                    for _ in range(self.XN1_RETRY_A):
                        self.tap(self.XN1_A_HOLD)
                        self.macro_wait(self.XN1_FILL_EVERY)
                self.macro_mark(f'{tag}重擊重按#{attempt}{"(亮著)" if lit else ""}')
            state, burned_at, _hold_at = self.xn_hold_burn(f'{tag}重擊' if attempt == 0 else f'{tag}重擊#{attempt}')
            if state != 'full':
                break
        fired = False
        if state == 'full':
            self.logger.warning(f'{tag}: 重按 {self.XN1_RETRIES} 次應世心都沒清空(步紅塵沒出), 轉相多半放不出來')
        else:
            if self.XN1_ECHO:
                xn.send_echo_key(down_time=0.05)
                xn.record_echo_use()
                self.macro_wait(0.05)
            fired = self.fire_r(xn, f'{tag}轉相', self.XN1_R1_SPAM)
            if fired and burned_at is not None:
                self.macro_mark(f'{tag}轉相出手(清空後{time.time() - burned_at:.2f}s)')
        if not fired:
            fired = self.xn_r1_rescue(xn, tag)
        if not fired:
            self.logger.warning(f'{tag}: 補了 {self.XN1_R1_RESCUE_CAP:.0f}s 轉相還是沒放出去 — 鎖暝拿不到同奏, 照常往下走')
        else:
            self.wait_hud_back(tag=f'{tag}轉相演出', min_gone=self.XN_R_ANIM_MIN, time_out=self.XN_R_ANIM_CAP)
            if self.LQ_XN1_E:
                # 照世相 E 跟應世相 E 冷卻分開, 不記 last_res
                self.press_res_until_cd(xn, self.LQ_XN1_E_CAP, f'{tag}照世相E', ready_grace=0.15)
        # 同奏 5 秒: 轉相一演完立刻切, 鎖暝不用滿協奏也是變奏入場(旋雷破·同奏)
        self.need(self.switch_retry(so, f'{tag}切鎖暝', assume_con=fired), 'hsin -> suoming')
        return fired

    def xn_echo(self, xn, tag, sw):
        """心1 進場放聲骸: 切人鍵 + LQ_XN1_ECHO_AT 後(技能欄換成心的)讀聲骸 CD, 好著就按到 CD 漲上來。"""
        self.wait_until_time(sw + self.LQ_XN1_ECHO_AT)
        self.task.next_frame()
        if self.so_on_field(xn) and self.read_cd('echo', xn) > self.SO_ECHO_RISE:
            self.macro_mark(f'{tag}聲骸冷卻中')
            return False
        return self.so_echo(xn, f'{tag}Q', cap=self.LQ_XN1_ECHO_CAP)

    def xn_r1_rescue(self, xn, tag):
        """轉相第一次沒放出去: 補到放出去為止(上限 XN1_R1_RESCUE_CAP)。返回放出去沒有。

        轉相圖示亮著 -> 按 R; 應世心滿 -> 再按住出步紅塵、等解鎖; 都不是 -> 普攻攢應世心; HUD 不在 -> 等它回來。
        一直既看不到轉相圖示也讀不到應世心條 = 已經進照世相了(轉相其實出了), 不再按 R(照世相裡按 R 是借相)。
        """
        start = time.time()
        rounds = 0
        lost = 0
        self.macro_mark(f'{tag}轉相補救開始')
        while time.time() - start < self.XN1_R1_RESCUE_CAP:
            rounds += 1
            self.task.next_frame()
            if not self.hud_ok():
                self.wait_hud_up(cap=1.0, tag=f'{tag}轉相補救等HUD')
                continue
            lit = 0
            for _ in range(self.XN1_R1_READS):
                if self.xn_r1_ready():
                    lit += 1
                self.task.next_frame()
            if lit >= self.XN1_R1_READS:
                lost = 0
                if self.fire_r(xn, f'{tag}轉相補#{rounds}', self.XN_R_WINDOW):
                    self.macro_mark(f'{tag}轉相補救成功({time.time() - start:.2f}s)')
                    return True
                continue
            full, L, R = self.xn_ying()
            if full or L >= self.XN_GAUGE_VALID or self.xn_icon('hsin_lib1'):
                lost = 0
            else:
                lost += 1
                if lost >= self.XN1_R1_LOST_ROUNDS:
                    self.macro_mark(f'{tag}轉相補救: 已不在應世相(當轉相出過了)')
                    return True
            if full or (L >= self.XN_GAUGE_VALID and R >= self.XN_YING_READY):
                state, burned_at, _hold_at = self.xn_hold_burn(f'{tag}補步紅塵#{rounds}')
                if state == 'burned':
                    anchor = burned_at if burned_at is not None else time.time() - 0.3
                    due = anchor + self.XN1_R1_UNLOCK + self.XN1_R1_MARGIN
                    while time.time() < due:
                        self.task.next_frame()
                        if self.hud_ok() and self.xn_r1_ready():
                            break
                        self.macro_wait(0.01)
                continue
            self.macro_spam(self.XN1_R1_RESCUE_A, self.XN1_FILL_EVERY, tag=f'{tag}補應世心A#{rounds}')
        self.macro_mark(f'{tag}轉相補救(cap,{rounds}輪)')
        return False

    def xn_hold_until_gone(self, cap, tag, watch_ready=False, stall=None):
        """按住左鍵到隊伍 HUD 消失(臨寰宇出手)。消失後再按 XN2_RELEASE_AFTER_GONE 秒鬆手。返回出手沒有。

        watch_ready: 人像出來 XN2_READY_REPRESS 還沒出手 = 這一下按住斷了, 鬆開重按。
        stall: 這麼多秒沒再翻一顆也沒出手就鬆手返回(交給呼叫端普攻補完再按)。
        """
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        gone = 0
        fired = False
        ready_since = None
        repress = 0
        last_count = None
        moved_at = start
        try:
            while time.time() - start < cap:
                self.task.next_frame()
                if not self.hud_ok():
                    gone += 1
                    if gone >= self.LIB_GONE_CONFIRM:
                        fired = True
                        break
                else:
                    gone = 0
                    if stall is not None:
                        try:
                            count = self.xn_statue_count()
                        except Exception as e:
                            count = last_count
                            self.logger.info(f'xn_statue_count failed ({e})')
                        if count != last_count:
                            last_count = count
                            moved_at = time.time()
                        elif time.time() - moved_at >= stall:
                            self.macro_mark(f'{tag}停在{count}顆({time.time() - start:.2f}s)')
                            break
                    if watch_ready and repress < self.XN2_REPRESS_MAX:
                        if self.xn_slot_state() == 'ready':
                            ready_since = ready_since or time.time()
                            if time.time() - ready_since >= self.XN2_READY_REPRESS:
                                repress += 1
                                ready_since = None
                                self.release_attack()
                                self.macro_wait(0.05)
                                self.xn_attack_down()
                                self.macro_mark(f'{tag}人像出來沒出手,重按#{repress}({time.time() - start:.2f}s)')
                        else:
                            ready_since = None
                self.macro_wait(0.02)
            if fired:
                self.macro_mark(f'{tag}臨寰宇出手({time.time() - start:.2f}s)')
                self.macro_wait(self.XN2_RELEASE_AFTER_GONE)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}鬆開({"出手" if fired else "沒出"})')
        return fired

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def xn_slot_glyph(self):
        """重擊位 16x16 灰階(只取圓內像素), 已歸一化。心不在場/HUD 不在返回 None。讀當前幀。"""
        in_team, index, _count = self.task.in_team()
        if not in_team or index != self.index:
            return None
        self.hud_seen_at = time.time()
        ref = getattr(self, '_slot_ref', None)
        if ref is None:
            yy, xx = np.mgrid[:96, :96]
            disk = ((((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2)).astype(np.float32)
            mask = cv2.resize(disk[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA) > 0.99

            def tpl(chunks):
                raw = base64.b64decode(''.join(chunks))
                return self.glyph_vec(np.frombuffer(raw, np.uint8).reshape(16, 16).astype(np.float32)[mask])

            ref = self._slot_ref = (mask, disk, tpl(self.XN_TY_GLYPH), tpl(self.XN_READY_GLYPH))
        mask, disk, _ty, _rd = ref
        x, y, w, h = self.XN_TY_SLOT
        box = self.task.box_of_screen_scaled(3840, 2160, x, y, x + w, y + h, hcenter=True)
        frame = self.task.frame
        cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
        half = int(box.height * 1.1)
        icon = frame[max(0, cy - half):cy + half, max(0, cx - half):cx + half, :3]
        g = cv2.cvtColor(cv2.resize(icon, (96, 96), interpolation=cv2.INTER_AREA),
                         cv2.COLOR_BGR2GRAY).astype(np.float32) * disk
        v = cv2.resize(g[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA)
        return self.glyph_vec(v[mask])

    def xn_slot_state(self):
        """統御眾機裡重擊位: 'statue'(照世心還沒打空) / 'ready'(人像, 臨寰宇可按) / '?' / None(HUD 不在)。讀當前幀。"""
        try:
            v = self.xn_slot_glyph()
            if v is None:
                return None
            _mask, _disk, ty, rd = self._slot_ref
            self._ty_score = float(v @ ty)
            self._rd_score = float(v @ rd)
            if self._rd_score >= self.XN_READY_MIN:
                return 'ready'
            if self._ty_score >= self.XN_TY_MIN:
                return 'statue'
            return '?'
        except Exception as e:
            self.logger.info(f'xn_slot_state probe failed ({e})')
            return '?'

    def dodge(self, tag):
        """閃避(右鍵)。"""
        self.task.mouse_down(key='right')
        try:
            self.macro_wait(self.XN2_DODGE_HOLD)
        finally:
            self.task.mouse_up(key='right')
        self.macro_mark(f'{tag}閃避')

    def xn_statue_reset(self):
        self._statue_streak = [0] * len(self.XN_STATUE_XS)
        self._statue_latch = [False] * len(self.XN_STATUE_XS)

    def xn_statue_count(self):
        """照世心雕像從右往左連續翻了幾顆(翻過的記住, 每次進統御眾機先 xn_statue_reset)。讀當前幀。
        同一幀新記住 >= XN_STATUE_BURST 顆 = 閃光, 這一幀不算。"""
        frame = self.task.frame
        hw = self.XN_STATUE_HW
        newly = []
        for k, x in enumerate(self.XN_STATUE_XS):
            if self._statue_latch[k]:
                continue
            red = glow = 0.0
            for y, kind in ((self.XN_STATUE_Y, 'red'), (self.XN_STATUE_UP_Y, 'glow')):
                box = self.task.box_of_screen_scaled(3840, 2160, x - hw, y - hw, x + hw, y + hw, hcenter=True)
                crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
                if crop.size == 0:
                    continue
                hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
                h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                if kind == 'red':
                    red = float((((h < 12) | (h > 160)) & (sat > 90) & (v > 110)).mean())
                else:
                    glow = float(((v > 235) & (sat < 60)).mean())
            hit = red >= self.XN_STATUE_RED or glow >= self.XN_STATUE_GLOW
            self._statue_streak[k] = self._statue_streak[k] + 1 if hit else 0
            if self._statue_streak[k] >= self.XN_STATUE_CONFIRM:
                newly.append(k)
        if len(newly) >= self.XN_STATUE_BURST:
            for k in newly:
                self._statue_streak[k] = 0
        else:
            for k in newly:
                self._statue_latch[k] = True
        n = 0
        for latched in reversed(self._statue_latch):
            if not latched:
                break
            n += 1
        return n

    def xn_ty_attack(self, tag, start, until_count, min_t, cap_t, every=None):
        """統御眾機裡點普攻, 每幀數雕像、看重擊位。時間從 start 起算: min_t 之前不停;
        翻滿 until_count 顆(或人像出來)就停; 到 cap_t 照停。返回 (原因, 翻了幾顆)。"""
        every = self.XN2_TY_A_EVERY if every is None else every
        n = 0
        next_click = 0.0
        count = 0
        ready_hits = 0
        counts = []
        last_count = -1
        why = 'cap'
        while time.time() - start < cap_t:
            if time.time() >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, every - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            if st is not None:
                try:
                    count = self.xn_statue_count()
                except Exception as e:
                    self.logger.info(f'xn_statue_count failed ({e})')
                if count != last_count:
                    last_count = count
                    if len(counts) < 12:
                        counts.append(f'{count}@{time.time() - start:.2f}')
            ready_hits = ready_hits + 1 if st == 'ready' else 0
            if ready_hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            if count >= until_count and time.time() - start >= min_t:
                why = 'count'
                break
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}(A x{n},翻{count},{why},{time.time() - start:.2f}s)')
        if counts:
            self.logger.info(f'{tag}: 照世心雕像翻面(顆@秒) — {" ".join(counts)}')
        return why, count

    def xn_tongyu_phase(self, tag, cap):
        """統御眾機裡一直普攻到重擊位換成人像(照世心打空)。返回 'ready' / 'cap'。"""
        start = time.time()
        n = 0
        next_click = 0.0
        hits = 0
        why = 'cap'
        last = None
        statue_seen = False
        while time.time() - start < cap:
            now = time.time()
            if now >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, self.XN2_TY_A_EVERY - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            last = st
            statue_seen = statue_seen or st == 'statue'
            hits = hits + 1 if st == 'ready' else 0
            if hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}照世心{"打空" if why == "ready" else "沒看到打空(cap)"}'
                        f'(A x{n},{time.time() - start:.2f}s{"" if statue_seen else ",沒見過雕像"})')
        if why != 'ready':
            self.logger.info(f'{tag}: {cap:.1f}s 沒看到重擊位換人像(最後讀成 {last}, '
                             f'雕像{getattr(self, "_ty_score", -1):.2f} 人像{getattr(self, "_rd_score", -1):.2f})')
        return why

    def seg_xn2(self, xn, intro, tag, opener=False):
        """心·第二段(變奏·照世相, 直接進統御眾機): 普攻到第 5 顆 -> 閃避 -> 普攻到第 7 顆 -> 按住到臨寰宇
        -> 演完 -> [開大前沒怪就中鍵鎖敵等] -> 萬闕垂天(認 hsin_lib2) -> [按過白屏時停 -> 重擊] -> E -> 協奏補滿。"""
        heavy = self.LQ_XN2_R2_HEAVY_OPENER if opener else self.LQ_XN2_R2_HEAVY
        self.wait_until_time(self.switch_press_at + self.XN2_LEAD)
        self.xn_statue_reset()
        why, count = self.xn_ty_attack(f'{tag}3A', time.time(), self.LQ_XN2_DODGE_COUNT, self.XN2_DODGE_MIN,
                                       self.LQ_XN2_DODGE_CAP)
        if why != 'ready':
            self.dodge(tag)
            self.macro_wait(self.XN2_DODGE_TO_A)
            self.xn_ty_attack(f'{tag}閃後2A', time.time(), self.XN2_HOLD_AT, 0.0, self.XN2_EMPTY_CAP,
                              every=self.XN2_POST_DODGE_A_EVERY)
        fired = self.xn_hold_until_gone(self.XN2_HOLD_CAP, f'{tag}按住', watch_ready=True,
                                        stall=self.XN2_HOLD_STALL)
        for attempt in range(1, 1 + self.XN2_RETRIES):
            if fired:
                break
            # 沒拿到變奏(沒進統御眾機)時先按一下 E
            if attempt == 1 and not intro:
                self.spam_key(xn.send_resonance_key, 0.2, interval=0.06, tag=f'{tag}補E(沒變奏)')
                xn.record_resonance_use()
            why = self.xn_tongyu_phase(f'{tag}補#{attempt}', self.XN2_RETRY_CAP)
            fired = self.xn_hold_until_gone(self.XN2_READY_HOLD if why == 'ready' else self.XN2_BLIND_HOLD,
                                            f'{tag}重按#{attempt}', watch_ready=True)
        if not fired:
            self.logger.warning(f'{tag}: 臨寰宇一直沒出手, 這一輪不放萬闕垂天(按 R 會放成借相)')
        else:
            self.wait_hud_back(tag=f'{tag}臨寰宇演出', min_gone=self.XN2_ANIM_MIN, time_out=self.XN2_ANIM_CAP)
            if self.XN2_R2_BLIND:
                unlocked = True
            else:
                # 【R 只認 hsin_lib2】照世相裡 R 一直亮(借相·應世)
                unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
                self.macro_mark(f'{tag}萬闕垂天{"解鎖" if unlocked else "圖示沒認出(能量不夠?)"}({t:.2f}s)')
                if not unlocked:
                    unlocked, t = self.xn_wait_lib2(self.XN2_R2_BUILD_CAP, build=True)
                    self.macro_mark(f'{tag}普攻攢大招能量({"認出萬闕垂天" if unlocked else "cap"},{t:.2f}s)')
            fired = False
            wave = True
            back_at = time.time()
            for attempt in range(2):
                if not unlocked:
                    break
                if attempt == 0:
                    # 開大前沒怪: 中鍵鎖敵等新怪, 時間到照放; 等完萬闕垂天圖示沒了就不放(會放成借相)
                    if self.XN2_PRE_R2_WAVE and not self.xn_pre_r2_wave(tag):
                        unlocked = False
                        break
                    if self.XN2_PRE_R2:
                        self.xn_pre_r2_con(tag)
                    if self.LQ_XN2_ECHO:
                        xn.send_echo_key(down_time=0.05)
                        xn.record_echo_use()
                        self.macro_wait(0.05)
                fired = self.fire_r(xn, f'{tag}萬闕垂天' if attempt == 0 else f'{tag}萬闕垂天重按', self.XN_R_WINDOW)
                if fired:
                    self.wait_hud_back(tag=f'{tag}萬闕垂天演出', min_gone=self.XN_R_ANIM_MIN,
                                       time_out=self.XN_R_ANIM_CAP,
                                       hold_from=self.XN2_R2_HOLD_FROM if heavy else None)
                    back_at = time.time()
                    if heavy and not self.holding_attack:
                        self.xn_attack_down()
                        self.macro_mark(f'{tag}大招後才按住')
                    thaw_at = back_at + self.XN2_R2_FREEZE
                    if self.XN2_R2_WAVE_WAIT and not self.xn_r2_target(tag, back_at):
                        self.release_attack()
                        wave = self.xn_wait_wave(tag)
                        if wave and heavy:
                            self.wait_until_time(thaw_at)
                            self.xn_attack_down()
                            self.macro_wait(self.XN2_R2_FRESH_HOLD)
                            self.release_attack()
                            self.macro_mark(f'{tag}新怪重擊鬆開({self.XN2_R2_FRESH_HOLD:.2f}s)')
                            self.macro_wait(self.XN2_R2_FRESH_E_AT)
                    elif heavy:
                        self.wait_until_time(thaw_at + self.XN2_R2_HEAVY_HOLD)
                        self.release_attack()
                        self.macro_mark(f'{tag}大招後重擊鬆開(解凍+{self.XN2_R2_HEAVY_HOLD:.2f}s)')
                        self.wait_until_time(thaw_at + self.XN2_R2_E_AT)
                    break
                # 沒放出去: 認一下 R 位還是不是萬闕垂天, 認得出才重按
                if self.XN2_R2_BLIND:
                    unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
                else:
                    unlocked, t = self.xn_wait_lib2(1.50, build=True)
            if not fired:
                self.logger.warning(f'{tag}: 萬闕垂天沒放出去'
                                    f'({"能量攢不滿/圖示沒認出, 不照按(會放成借相)" if not unlocked else "按了沒出"})')
            elif not wave:
                self.macro_mark(f'{tag}沒等到新怪(不重擊不E)')
            elif self.XN2_E_AFTER_R2 and time.time() - getattr(xn, 'last_res', 0) >= self.XN_E_CD:
                if self.press_res_until_cd(xn, self.XN2_E_CAP, f'{tag}E偷傷害', ready_grace=0.15):
                    xn.record_resonance_use()
            if fired and heavy and self.XN2_TAIL_A:
                self.xn_tail_ying(tag, back_at)
        self.xn_ensure_con(xn, tag)

    def target_visible(self):
        """鎖定目標在不在。照 CombatCheck.has_target() 的讀框, 去掉它最後那個兜底分支(會 sleep 再按 ESC)。"""
        t = self.task
        try:
            has_name, no_name = t.get_target_names()
            scale = 1.2 if t.is_browser() else 1.1
            for box in (t.get_box_by_name(has_name).scale(scale), t.get_box_by_name('box_target_enemy_long'),
                        t.get_box_by_name('target_box_long2')):
                best = t.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception as e:
            # 別的 工具 版本這幾個讀框/方法可能改名了: 當成有怪
            if not getattr(self, '_target_visible_warned', False):
                self._target_visible_warned = True
                self.logger.warning(f'xsv target_visible unsupported in this 工具 version ({e!r}), assuming a target is there')
            return True
        return False

    def xn_enemy_here(self):
        """場上有沒有怪: Boss 破盾/鎖圖示、怪物血條、鎖定目標, 任一個讀到就算有。"""
        t = self.task
        try:
            if t.is_boss() or t.has_health_bar():
                return True
        except Exception as e:
            if not getattr(self, '_health_bar_warned', False):
                self._health_bar_warned = True
                self.logger.warning(f'xsv is_boss/has_health_bar unsupported in this 工具 version ({e!r})')
        return self.target_visible()

    def xn_enemy_seen(self, window):
        """window 秒內有沒有怪: 一幀讀到就算有; 一幀都沒讀到而且讀夠 TARGET_GONE_CONFIRM 幀 = 沒怪;
        幀數不夠(卡幀)當有怪(寧可照放, 不白等)。"""
        end = time.time() + window
        frames = 0
        while time.time() < end:
            self.task.next_frame()
            self.hud_ok()
            if self.xn_enemy_here():
                return True
            frames += 1
            self.macro_wait(0.02)
        return frames < self.TARGET_GONE_CONFIRM

    def xn_pre_r2_wave(self, tag):
        """開大前看有沒有怪; 沒有就中鍵重新鎖敵, 等新怪最多 XN2_PRE_R2_WAVE_CAP, 時間到照放。
        等過之後再認一次萬闕垂天圖示: 認不出 = 已經不是萬闕垂天(按了是借相)。返回還能不能放。"""
        if self.xn_enemy_seen(self.XN2_PRE_R2_LOOK):
            return True
        self.macro_mark(f'{tag}開大前沒怪(中鍵鎖敵)')
        self.xn_wait_wave(tag, cap=self.XN2_PRE_R2_WAVE_CAP)
        unlocked, t = self.xn_wait_lib2(self.XN2_LIB2_CAP)
        if not unlocked:
            self.macro_mark(f'{tag}等完怪萬闕垂天圖示沒了(不放,{t:.2f}s)')
        return unlocked

    def xn_r2_target(self, tag, back_at):
        """萬闕垂天 HUD 回來後的時停裡看有沒有怪(XN2_R2_WAVE_WAIT 用)。"""
        gone = 0
        while time.time() < back_at + self.XN2_R2_TARGET_BY:
            self.task.next_frame()
            if self.xn_enemy_here():
                return True
            gone += 1
        if gone < self.TARGET_GONE_CONFIRM:
            return True
        self.macro_mark(f'{tag}時停裡沒怪(鬆手等新一波, {gone}幀)')
        return False

    def xn_wait_wave(self, tag, cap=None):
        """沒怪: 不點普攻(空揮), 每 WAVE_LOCK_INTERVAL 按中鍵, 連 ENEMY_CONFIRM 幀讀到怪就返回 True, 上限 cap。"""
        cap = self.XN2_WAVE_WAIT if cap is None else cap
        start = time.time()
        next_mid = 0.0
        hits = 0
        while time.time() - start < cap:
            self.task.next_frame()
            self.hud_ok()
            hits = hits + 1 if self.xn_enemy_here() else 0
            if hits >= self.ENEMY_CONFIRM:
                self.macro_mark(f'{tag}等到新一波({time.time() - start:.2f}s)')
                return True
            if time.time() >= next_mid:
                self.task.middle_click()
                next_mid = time.time() + self.WAVE_LOCK_INTERVAL
            self.macro_wait(0.05)
        self.macro_mark(f'{tag}{cap:.1f}s沒等到新怪')
        return False

    def xn_tail_ying(self, tag, back_at):
        """萬闕垂天之後(回到應世相): 普攻到應世心左半 >= XN2_TAIL_YING 再交棒(XN2_TAIL_A 用)。"""
        start = time.time()
        taps = 0
        next_tap = 0.0
        hits = 0
        L = 0.0
        while time.time() < back_at + self.XN2_TAIL_CAP:
            self.task.next_frame()
            if self.hud_ok():
                full, L, R = self.xn_ying()
                hits = hits + 1 if (full or L >= self.XN2_TAIL_YING) else 0
                if hits >= 2:
                    self.macro_mark(f'{tag}收尾應世心({L:.2f},A x{taps},{time.time() - start:.2f}s)')
                    return True
            if time.time() >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                next_tap = time.time() + max(0.0, self.XN1_TAP_EVERY - self.XN1_A_HOLD)
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}收尾應世心(cap,{L:.2f},A x{taps})')
        return False

    def xn_wait_lib2(self, cap, build=False):
        """等 R 位變成萬闕垂天(hsin_lib2 連讀幾幀)。build: 期間點普攻攢大招能量。返回 (認出沒有, 用時)。"""
        start = time.time()
        hits = 0
        next_tap = 0.0
        while time.time() - start < cap:
            if build and time.time() >= next_tap:
                self.tap()
                next_tap = time.time() + max(0.0, self.A_INTERVAL - self.A_TAP)
            self.task.next_frame()
            if self.hud_ok():
                hits = hits + 1 if self.xn_icon('hsin_lib2') else 0
                if hits >= self.XN2_LIB2_READS:
                    return True, time.time() - start
            self.macro_wait(0.02)
        return False, time.time() - start

    def xn_pre_r2_con(self, tag):
        """萬闕垂天之前: 協奏低於 XN2_PRE_R2_CON 就照世相普攻補(XN2_PRE_R2 用)。"""
        start = time.time()
        con = self.read_con(1.0, settle=0.12)
        if con >= self.XN2_PRE_R2_CON:
            self.macro_mark(f'{tag}開大前協奏{con:.2f}')
            return
        taps = 0
        while time.time() - start < self.XN2_PRE_R2_CAP:
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            con = self.read_con(1.0, settle=0.03)
            if con >= self.XN2_PRE_R2_CON:
                break
        self.macro_mark(f'{tag}開大前補協奏({con:.2f},A x{taps},{time.time() - start:.2f}s)')

    def xn_ensure_con(self, xn, tag):
        """心切維之前協奏要真滿: 讀一下, 不滿就 E -> 普攻, 每下之後讀一次。返回滿沒滿。"""
        start = time.time()
        if self.con_ready(xn, self.XN2_CON_READ):
            return True
        samples = [f'0:{self.con_last:.2f}']
        taps = 0
        used_e = False
        while time.time() - start < self.XN2_CON_CAP:
            if not used_e and time.time() - getattr(xn, 'last_res', 0) >= self.XN_E_CD:
                used_e = True
                self.spam_key(xn.send_resonance_key, 0.26, interval=0.06, tag=f'{tag}補協奏E')
                xn.record_resonance_use()
            else:
                self.tap()
                taps += 1
                self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            full = self.con_ready(xn, 0.03)
            if len(samples) < 20:
                samples.append(f'{time.time() - start:.2f}:{self.con_last:.2f}')
            if full:
                self.macro_mark(f'{tag}補協奏(滿,E{int(used_e)},A x{taps},{time.time() - start:.2f}s)')
                return True
        self.macro_mark(f'{tag}補協奏(cap,E{int(used_e)},A x{taps},{time.time() - start:.2f}s)')
        self.logger.warning(f'{tag}: 心補了 {time.time() - start:.1f}s 協奏還是沒滿, 維里奈拿不到變奏'
                            f' — {" ".join(samples)}')
        return False

    # ==================== 鎖暝 ====================

    def so_forte_full(self, so):
        """妄執滿(E 位是鎖妄念/無捨念, 框架的 suoming_forte_e 模板)。讀當前幀。"""
        try:
            return bool(so.forte_available())
        except Exception:
            return False

    def so_on_field(self, so):
        """隊伍 HUD 在場而且當前是 so(誰都行; 剛切人那幾幀技能欄還是上一個人的)。讀當前幀。"""
        try:
            in_team, index, _count = self.task.in_team()
        except Exception:
            return False
        return bool(in_team) and index == so.index

    def so_r_asap(self, so, tag, cap, allow_e):
        """鎖暝進場就放 R, R 沒好(CD / 能量不夠)就一直點 A, 好了馬上出, 不站著等。
        每下 A 之後順手按一下 R; 讀到 R 亮: 入場動作裡一直按, 入場之後連按 LQ_SO_R_BURST, HUD 沒消失就回去點 A。
        allow_e: 沒變奏入場(念起, R 鎖著)時妄執滿了點 E 進念深。"""
        sw = self.switch_press_at
        start = time.time()
        taps = bursts = r_n = e_taps = 0
        next_tap = 0.0
        burst_until = backoff_until = 0.0
        last_r = -9.0
        next_e = sw + self.LQ_SO_R_E_FROM
        lit_hits = forte_hits = gone = 0
        fired = False
        while time.time() - start < cap:
            self.task.next_frame()
            now = time.time()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM and now - last_r < 0.6:
                    fired = True
                    break
                self.macro_wait(0.01)
                continue
            gone = 0
            on = self.so_on_field(so)
            try:
                lit = on and bool(so.liberation_available())
            except Exception:
                lit = False
            lit_hits = lit_hits + 1 if lit else 0
            forte_hits = forte_hits + 1 if on and self.so_forte_full(so) else 0
            if now < burst_until:
                so.send_liberation_key()
                r_n += 1
                last_r = now
            elif lit_hits >= 2 and now >= backoff_until:
                bursts += 1
                burst_until = max(now + self.LQ_SO_R_BURST, sw + self.LQ_SO_R_ENTRY)
                backoff_until = burst_until + self.LQ_SO_R_BACKOFF * bursts
                so.send_liberation_key()
                r_n += 1
                last_r = now
            elif allow_e and forte_hits >= 2 and not lit and now >= next_e:
                self.so_tap_e(so.get_resonance_key())
                so.record_resonance_use()
                e_taps += 1
                next_e = time.time() + 1.0
            elif now >= next_tap:
                self.tap()
                so.send_liberation_key()
                r_n += 1
                taps += 1
                last_r = time.time()
                next_tap = last_r + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(self.LIB_KEY_INTERVAL if time.time() < burst_until else 0.01)
        self.task.skip_combat_check = True
        el = time.time() - start
        e_note = f',E x{e_taps}' if e_taps else ''
        if fired:
            so.record_liberation_use()
            self.macro_mark(f'{tag}R_fired(A x{taps},R x{r_n},連按{bursts}次{e_note},{el:.2f}s)')
        else:
            self.macro_mark(f'{tag}R_NOFIRE(cap,A x{taps},R x{r_n},連按{bursts}次{e_note},{el:.2f}s)')
        return fired

    def so_echo(self, so, tag, cap=None):
        """一直按 Q 到聲骸 CD 漲上來(比按之前高 SO_ECHO_RISE, 連 2 幀)。返回放出去沒有。so 可以是任何人。"""
        cap = self.SO_ECHO_CAP if cap is None else cap
        cd0 = self.read_cd('echo', so)
        start = time.time()
        n = hits = 0
        fired = False
        while time.time() - start < cap:
            so.send_echo_key()
            n += 1
            self.task.next_frame()
            up = self.so_on_field(so) and self.read_cd('echo', so) > cd0 + self.SO_ECHO_RISE
            hits = hits + 1 if up else 0
            if hits >= 2:
                fired = True
                break
            self.macro_wait(0.06)
        if fired:
            so.record_echo_use()
        else:
            self.logger.info(f'{tag}: 按了 {n} 下聲骸 CD 沒漲(基線 {cd0:.1f}s) — 被收招吞了, 還是讀不到數?')
        self.macro_mark(f'{tag}({"出" if fired else "cap"},x{n},{time.time() - start:.2f}s)')
        return fired

    def so_tap_e(self, key):
        """點一下 E, 真的按住 SO_KX_E_TAP 秒。"""
        self.task.send_key_down(key)
        try:
            self.macro_wait(self.SO_KX_E_TAP)
        finally:
            self.task.send_key_up(key)

    def so_wuse(self, so, tag):
        """點 E 出無捨念: E 位是無捨念就每 SO_KX_E_EVERY 點一下, 讀到出了(連 2 幀不是無捨念)就停, 上限 SO_KX_WUSE_CAP。
        返回 (E 鍵, 停下的時刻)。"""
        key = so.get_resonance_key()
        start = time.time()
        e_taps = gone = 0
        next_e = 0.0
        out = False
        while time.time() - start < self.SO_KX_WUSE_CAP:
            self.task.next_frame()
            if self.so_on_field(so):
                if self.so_forte_full(so):
                    gone = 0
                    if time.time() >= next_e:
                        self.so_tap_e(key)
                        e_taps += 1
                        next_e = time.time() + max(0.0, self.SO_KX_E_EVERY - self.SO_KX_E_TAP)
                else:
                    gone += 1
                    if gone >= 2 and e_taps:
                        out = True
                        break
            self.macro_wait(0.01)
        so.record_resonance_use()
        t_w = time.time()
        self.macro_mark(f'{tag}無捨念({"出" if out else "cap"},E x{e_taps},{t_w - start:.2f}s)')
        return key, t_w

    def so_kx_hold(self, so, key, t_w, tag):
        """無捨念出了之後按住普攻出刻心念, 一直按著轉圈(時停), 轉完收招 +40 協奏、光圈出來就鬆手。
        按下時協奏已經滿著(光圈一直在)就按滿 LQ_SO_KX_HOLD_BLIND。
        按住期間 E 位又是無捨念 = 沒放出來: 鬆開, 連點 E 到放出來, 再按住(最多 LQ_SO_KX_E_MAX 輪)。"""
        self.wait_until_time(t_w + self.SO_KX_A_FROM)
        strict = self.glow_trusted()
        si = self.xn_attack_down()
        first_held = held_at = time.time()
        why = 'cap'
        pre_full = None
        e_more = e_hits = con_hits = 0
        try:
            while time.time() - held_at < self.LQ_SO_KX_HOLD_CAP:
                self.task.next_frame()
                el = time.time() - held_at
                if not self.hud_ok():
                    self.macro_wait(0.02)
                    continue
                on = self.so_on_field(so)
                e_hits = e_hits + 1 if on and self.so_forte_full(so) else 0
                if (e_hits >= 2 and e_more < self.LQ_SO_KX_E_MAX
                        and time.time() - first_held < self.LQ_SO_KX_E_RESCUE_CAP):
                    self.release_attack()
                    e_more += 1
                    key, t_w = self.so_wuse(so, f'{tag}補#{e_more}')
                    self.wait_until_time(t_w + self.SO_KX_A_FROM)
                    si = self.xn_attack_down()
                    held_at = time.time()
                    pre_full = None
                    e_hits = con_hits = 0
                    continue
                try:
                    con = float(self.task.get_current_con())
                except Exception:
                    con = 0.0
                if pre_full is None:
                    # 單幀: con_glow 要連 GLOW_CONFIRM 幀, 第一幀永遠是 False
                    pre_full = self.glow_now(so) or (not strict and con >= self.SK_CON_ENOUGH)
                if pre_full:
                    if el >= self.LQ_SO_KX_HOLD_BLIND:
                        why = '原來就滿'
                        break
                elif self.con_glow(so):
                    if el >= self.LQ_SO_KX_HOLD_MIN:
                        why = '光圈'
                        break
                elif not strict:
                    con_hits = con_hits + 1 if con >= self.SK_CON_ENOUGH else 0
                    if con_hits >= self.SK_CON_FULL_CONFIRM and el >= self.LQ_SO_KX_HOLD_MIN:
                        why = '讀數'
                        break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}刻心念按住({why},{"SI" if si else "PM"},{time.time() - held_at:.2f}s'
                        f'{f",補E x{e_more}" if e_more else ""})')
        return why

    def so_kx_wait_con(self, so, tag, cap):
        """刻心念之後不按鍵等協奏真滿(光圈; 光圈認得出過就不信讀數, 讀數滿了再給 SO_KX_GLOW_GRACE)。返回滿沒滿。"""
        start3 = time.time()
        hits = 0
        samples = []
        full = False
        strict = self.glow_trusted()
        con_full_at = None
        while time.time() - start3 < cap:
            self.task.next_frame()
            if not self.hud_ok():
                self.macro_wait(0.02)
                continue
            if self.con_glow(so):
                full = True
                samples.append('光圈')
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX and (not samples or time.time() - start3 >= len(samples) * 0.3):
                samples.append(f'{time.time() - start3:.2f}:{con:.2f}')
            hits = hits + 1 if con >= self.SK_CON_ENOUGH else 0
            if hits >= self.SK_CON_FULL_CONFIRM:
                if not strict:
                    full = True
                    break
                con_full_at = con_full_at or time.time()
                if time.time() - con_full_at >= self.SO_KX_GLOW_GRACE:
                    samples.append('讀數滿沒光圈')
                    break
            self.macro_wait(self.SK_CON_POLL)
        glow = ',光圈' if samples and samples[-1] == '光圈' else (',讀數滿沒光圈' if samples and samples[-1] == '讀數滿沒光圈' else '')
        self.macro_mark(f'{tag}等協奏({"滿" if full else "沒滿"}{glow},{time.time() - start3:.2f}s)')
        if not full:
            self.logger.info(f'{tag}: 刻心念之後 {cap:.1f}s 協奏沒滿 — {" ".join(samples)}')
        return full

    def seg_lq_so_a(self, so, xn, tag):
        """鎖暝·第一次上場(維變奏進來 = 變奏·閃裂, 念起 -> 念深): R [沒好就一直 A 到好] -> 演完 -> 點一下 A
        -> Q(暗鳥) -> 同奏切心。返回心帶不帶變奏(R 出沒出)。"""
        self.wait_until_time(self.switch_press_at + self.SO_R_LEAD)
        fired = self.so_r_asap(so, tag, self.LQ_SO_R_CAP, allow_e=not so.has_intro)
        if fired:
            self.so_tongzou_at = time.time()
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.SO_R_ANIM_MIN, time_out=self.SO_R_ANIM_CAP)
            for i in range(self.LQ_SO_A_TAPS):
                if i:
                    self.macro_wait(max(0.0, self.SO_A_EVERY - self.A_TAP))
                self.tap()
            self.macro_mark(f'{tag}R後A(x{self.LQ_SO_A_TAPS})')
        else:
            self.logger.warning(f'{tag}: 鎖暝 R 沒放出去(能量不夠 / 沒進念深) — 心拿不到同奏')
        self.so_echo(so, f'{tag}Q暗鳥')
        full = fired
        if not fired:
            full = self.read_con(1.0, settle=0.15) >= 1.0
        self.need(self.switch_retry(xn, f'{tag}切心', assume_con=full), 'suoming -> hsin')
        return full

    def seg_lq_so_b(self, so, xn, tag):
        """鎖暝·第二次上場(心轉相的同奏 -> 旋雷破·同奏, 念深 +200 妄執): 點 A 到妄執滿 -> 點 E(無捨念)
        -> 按住普攻(刻心念轉滿) -> 協奏滿變奏心。返回協奏滿沒滿。
        妄執沒滿時按 E 是破隙(冷卻 8s, 這一圈就沒無捨念了), 所以讀到滿(連 2 幀)才點 E。"""
        sw = self.switch_press_at
        self.wait_until_time(sw + self.LQ_SO_B_A_LEAD)
        start = time.time()
        taps = hits = 0
        next_tap = 0.0
        ok = False
        while time.time() - start < self.LQ_SO_B_FILL_CAP:
            self.task.next_frame()
            if self.so_on_field(so):
                hits = hits + 1 if self.so_forte_full(so) else 0
                if hits >= 2:
                    ok = True
                    break
            if time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}A到妄執滿({"滿" if ok else "cap"},A x{taps},{time.time() - start:.2f}s)')
        if ok:
            key, t_w = self.so_wuse(so, tag)
            self.so_kx_hold(so, key, t_w, tag)
            full = self.so_kx_wait_con(so, tag, self.LQ_SO_KX_FINISH_CAP)
        else:
            self.logger.warning(f'{tag}: 鎖暝 {self.LQ_SO_B_FILL_CAP:.1f}s 妄執沒滿, 接著普攻到妄執滿再出刻心念')
            full = False
        if not full:
            full = self.so_ensure_intro(so, tag)
        self.need(self.switch_retry(xn, f'{tag}切心', assume_con=full, time_out=self.SO_TO_XN_TIME_OUT),
                  'suoming -> hsin')
        return full

    def so_ensure_intro(self, so, tag):
        """鎖暝協奏不滿不切: 一直普攻, 妄執滿了就再出一次無捨念 + 按住刻心念(+40 協奏), 光圈出來才走。
        光圈認得出過就只認光圈, 讀數滿了 LQ_SO_B_READ_GRACE 還沒光圈也走。返回滿沒滿。"""
        start = time.time()
        strict = self.glow_trusted()
        taps = kx = forte_hits = con_hits = 0
        next_tap = 0.0
        read_full_at = None
        why = 'cap'
        while time.time() - start < self.LQ_SO_B_ENSURE_CAP:
            self.task.next_frame()
            if not self.hud_ok():
                self.macro_wait(0.02)
                continue
            if self.con_glow(so):
                why = '光圈'
                break
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            con_hits = con_hits + 1 if con >= self.SK_CON_ENOUGH else 0
            if con_hits >= self.SK_CON_FULL_CONFIRM:
                read_full_at = read_full_at or time.time()
                if not strict or time.time() - read_full_at >= self.LQ_SO_B_READ_GRACE:
                    why = f'讀數{con:.2f}'
                    break
            else:
                read_full_at = None
            on = self.so_on_field(so)
            forte_hits = forte_hits + 1 if on and self.so_forte_full(so) else 0
            if forte_hits >= 2 and kx < self.LQ_SO_B_KX_MAX:
                kx += 1
                forte_hits = con_hits = 0
                read_full_at = None
                key, t_w = self.so_wuse(so, f'{tag}保變奏#{kx}')
                self.so_kx_hold(so, key, t_w, f'{tag}保變奏#{kx}')
                continue
            if time.time() >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.SO_A_EVERY - self.A_TAP)
            self.macro_wait(0.01)
        full = why != 'cap'
        self.macro_mark(f'{tag}保變奏({why},刻心念x{kx},A x{taps},{time.time() - start:.2f}s)')
        if not full:
            self.logger.warning(f'{tag}: 鎖暝補了 {self.LQ_SO_B_ENSURE_CAP:.0f}s 協奏還是沒滿(打不到怪?), '
                                f'心只能普通入場')
        return full

    # ==================== 一圈 ====================

    def run_cycle(self, so, vr, opener, tag):
        """維 QER 打滿協奏 -> 鎖暝 R 暗鳥 -> 心 轉相 E -> 鎖暝 刻心念 -> 心 統御眾機 萬闕垂天 重擊 E -> 維變奏入場、HUD 回來。"""
        marks = len(self.macro_marks)
        self.timeline_logged = False
        self.seg_vr(vr, so, tag=f'{tag}維', opener=opener)
        self.seg_lq_so_a(so, self, tag=f'{tag}鎖a')
        self.seg_xn1(self, so, tag=f'{tag}心1')
        intro = self.seg_lq_so_b(so, self, tag=f'{tag}鎖b')
        self.seg_xn2(self, intro, tag=f'{tag}心2', opener=opener)
        if self.SK_BREAK:
            self.note_break_prompt()
        self.need(self.switch_to_sk(vr, tag=f'{tag}切維'), 'hsin -> verina')
        self.logger.info(f'{tag} cycle timeline: {self.macro_timeline(marks)}')
        self.timeline_logged = True

    def macro_enter(self, entry_char):
        so = self.teammate('Suoming')
        vr = self.teammate('Verina')
        if so is None or vr is None:
            return None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        for char in (self, so, vr):
            char.check_f_on_switch = False
        self.macro_start()
        self.timeline_logged = False
        self.hud_seen_at = time.time()
        self.enemy_seen_at = time.time()
        self.enemy_check_at = 0.0
        self.unlocked_since = None
        self.relock_n = 0
        self.relock_at = 0.0
        self.hud_watch = True
        return so, vr, previous

    def macro_exit(self, previous):
        # 長按跨了好幾個方法, 中途拋例外的話滑鼠會一直按著。這裡是唯一保證鬆手的地方
        self.release_attack()
        if not self.timeline_logged and self.macro_marks:
            self.logger.info(f'xsv timeline (沒跑完): {self.macro_timeline()}')
            self.timeline_logged = True
        self.hud_watch = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def perform_opener(self, entry_char=None):
        """啟動軸: 切維里奈 -> 一圈。返回時維里奈剛變奏入場、HUD 在場。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        so, vr, previous = got
        self.logger.info(f'xsv opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            self.so_tongzou_at = -99.0
            if self.cur is not vr:
                self.need(self.switch_retry(vr, 'op'), 'opener: switch to verina')
            self.run_cycle(so, vr, opener=True, tag='op')
            self.logger.info(
                f'xsv opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'xsv opener broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循環軸一圈。場上不是維里奈(宏散過)就先把場子交給她。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        so, vr, previous = got
        try:
            if self.cur is not vr:
                self.need(self.switch_to_sk(vr, tag='L接維'), 'loop: hand the field to verina')
            self.loop_count += 1
            n = self.loop_count
            self.run_cycle(so, vr, opener=False, tag=f'L{n}')
            self.logger.info(
                f'xsv loop #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'xsv loop broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架介面 ====================

    def drive(self, entry):
        """三個人的 do_perform 都走這裡。entry = 框架這次呼叫的是誰(= 場上是誰)。"""
        # 【HUD 不在就什麼都不做】: 關卡結束/結算/過場時框架還會接著呼叫進來
        if not self.wait_hud_up(cap=self.DRIVE_HUD_CAP, tag='drive'):
            if time.time() - self.drive_log_at > 10:
                self.drive_log_at = time.time()
                self.logger.info('xsv: 隊伍 HUD 不在(結算/過場/視窗沒了?), 宏不動')
            return None
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 標記要在跑之前落: 中途拋例外(脫戰/任務被停)也不能讓啟動軸重跑
            self.opener_armed = False
            self.last_opener = time.time()
            return self.perform_opener(entry)
        self.logger.info(f'xsv: opener not pending ({blocked}), running the loop')
        return self.perform_loop(entry)

    def do_perform(self):
        if not self.is_in_xss:
            return super().do_perform()
        self.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """啟動軸待跑時讓維里奈先上。"""
        if self.is_in_xss and self.opener_pending():
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        return super().on_combat_end(chars)