import time

from src.char.BaseChar import SwitchPriority
from src.char.Lupa import Lupa as NativeLupa


class Lupa(NativeLupa):
    """露帕 —— 嘉露守（嘉贝莉娜 / 露帕 / 守岸人）25 秒轮椅轴里的这一棒。

    轴出处：教学视频 0–115 秒的「轮椅轴」轴表 + 用户《细节.txt》。三份文件共用同一套
    公共段（见 Galbrena.py 顶部注释），改一处记得同步三处。

    本角色在轴里的三棒：
      s1  露 REAAA —— 守岸人延奏进来（变奏）：R（大招）→ E（破敌，进 12 秒沸腾、升空）
           → 空中 A1 A2 A3（焰袭）。视频原话「露帕空中A3(焰袭)前摇出来切嘉贝」。
      s2  露 AE    —— 平切回来：1 下强化普攻 + E。
      s3  露 EEQ↓  —— E（围猎）→ E（凶噬）→ Q（声骸）→ 延奏嘉贝莉娜。
    """

    TAG = 'lupa'

    # ================================================================ 公共段
    #
    # 为什么不用框架的 switch_next_char():
    #   死顺序 + 它内部会补普攻 + 守岸人满协奏下场后 16 秒内会被判成 NO（这一圈她两次上场
    #   只隔 3 个节点）。直接按数字键切人绕开了这三条，代价是交接记账要自己补。
    SWITCH_TIMEOUT: float = 2.0
    SWITCH_KEY_INTERVAL: float = 0.12
    SWITCH_SETTLE: float = 0.06
    HANDOFF_CON_WAIT: float = 0.8
    HANDOFF_CON_POLL: float = 0.1
    CON_QUICK_WAIT: float = 0.08
    CON_CONFIRM_WAIT: float = 0.12
    HOLD_POLL: float = 0.1
    FILL_CON_INTERVAL: float = 0.20
    TEAM_HUD_WAIT: float = 3.0
    SWITCH_ANCHOR_MAX: float = 1.5
    INTRO_PENDING_TTL: float = 8.0
    LEAVE_TRIES: int = 2
    GATE_LOG_EVERY: float = 3.0
    TAP_DOWN: float = 0.06
    # 她可能在开场就被框架自然调进来（编队顺序不同）。那时从循环第一棒开始打
    OPENER_MODE: str = 's1'
    FAST_INTRO_MODES: tuple = ()
    FAST_INTRO_ANIM: float = 0.40

    intro_pending = False
    intro_pending_at = 0.0
    switch_confirmed_at = 0.0
    handoff_source = None
    handoff_source_at = 0.0
    _exit_fill = 0.0
    _con_full_confirmed = False
    _skip_con_check = False
    _force_switch_me = False
    _entry_mode = None
    _node = None
    started = False
    _startup_done = False
    _axis_char = True
    # R 真正发键的时刻：破敌要按「R 起手 + 201F」算，不能用 HUD 回来的时刻
    _r_press_at = 0.0

    def note_handoff_source(self, source):
        self.handoff_source = source.__class__.__name__ if source is not None else None
        self.handoff_source_at = time.time()

    def take_handoff_source(self):
        name = self.handoff_source
        if name is not None and time.time() - self.handoff_source_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: handoff_source ({name}) 已过期, 按未知处理')
            name = None
        self.handoff_source = None
        self.handoff_source_at = 0.0
        return name

    def note_intro_handoff(self):
        self.intro_pending = True
        self.intro_pending_at = time.time()

    def take_intro(self):
        pending = self.intro_pending
        if pending and time.time() - self.intro_pending_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: intro_pending 已过期, 按空手入场处理')
            pending = False
        self.intro_pending = False
        self.intro_pending_at = 0.0
        return self.has_intro or pending

    def reset_fixed_rotation(self, chars=None):
        for char in (chars if chars is not None else [self]):
            if char is None:
                continue
            char.intro_pending = False
            char.intro_pending_at = 0.0
            char.handoff_source = None
            char.handoff_source_at = 0.0

    # ---------------------------------------------------------------- 切人
    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        HUD 黑屏（大招/击破/换波）时补按一次就等，HUD 回来再核对 index。
        """
        start = time.time()
        blind_total = 0.0
        blind_pressed = False
        while True:
            in_team, current_index, _ = self.task.in_team()
            if in_team:
                blind_pressed = False
                if current_index == index:
                    # 先记时间戳再站稳：锚点晚 SWITCH_SETTLE 会让入场等待整体推迟
                    self.switch_confirmed_at = time.time()
                    self.settle_after_switch(self.SWITCH_SETTLE)
                    return True
                if time.time() - start - blind_total >= self.SWITCH_TIMEOUT:
                    return False
                self.task.send_key(index + 1)
            else:
                blind_total += self.SWITCH_KEY_INTERVAL
                if blind_total >= self.TEAM_HUD_WAIT:
                    return False
                if not blind_pressed:
                    self.task.send_key(index + 1)
                    blind_pressed = True
            self.task.next_frame()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)

    def settle_after_switch(self, duration):
        self.sleep(max(0.0, duration), check_combat=False)

    def handoff_to(self, target, has_intro):
        """复刻 switch_next_char() 内部那套记账（绕开框架切人后必须自己补）。"""
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if hasattr(target, 'note_handoff_source'):
            target.note_handoff_source(self)
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self, timeout=None):
        timeout = self.HANDOFF_CON_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.is_con_full():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.is_con_full():
                    return True
            else:
                self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        return False

    def char_at_slot(self, slot):
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def wait_team_hud(self, timeout=None):
        timeout = self.TEAM_HUD_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.task.in_team()[0]:
                return True
            self.task.next_frame()
            self.sleep(0.08, check_combat=False)
        self.logger.warning(f'{self.TAG}: 队伍 HUD {timeout:.1f}s 还没回来')
        return False

    def switch_in_anchor(self):
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now

    # ---------------------------------------------------------------- 强切协议
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """只给框架兜底路径用。压掉内置那条「还在大招里就抢人」的 MUST。"""
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return SwitchPriority.NORMAL

    def _find_teammate(self, class_name):
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _exit_intro(self):
        """离场前定「下一个人带不带变奏」。必须先读协奏, 再按切人键。"""
        if self._skip_con_check:
            self._skip_con_check = False
            self._exit_fill = 0.0
            return False
        fill = self._exit_fill
        self._exit_fill = 0.0
        if self._con_full_confirmed:
            self._con_full_confirmed = False
            return True
        if fill <= 0:
            return self.wait_con_full(self.CON_QUICK_WAIT)
        if self.wait_con_full(self.CON_QUICK_WAIT):
            return True
        self.logger.info(f'{self.TAG}: 协奏没满, 离场前补普攻 (上限 {fill:.1f}s)')
        start = time.time()
        filled_full = False
        while self.time_elapsed_accounting_for_freeze(start) < fill:
            if self.is_con_full():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.is_con_full():
                    filled_full = True
                    break
            self.check_combat()
            self.tap()
            self.sleep(self.FILL_CON_INTERVAL)
        has_intro = filled_full or self.wait_con_full(self.CON_QUICK_WAIT)
        if not has_intro:
            self.logger.info(f'{self.TAG}: 交接时协奏没满, 下一个人按平切入场')
        return has_intro

    def _direct_switch(self, target, has_intro):
        """按数字键直接切过去 + 自己补交接记账。失败返回 False 交给框架兜底。"""
        for attempt in range(1, self.LEAVE_TRIES + 1):
            self.wait_team_hud()
            if self.switch_to_index(target.index):
                self.handoff_to(target, has_intro)
                self.logger.info(f'{self.TAG}: 交接 {target.__class__.__name__} '
                                 f'(intro={has_intro}, 第 {attempt} 次)')
                return True
            has_intro = has_intro or self.wait_con_full()
            self.logger.warning(f'{self.TAG}: 直切失败 (第 {attempt}/{self.LEAVE_TRIES} 次)')
        return False

    def _force_switch_to(self, target, mode):
        if target is None:
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            has_intro = self._exit_intro()
            if self._direct_switch(target, has_intro):
                return True
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=direct_switch_failed')
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    # ---------------------------------------------------------------- 分发器
    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        entry = 'natural' if mode is None else 'forced'
        if mode is None:
            if not self.started:
                mode = self.OPENER_MODE
            elif self._startup_done:
                mode = 's1'
            else:
                self.logger.info(f'{self.TAG}: 启动轴进行中被自然入场, 交还框架切人')
                return self.switch_next_char()
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, 'perform_' + mode, None)
        if func is None:
            self.logger.info(f'{self.TAG}: interrupt reason=unknown_mode mode={mode} next=framework')
            return self.switch_next_char()
        self._node = mode
        self.check_f_on_switch = False
        source = self.take_handoff_source()
        intro = self.take_intro()
        anchor = self.switch_in_anchor()
        self.logger.info(f'{self.TAG}: [{mode.upper()}] enter (intro={intro}, '
                         f'mode={entry}, source={source})')
        if intro:
            intro_anim = self.INTRO_ANIM
            if mode in getattr(self, 'FAST_INTRO_MODES', ()):
                intro_anim = self.FAST_INTRO_ANIM
            self.sleep(max(0.0, anchor + intro_anim - time.time()), check_combat=False)
            # 强化变奏(141F) 会盖住 HUD 更久: 头像没回来就继续等, 上限 2.0s
            if not self.task.in_team()[0]:
                self.task.wait_until(lambda: self.task.in_team()[0], time_out=2.0, settle_time=0.1)
        if self.flying():
            self.sleep(0.30, check_combat=False)
            self.tap()
            self.sleep(0.20, check_combat=False)
        return func()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._exit_fill = 0.0
        self._con_full_confirmed = False
        self._skip_con_check = False
        self._reset_char_state()

    def on_combat_end(self, chars):
        self.reset_fixed_rotation(chars)
        super().on_combat_end(chars)

    # ---------------------------------------------------------------- 通用动作
    def tap(self, after_sleep=0.0):
        """短按普攻。task.click() 缺省时会把 down_time 压回 0.01（10ms 会被吞），
        所以按下/抬起自己发，按住 TAP_DOWN 秒。"""
        self.task.mouse_down()
        try:
            self.sleep(self.TAP_DOWN, check_combat=False)
        finally:
            self.task.mouse_up()
        if after_sleep:
            self.sleep(after_sleep)

    def attack_chain(self, count, interval, last_interval=None):
        for i in range(count):
            self.tap()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def dodge(self):
        self.task.click(key='right')

    def fire_liberation(self, window=None):
        """R —— 在窗口里等图标亮了再按。变奏入场 60F 里按的键会被丢, 所以从到场一直按。"""
        self.task.in_liberation = False
        window = self.LIB_WINDOW if window is None else window
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < window:
            self.task.next_frame()
            if self.liberation_available():
                waited = self.time_elapsed_accounting_for_freeze(start)
                self._r_press_at = time.time()
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    self.logger.info(f'{self.TAG}: 大招放出 (等了 {waited:.2f}s)')
                    return True
            self.check_combat()
            self.tap()
            self.sleep(self.LIB_RETRY)
        self.logger.warning(f'{self.TAG}: 大招图标 {window:.1f}s 内没亮, 硬按一次')
        return bool(self.click_liberation(wait_if_cd_ready=0.5, click_f=False))

    def fire_echo(self):
        if self.ECHO_TRIES <= 0:
            return False
        was_available = self.echo_available()
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if not was_available:
                return False
            if not self.echo_available():
                if i:
                    self.logger.info(f'{self.TAG}: echo landed on try {i + 1}')
                return True
        self.logger.warning(f'{self.TAG}: echo still reads available after {self.ECHO_TRIES} tries')
        return False

    def cast_resonance(self):
        for attempt in range(self.E_RETRIES):
            self.check_combat()
            self.send_resonance_key()
            if self.task.wait_until(lambda: not self.resonance_available(),
                                    time_out=self.E_CAST_TIMEOUT):
                self.record_resonance_use()
                return True
            if attempt + 1 < self.E_RETRIES:
                self.logger.warning(f'{self.TAG}: E 第 {attempt + 1} 次没进冷却, 补普攻后重发')
                self.tap()
                self.sleep(0.25)
        self.logger.warning(f'{self.TAG}: E 两次都没进冷却, 跳过')
        return False

    # ================================================================ 露帕这一棒
    #
    # 轴原文：循环「露 REAAA」「露 AE」「露 EEQ↓」（视频 0:04 轴表）。
    #
    # 帧表依据（Lupa，数据版本 3.7.13）：
    #   · 大招：第 201F 前不响应输入、第 120F 解锁 E3-破敌（持续 4 秒）、隐藏 HUD 132F。
    #   · E3-破敌：第 1F 获得 12 秒沸腾状态、清空狼焰、升空，协奏 +20。
    #   · E1-围猎 第 29F 给 15 点狼焰并挂 8 秒标记，8 秒内 E2-凶噬 会给 15 点 + 协奏 4.17。
    #   · 强化 E（狼舞的决意·极）要 2 格狼魂；本轴不用它，见到狼魂图标也不当它是强化 E。
    INTRO_ANIM = 1.00        # 普通 QTE 60F 不响应输入（强化变奏 141F 见 do_perform 里补的等 HUD）
    R_WINDOW = 3.50          # 变奏进来先按 R：入场动作期间按的键会被丢，一直按到图标亮
    R_AFTER_SLEEP = 0.25     # R 演出（HUD 回来）之后先站一下再破敌
    POD_MIN = 3.35           # 从 R 起手算：第 201F 才响应输入
    POD_CAP = 6.00           # 从 R 起手算：破敌窗口到第 360F
    POD_POLL = 0.10
    POD_CONFIRM = 2          # 狼焰条从满到空连读 2 帧 = 破敌生效
    Q_CAP = 0.90
    AIR_A_EVERY = 0.50       # 相邻空中 A 之间原有松键等待
    REAAA_HANDOFF_ADVANCE = 0.15  # 【调时】提前多少秒检查狼魂，确认焰袭起手才提前切嘉贝
    AIR_A_TRIES = 4          # 最多点几下；狼魂亮（焰袭起手）就提前切
    POD_TO_AIR = 0.60        # 破敌判定在 E3 第 48F 就报出来，等投枪动作收尾（v1.3.0 的 0.9s 偏长，用户要求缩短）
    E_INTERVAL = 0.85        # 围猎 -> 凶噬 的间隔（E2 在 8 秒内都能接, 0.85s 足够动作过完）
    # v1.6.0（从 1.5.0 起改）：
    EE_INTERVAL = 0.50       # EEQ 里两下 E 的间隔（原来 0.85，用户要求缩短）
    EE_Q_GAP = 0.20          # 第二下 E 到 Q 的间隔（原来 0.55）
    EE_PRESSES = 7           # AE 里强化E 最多连按几次（按出来就停）
    EE_RETRY = 0.1          # 强化E 连按之间等多久，然后再看狼魂图标灭没灭
    E_CAST_TIMEOUT = 0.9
    E_RETRIES = 2
    ECHO_TRIES = 2
    ECHO_RETRY = 0.08
    LIB_WINDOW = 3.50
    LIB_RETRY = 0.15
    WOLF_THRESHOLD = 0.85

    def _reset_char_state(self):
        # 内置 Lupa 的字段: 换类时会被内置实例的值打回, 这里重申
        self.check_f_on_switch = False
        self.wolf = False

    def skip_combat_check(self):
        return self.has_intro or self.flying()

    def still_in_liberation(self):
        """内置版用它抢切人; 本队走死顺序, 这里只留给日志/兜底。"""
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 12

    # ------------------------------------------------------------------ 节点
    def perform_s1(self):
        self._action_open('s1', 'Galbrena.s1')
        self._force_switch_to(self._find_teammate('Galbrena'), 's1')

    def perform_s2(self):
        self._action_enhanced_a_e('s2', 'ShoreKeeper.s1')
        self._force_switch_to(self._find_teammate('ShoreKeeper'), 's1')

    def perform_s3(self):
        self._action_eeq('s3', 'Galbrena.s3')
        self._force_switch_to(self._find_teammate('Galbrena'), 's3')

    # ------------------------------------------------------------------ 动作体
    def _action_open(self, tag, nxt):
        """露 REAAA：R → 破敌（沸腾、升空）→ 空中 A1 A2 A3（焰袭）。

        【为什么要等到 R 之后 3.3s 才破敌】大招第 201F（3.35s）前不响应输入，
        HUD 在 132F（2.2s）就回来了，早按的 E 会被直接丢掉。
        """
        fired = self.fire_liberation(window=self.R_WINDOW)
        podi = False
        if fired:
            self.sleep(self.R_AFTER_SLEEP, check_combat=False)
            podi = self.break_enemy()
            self.a3_handoff(tag)
        else:
            # 没放出 R = 没破敌、没沸腾：只点几下普攻，别把整圈卡死
            self.logger.warning(f'{self.TAG}: [{tag.upper()}] R 没放出来, 跳过破敌')
            self.a3_handoff(tag)
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={fired and podi} '
                         f'reason=done next={nxt}')

    def _action_enhanced_a_e(self, tag, nxt):
        """露 AE：1 下强化普攻（锐爪）+ E（强化E）。

        用户 2026-11-24：强化E 有时按不出来 —— 所以这里**连按几次**，但带一个停止条件：
        强化E 一旦出手就会吃掉两颗狼魂（`lupa_wolf_icon2` 熄灭），看到熄灭就停；
        否则每 0.25s 再补一发，最多 3 发。
        """
        self.attack_chain(1, self.AIR_A_EVERY)
        if self.wolf_ready():
            self.logger.info(f'{self.TAG}: [{tag.upper()}] 两颗狼魂就绪, E 是强化E')
        presses = 0
        for _ in range(self.EE_PRESSES):
            self.press_e(wait=self.EE_RETRY)
            presses += 1
            if not self.wolf_ready():
                # 图标灭了 = 强化E 已经出手（狼魂被吃掉了）
                break
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok reason=done next={nxt} '
                         f'e_presses={presses}')

    def _action_eeq(self, tag, nxt):
        """露 EEQ↓：围猎 → 凶噬 → 声骸，然后延奏嘉贝莉娜。

        用户 2026-11-24：这一段要更快 —— 两下 E 的间隔从 0.85 压到 EE_INTERVAL，
        第二下到 Q 的间隔从 0.55 压到 EE_Q_GAP。
        """
        wolf = self.wolf_ready()
        self.press_e(wait=self.EE_INTERVAL)
        self.press_e(wait=self.EE_Q_GAP)
        self.fire_echo()
        # 轴里这一棒是↓（延奏）。协奏没满时补 1.0s 普攻（原轴没写补齐，见 notes I5）
        self._exit_fill = 1.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok reason=done next={nxt} '
                         f'wolf_icon={wolf}')

    # ------------------------------------------------------------------ 动作
    def press_e(self, wait=0.75):
        """E 发一次键就算出手 —— 不等冷却。

        露帕的 E1-围猎不进冷却（8 秒内接 E2-凶噬，只有 E2 进 10.6 秒冷却），
        用 v1.0.0 的 cast_resonance（等 not resonance_available）会：
        第一下按完白等 0.9s → 补一发 → 再等 0.9s，s2/s3 一共白烧 4-5s，
        用户看到的就是「EEQ 那段有发呆停顿」（2026-11-24 18:33 那局日志两次
        `wait_until timeout Lupa.cast_resonance`）。
        多段技能只按一次、按派生帧等，这是 rules 5-3 点名的例外。
        """
        self.check_combat()
        self.send_resonance_key()
        self.record_resonance_use()
        self.sleep(wait, check_combat=False)

    def wolf1_lit(self):
        """第一颗狼魂的图标亮没亮（框架自带模板 lupa_wolf_icon1）。"""
        try:
            return bool(self.task.find_one('lupa_wolf_icon1', threshold=self.WOLF_THRESHOLD))
        except Exception:
            return False

    def wolf_ready(self):
        """E 图标是不是「两个狼魂」（强化E 就绪）。只读当前帧。"""
        try:
            return bool(self.task.find_one('lupa_wolf_icon2', threshold=self.WOLF_THRESHOLD))
        except Exception:
            return False

    def a3_handoff(self, tag):
        """三下空中 A（A1 → A2 → A3 焰袭），看到第一颗狼魂就切嘉贝。

        视频 0:18 文案：「露帕空中A3(焰袭)前摇出来切嘉贝 AA」。
        帧表：空中 A1 派生帧 24F（0.40s）、空中 A3-强化下落 第 7F 获得 1 点狼魂，
        所以「第一颗狼魂亮起」就是焰袭起手最可靠的画面判据（框架自带 lupa_wolf_icon1）。

        【v1.3.0 修】2026-11-24 18:27 那局实测：破敌报出来的时刻（狼焰条清空，E3 第 48F）
        破敌的投枪动作还要演 1 秒（E3 动作结束 109F），这期间点的 A 全被吞 ——
        三下只出一两下，用户看到的就是「只 A 了一下」。
        所以先等 POD_TO_AIR（0.9s），再「点一下 → 等 0.5s → 看狼魂」，最多 AIR_A_TRIES 下；
        狼魂一亮立刻切（这就是焰袭前摇）。
        """
        self.sleep(self.POD_TO_AIR, check_combat=False)
        was_lit = self.wolf1_lit()
        taps = 0
        advance = min(self.AIR_A_EVERY, max(0.0, self.REAAA_HANDOFF_ADVANCE))
        while taps < self.AIR_A_TRIES:
            self.tap()
            taps += 1
            if advance > 0 and not was_lit:
                early_wait = self.AIR_A_EVERY - advance
                if early_wait > 0:
                    self.sleep(early_wait, check_combat=False)
                if self.wolf1_lit():
                    break
                self.sleep(advance, check_combat=False)
            else:
                self.sleep(self.AIR_A_EVERY, check_combat=False)
            if not was_lit and self.wolf1_lit():
                break
        else:
            self.logger.info(f'{self.TAG}: [{tag.upper()}] 打了 {taps} 下空中 A 没等到狼魂图标, 直接切')
            return
        self.logger.info(f'{self.TAG}: [{tag.upper()}] 第 {taps} 下之后狼魂亮(焰袭起手), 切嘉贝')

    def break_enemy(self):
        """破敌：R 起手 +3.35s 发 E（第 201F 之后才响应输入）；没生效就点普攻，
        直到狼焰条从满清空（连读 2 帧）。

        狼焰条 = is_forte_full()。破敌第 1F 清空狼焰，这是唯一可靠的判据
        （E 图标变灰但没有冷却数字，框架会当成可用）。大招本身给 100 点狼焰，
        所以 R 演完条一定是满的（嘉露莫 10-16 实机）。
        """
        r_at = self._r_press_at or time.time()
        podi_at = r_at + self.POD_MIN
        seen_full = False
        gone = 0
        pressed_e = False
        while time.time() - r_at < self.POD_CAP:
            now = time.time()
            if now >= podi_at and not pressed_e:
                self.send_resonance_key()
                self.record_resonance_use()
                pressed_e = True
            if now < podi_at:
                self.sleep(self.POD_POLL, check_combat=False)
                self.task.next_frame()
                continue
            self.tap()
            self.task.next_frame()
            if self.is_forte_full():
                seen_full = True
                gone = 0
            elif seen_full:
                gone += 1
                if gone >= self.POD_CONFIRM:
                    self.logger.info(f'{self.TAG}: 破敌 ok ({time.time() - r_at:.2f}s)')
                    return True
            self.sleep(self.POD_POLL)
        self.logger.warning(f'{self.TAG}: 破敌 {self.POD_CAP:.1f}s 内没等到狼焰清空')
        return False
