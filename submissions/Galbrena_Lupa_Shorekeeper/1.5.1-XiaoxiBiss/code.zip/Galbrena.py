import time

from src.char.BaseChar import SwitchPriority
from src.char.Galbrena import Galbrena as NativeGalbrena


class Galbrena(NativeGalbrena):
    """嘉贝莉娜 —— 嘉露守（嘉贝莉娜 / 露帕 / 守岸人）25 秒轮椅轴里的一棒。

    轴出处：用户提供的教学视频《嘉露守25秒轮椅_进阶轴实战教学》0–115 秒的「轮椅轴」
    画面轴表（见 ../media/info.md、../skilltest-v1/timeline.json），加上用户给的
    《细节.txt》。三个文件的公共段由同一份骨架生成，改一处记得同步三处。

    本角色在轴里的四棒：
      f1  嘉 ZZZ       —— 守岸人交过来（平切）。一顿长按把重击 1~3 段打完。
      s1  嘉 AA        —— 露帕空中 A3（焰袭）前摇切出来，补两下普攻。
      s2  嘉 AA        —— 守岸人 AAAQ 之后，继续补普攻（回路罪火）。
      s3  嘉 QER + 强化连段 + ZZZ↓ —— 露帕延奏进来（变奏）：Q → 强化E(恶翼扬升) →
          R（14 秒强化状态）→ AAAA闪AAA闪A → 长按 3 段重击 → 延奏守岸人。

    和轴的对应关系：「JE」= 恶魔位格里普攻变强化普攻（帧表 ID 10–15），
    「闪」= 滑步（任意攻击后短按闪避，固定 666，不断连段），「ZZZ」= 一顿长按出 3 段重击。
    """

    TAG = 'galbrena'

    # ================================================================ 公共段
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴是死顺序;
    #   2. 它内部有三处补普攻 (performing too fast / 维持锁定 / 切人没认到时补点击),
    #      打完最后一下想立刻走人时那几下 A 会把节奏拖乱;
    #   3. 守岸人满协奏下场后 16 秒内会被框架判成 NO, 而这一圈里她两次上场只隔 3 个节点
    #      —— 直接按数字键切人绕开了这条锁。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。
    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    SWITCH_SETTLE: float = 0.06        # 切到之后等角色站稳 (秒)
    HANDOFF_CON_WAIT: float = 0.8      # 补刀后等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    CON_QUICK_WAIT: float = 0.08       # 平切前的读数确认; 不为「可能刚好满」空等 0.8s
    CON_FULL_SOFT: float = 0.985       # 0.99 哨兵也算满（见 con_now）
    CON_CONFIRM_WAIT: float = 0.12     # 满协奏要连读两次: 0.99/1.04 那种读数会抖
    HOLD_POLL: float = 0.1
    FILL_CON_INTERVAL: float = 0.20
    TEAM_HUD_WAIT: float = 3.0         # 大招/击破演出期间队伍 HUD 整块不画, 盲区最多等这么久
    SWITCH_ANCHOR_MAX: float = 1.5
    INTRO_PENDING_TTL: float = 8.0
    LEAVE_TRIES: int = 2
    GATE_LOG_EVERY: float = 3.0
    TAP_DOWN: float = 0.06             # 普攻按住时长: 框架 click() 只按 10ms, 会被吞
    # 本角色作为「开场自然入场」时跑哪个节点。默认 f1
    OPENER_MODE: str = 'f1'
    # 首动作是「轮询等提示」的节点, 入场不用睡满 INTRO_ANIM, 提前轮询即可
    FAST_INTRO_MODES: tuple = ()
    FAST_INTRO_ANIM: float = 0.40

    # ---- 交接状态（写成类属性: CharFactory 换类时只覆盖「内置实例也有」的字段）
    intro_pending = False
    intro_pending_at = 0.0
    # 切人【真正完成】那一刻, 作用: 给下一个角色的入场等待当锚点
    switch_confirmed_at = 0.0
    handoff_source = None
    handoff_source_at = 0.0
    _exit_fill = 0.0
    _con_full_confirmed = False
    _skip_con_check = False
    _force_switch_me = False
    _entry_mode = None
    _node = None
    started = False
    _startup_done = False
    _axis_char = True
    # 守岸人开场把「按住重击」交过来（视频 0:00：守岸人重击按住不松，切嘉贝自动打完 3Z）
    _handoff_hold = False
    _own_heavy_done = False

    def note_handoff_source(self, source):
        """被 handoff_to() 交接进场时调用 —— 记下上一棒是谁。带不带变奏都记。"""
        self.handoff_source = source.__class__.__name__ if source is not None else None
        self.handoff_source_at = time.time()

    def take_handoff_source(self):
        name = self.handoff_source
        if name is not None and time.time() - self.handoff_source_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: handoff_source ({name}) 已过期, 按未知处理')
            name = None
        self.handoff_source = None
        self.handoff_source_at = 0.0
        return name

    def note_intro_handoff(self):
        """被别人用直接切人的方式交接进场时调用 —— 记下「我是带着变奏上来的」。"""
        self.intro_pending = True
        self.intro_pending_at = time.time()

    def take_intro(self):
        """本次入场是否带着变奏。读完就清, 避免下一轮误判。"""
        pending = self.intro_pending
        if pending and time.time() - self.intro_pending_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: intro_pending 已过期, 按空手入场处理')
            pending = False
        self.intro_pending = False
        self.intro_pending_at = 0.0
        return self.has_intro or pending

    def reset_fixed_rotation(self, chars=None):
        """战斗结束时清全队的交接标记 (combat_end 只对当前角色调 on_combat_end)。"""
        for char in (chars if chars is not None else [self]):
            if char is None:
                continue
            char.intro_pending = False
            char.intro_pending_at = 0.0
            char.handoff_source = None
            char.handoff_source_at = 0.0

    # ---------------------------------------------------------------- 切人
    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        【HUD 看不见时只补按一次】演出期间队伍 HUD 整块不渲染, in_team 只回 False；
        盲区里补按一次就等，HUD 回来再核对 index（等的是演出本身，用户 2026-11-24 确认）。
        """
        start = time.time()
        blind_total = 0.0
        blind_pressed = False
        while True:
            in_team, current_index, _ = self.task.in_team()
            if in_team:
                blind_pressed = False
                if current_index == index:
                    # 先记时间戳再站稳：锚点晚 SWITCH_SETTLE 会让入场等待整体推迟
                    self.switch_confirmed_at = time.time()
                    self.settle_after_switch(self.SWITCH_SETTLE)
                    return True
                if time.time() - start - blind_total >= self.SWITCH_TIMEOUT:
                    return False
                self.task.send_key(index + 1)
            else:
                blind_total += self.SWITCH_KEY_INTERVAL
                if blind_total >= self.TEAM_HUD_WAIT:
                    return False
                if not blind_pressed:
                    self.task.send_key(index + 1)
                    blind_pressed = True
            self.task.next_frame()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)

    def settle_after_switch(self, duration):
        """切人确认之后等角色站稳。

        【这里不点普攻】: 这一套每个节点的起手动作都要数得清, 切人期间多点的 A
        会被算进连段里, 让段数漂掉。
        """
        self.sleep(max(0.0, duration), check_combat=False)

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if hasattr(target, 'note_handoff_source'):
            target.note_handoff_source(self)
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def con_now(self):
        """协奏是否算满（把 0.99 哨兵算进去）。

        【为什么需要】框架在「协奏环面积已经超过满环、但轮廓没闭合」时，会把读数夹成 0.99
        并让 is_con_full() 回 False（日志原话 is_con_full not full but percent greater than 1,
        set to 0.99, 1.047）。这时游戏其实已经满协奏、可以延奏了：
        我们按「没满」交接，游戏却演了延奏/QTE，下一棒在 QTE 里按的键全被吞。
        2026-11-24 18:55 那局守岸人两次 ↓ 的读数都是 0.9900（面积 1.04/1.05），就是这个情况。
        """
        try:
            value = self.get_current_con()
        except Exception:
            return self.is_con_full()
        if value is None:
            return self.is_con_full()
        return value >= self.CON_FULL_SOFT

    def wait_con_full(self, timeout=None):
        """短暂轮询协奏是否满 —— 决定交接时给不给对方变奏。

        不能只读一次: 打完最后一下那一刻协奏其实已经满了, 但能量环读数滞后,
        1.00–1.04 还会被夹成 0.99、is_con_full 时真时假。所以满要连读两次。
        """
        timeout = self.HANDOFF_CON_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.con_now():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.con_now():
                    return True
            else:
                self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def wait_team_hud(self, timeout=None):
        """等右侧队伍头像渲染回来 —— 演出期间它整块是不画的。"""
        timeout = self.TEAM_HUD_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.task.in_team()[0]:
                return True
            self.task.next_frame()
            self.sleep(0.08, check_combat=False)
        self.logger.warning(f'{self.TAG}: 队伍 HUD {timeout:.1f}s 还没回来')
        return False

    def switch_in_anchor(self):
        """本轮的计时基准: 头像认出「切人完成」的那一刻, 不是 do_perform 被调那一刻。"""
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now

    # ---------------------------------------------------------------- 强切协议
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """只给框架兜底路径用: 被标记的人 MUST, 其他人 NO, 否则 NORMAL。"""
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return SwitchPriority.NORMAL

    def _find_teammate(self, class_name):
        """按类名找队友 —— 工坊类各自独立加载, isinstance 对 src.char.* 不成立。"""
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _exit_intro(self):
        """离场前定「下一个人带不带变奏」。必须先读协奏, 再按切人键。"""
        if self._skip_con_check:
            self._skip_con_check = False
            self._exit_fill = 0.0
            return False
        fill = self._exit_fill
        self._exit_fill = 0.0
        if self._con_full_confirmed:
            self._con_full_confirmed = False
            return True
        if fill <= 0:
            return self.wait_con_full(self.CON_QUICK_WAIT)
        if self.wait_con_full(self.CON_QUICK_WAIT):
            return True
        self.logger.info(f'{self.TAG}: 协奏没满, 离场前补普攻 (上限 {fill:.1f}s)')
        start = time.time()
        filled_full = False
        while self.time_elapsed_accounting_for_freeze(start) < fill:
            if self.con_now():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.con_now():
                    filled_full = True
                    break
            self.check_combat()
            self.tap()
            self.sleep(self.FILL_CON_INTERVAL)
        has_intro = filled_full or self.wait_con_full(self.CON_QUICK_WAIT)
        if not has_intro:
            self.logger.info(f'{self.TAG}: 交接时协奏没满, 下一个人按平切入场')
        return has_intro

    def _direct_switch(self, target, has_intro):
        """按数字键直接切过去 + 自己补交接记账。失败返回 False 交给框架兜底。

        HUD 黑屏那一段（守岸人变奏动画/大招收尾）本来就该等 —— 用户 2026-11-24 确认
        「那 3.5s 是正常的等变奏动画」，所以保留先 wait_team_hud()。
        """
        for attempt in range(1, self.LEAVE_TRIES + 1):
            self.wait_team_hud()
            if self.switch_to_index(target.index):
                self.handoff_to(target, has_intro)
                self.logger.info(f'{self.TAG}: 交接 {target.__class__.__name__} '
                                 f'(intro={has_intro}, 第 {attempt} 次)')
                return True
            has_intro = has_intro or self.wait_con_full()
            self.logger.warning(f'{self.TAG}: 直切失败 (第 {attempt}/{self.LEAVE_TRIES} 次)')
        return False

    def _force_switch_to(self, target, mode):
        """把棒交给 target 并让它跑 perform_<mode>。"""
        if target is None:
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            has_intro = self._exit_intro()
            if self._direct_switch(target, has_intro):
                return True
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=direct_switch_failed')
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    # ---------------------------------------------------------------- 分发器
    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        entry = 'natural' if mode is None else 'forced'
        if mode is None:
            if not self.started:
                mode = self.OPENER_MODE
            elif self._startup_done:
                mode = 's1'
            else:
                self.logger.info(f'{self.TAG}: 启动轴进行中被自然入场, 交还框架切人')
                return self.switch_next_char()
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, 'perform_' + mode, None)
        if func is None:
            self.logger.info(f'{self.TAG}: interrupt reason=unknown_mode mode={mode} next=framework')
            return self.switch_next_char()
        self._node = mode
        self.check_f_on_switch = False
        # 【跨角色预输入】守岸人把「按住左键」交过来了：接着按住把 3Z 打完，再松手
        self._own_heavy_done = False
        if self._handoff_hold:
            self._release_handoff_hold()
            self._own_heavy_done = True
        source = self.take_handoff_source()
        intro = self.take_intro()
        anchor = self.switch_in_anchor()
        self.logger.info(f'{self.TAG}: [{mode.upper()}] enter (intro={intro}, '
                         f'mode={entry}, source={source})')
        if intro:
            # 用【切人确认那一刻】当基准: 中间隔着交接记账和任务循环, 那段延迟是变长的
            intro_anim = self.INTRO_ANIM
            if mode in getattr(self, 'FAST_INTRO_MODES', ()):
                intro_anim = self.FAST_INTRO_ANIM
            self.sleep(max(0.0, anchor + intro_anim - time.time()), check_combat=False)
        if self.flying():
            # wait_down 会空耗 2.5s, 而且 flying() 在地面也会误判; 只给短落地
            self.sleep(0.30, check_combat=False)
            self.tap()
            self.sleep(0.20, check_combat=False)
        return func()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._exit_fill = 0.0
        self._con_full_confirmed = False
        self._skip_con_check = False
        if self._handoff_hold:
            self._handoff_hold = False
            self.task.mouse_up()
        self._own_heavy_done = False
        self._reset_char_state()

    def on_combat_end(self, chars):
        self.reset_fixed_rotation(chars)
        super().on_combat_end(chars)

    # ---------------------------------------------------------------- 通用动作
    def tap(self, after_sleep=0.0):
        """短按普攻。

        【不能传 down_time】task.click() 在 x/y 缺省时会把 down_time 强制改回 0.01，
        而 10ms 的普攻在特效糊屏时会被游戏吞掉（嘉露莫 10-16 实机）。所以按下/抬起
        自己发，按住 TAP_DOWN 秒。按住期间不发别的键（5-4）。
        """
        self.task.mouse_down()
        try:
            self.sleep(self.TAP_DOWN, check_combat=False)
        finally:
            self.task.mouse_up()
        if after_sleep:
            self.sleep(after_sleep)

    def attack_chain(self, count, interval, last_interval=None):
        """点按普攻打一轮连段。last_interval 给最后一段之后的间隔。"""
        for i in range(count):
            self.tap()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def dodge(self):
        """闪避 = 右键。注意 "Dodge Key" 配置项是疾跑键, 不是战斗闪避。"""
        self.task.click(key='right')

    def fire_liberation(self, window=None):
        """R 大招 —— 在窗口里等图标亮了再按, 不是问一次就走。

        click_liberation() 只在「图标当下就亮着」时才真发键; 刚放完前一个动作时
        能量环那几帧最不可信。顺手清 task.in_liberation。
        click_f=False: 演出期间框架默认每 0.1 秒发一次 F, 这条轴上没有要她按的处决。
        """
        self.task.in_liberation = False
        window = self.LIB_WINDOW if window is None else window
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < window:
            self.task.next_frame()
            if self.liberation_available():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    self.logger.info(f'{self.TAG}: 大招放出 (等了 {waited:.2f}s)')
                    return True
            self.check_combat()
            if window > 1.5:
                self.tap()
            self.sleep(self.LIB_RETRY)
        self.logger.warning(f'{self.TAG}: 大招图标 {window:.1f}s 内没亮, 硬按一次')
        return bool(self.click_liberation(wait_if_cd_ready=0.5, click_f=False))

    def fire_echo(self):
        """Q 声骸 —— 连发, 不是只发一次。

        演出期间的按键被游戏丢弃、不排队, 只发一次很容易整段被吃掉; Q 是脱手技能,
        多按几下不会打断当前动作。
        """
        if self.ECHO_TRIES <= 0:
            return False
        was_available = self.echo_available()
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if not was_available:
                return False
            if not self.echo_available():
                if i:
                    self.logger.info(f'{self.TAG}: echo landed on try {i + 1}')
                return True
        self.logger.warning(f'{self.TAG}: echo still reads available after {self.ECHO_TRIES} tries')
        return False

    def cast_resonance(self):
        """E —— 发键后确认它真的进了冷却; 被受击打断就补一下普攻再重发。"""
        for attempt in range(self.E_RETRIES):
            self.check_combat()
            self.send_resonance_key()
            if self.task.wait_until(lambda: not self.resonance_available(),
                                    time_out=self.E_CAST_TIMEOUT):
                self.record_resonance_use()
                return True
            if attempt + 1 < self.E_RETRIES:
                self.logger.warning(f'{self.TAG}: E 第 {attempt + 1} 次没生效, 补普攻后重发')
                self.tap()
                self.sleep(0.25)
        self.logger.warning(f'{self.TAG}: E 两次都没进冷却, 跳过')
        return False

    # ================================================================ 嘉贝莉娜这一棒
    #
    # 轴原文（视频 0:04 起的轴表）：
    #   启动「嘉 ZZZ」  循环「嘉 AA」「嘉 AA」「嘉 QER / AAAA闪AAA闪A / ZZZ↓」
    #
    # 为什么重击是一顿长按而不是点三下（帧表 Galbrena 重击 1/2/3）：
    #   重击1 派生帧 29F、重击2 16F、重击3 45F 起手、子弹 75F 脱手，第 115F 才轮到下一轮重击1。
    #   所以按住时长只能落在 1.25 ~ 1.92s：短了第 3 段不出，长了自动接第二轮。
    #   1.40s 是嘉露莫 v1.1.0（楽山）在实机定下的值，本轮照用。
    INTRO_ANIM = 0.80        # QTE 44F 前按的 A/F/E 被丢掉、不排队
    A_INTERVAL = 0.35        # 轴里的「AA」两下之间的间隔（嘉仇守实机 0.35）
    HEAVY_HOLD = 1.40        # 一顿长按 = 重击 1~3 段
    HANDOFF_HOLD = 1.40      # 接过守岸人按住状态后，再按这么久松手（打完 3Z）
    END_HOLD = 1.70          # 爆发收尾那下按满（嘉仇守实机 1.70），多走一段子弹
    ECHO_TRIES = 2
    ECHO_RETRY = 0.08
    E_TO_R = 0.55            # 恶翼扬升派生 29F、动作结束 61F ⇒ 0.55s 后 R 不会吞 E3
    E_CAST_TIMEOUT = 0.9
    E_RETRIES = 2
    LIB_WINDOW = 3.0
    LIB_RETRY = 0.15
    FORTE_WAIT = 6.0         # 罪火没满时补普攻的上限（轴里没写补齐，见 notes.md I3）
    FORTE_POLL = 0.20
    FORTE_CONFIRM = 0.10     # 罪火满要连读 0.1s，躲开 boss 白闪的单帧误判
    E3_GONE_WAIT = 0.8       # 按 E3 后等 E 图标外圈灭掉
    E3_PRESSES = 3
    # ---- 爆发段（R 的 14 秒强化状态）----
    # 嘉露莫 v1.1.0 实机定标：第一脚 3.50s、第二脚再 3.56s、尾巴 0.92s，0.16s 一下普攻；
    # 对得上教学视频「4A踢+闪 / 3A踢+闪 / A3展翅」的节奏。
    BURST_A_INTERVAL = 0.16
    BURST_DODGE_1 = 3.50
    BURST_DODGE_2 = 3.56
    BURST_TAIL = 0.92
    BURST_PRE_DODGE = 0.10   # 闪避前这么久不再点，别让最后一下普攻跟闪避粘在一起
    LIB_TO_BURST = 0.10
    DODGE_TO_A = 0.12        # 闪完接普攻不能贴着发，会把闪避顶掉

    def _reset_char_state(self):
        # 【必须写在 reset_state 里, 光写 __init__ 保不住】: CharFactory 换类时是先建新
        # 实例再 replacement.__dict__.update(内置实例.__dict__), 凡是「内置也有、我改了值」
        # 的字段都会被静默打回内置值。
        # 她不是治疗, 内置值是 True; 不重申的话框架会在每次切人时替她按一下 F
        self.check_f_on_switch = False

    def skip_combat_check(self):
        """R 演出期间照样算在战斗里: 她的大招有 3 秒以上全屏动画, HUD 全隐。"""
        return self.has_intro or self.flying()

    # ------------------------------------------------------------------ 节点
    def perform_f1(self):
        self._action_heavy3('f1', 'ShoreKeeper.f2')
        self._force_switch_to(self._find_teammate('ShoreKeeper'), 'f2')

    def perform_s1(self):
        self._action_double_a('s1', 'Lupa.s2')
        self._force_switch_to(self._find_teammate('Lupa'), 's2')

    def perform_s2(self):
        self._action_double_a('s2', 'Lupa.s3')
        self._force_switch_to(self._find_teammate('Lupa'), 's3')

    def perform_s3(self):
        self._action_burst('s3', 'ShoreKeeper.s2')
        self._force_switch_to(self._find_teammate('ShoreKeeper'), 's2')

    # ------------------------------------------------------------------ 动作体
    def _action_heavy3(self, tag, nxt):
        """嘉 ZZZ：一顿长按打完重击 1~3 段。

        【跨角色预输入】如果这一棒是守岸人按住左键交过来的（开场），
        那按住已经算开始了，这里只补足时长再松手，不再重新按下 ——
        视频 0:00「守岸人重击按住不松，切嘉贝自动打完 3Z」。
        其余情况（没有交接）自己按 1.40s。
        """
        if self._own_heavy_done:
            self._own_heavy_done = False
            self.logger.info(f'{self.TAG}: [{tag.upper()}] 重击沿用守岸人的按住状态')
        else:
            self.heavy_attack(self.HEAVY_HOLD)
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok reason=done next={nxt}')

    def _release_handoff_hold(self):
        """接过守岸人的按住：继续按住，把重击 1~3 段连完再松手。"""
        if not self._handoff_hold:
            return
        self._handoff_hold = False
        try:
            self.sleep(self.HANDOFF_HOLD, check_combat=False)
        finally:
            self.task.mouse_up()
        self.logger.info(f'{self.TAG}: 接过守岸人的按住, 补 {self.HANDOFF_HOLD:.2f}s 后松手')

    def _action_double_a(self, tag, nxt):
        """嘉 AA：两下常态普攻，补回路罪火 / 余火窗口。

        这两棒都是平切进出，不需要协奏，也就不读协奏（省 0.15-0.3s/次）。
        """
        self.attack_chain(2, self.A_INTERVAL)
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok reason=done next={nxt}')

    def _action_burst(self, tag, nxt):
        """嘉 QER → 强化连段 → ZZZ↓：整条轴唯一一段「站满」的输出。

        细节.txt ④：E2R 连按太快会吞 E2 —— 所以 E3 确认出手后隔 E_TO_R 再放 R。
        细节.txt ⑥：净炼火打空后当前动作照常打完，所以收尾的长按不受能量影响。
        细节.txt ⑤：净炼火命中才消耗，滑步能快速衔接派生 = AAAA闪AAA闪A。
        """
        self.fire_echo()
        e3 = self.cast_enhanced_e()
        self.sleep(self.E_TO_R)
        r = self.fire_liberation()
        if r:
            self.sleep(self.LIB_TO_BURST)
            self.demon_burst(tag)
        self.heavy_attack(self.END_HOLD)
        # 轴里这一棒是↓（延奏守岸人）。R + 爆发一般已经把协奏打满，没满补 1.0s 普攻
        self._exit_fill = 1.0 if r else 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={e3 and r} '
                         f'reason=done next={nxt}')

    # ------------------------------------------------------------------ 动作
    def cast_enhanced_e(self):
        """强化 E（恶翼扬升）：罪火满才按，按早了出的是 E1、还把 E 打进冷却。

        判据用 is_forte_full()（回路条）或 is_e_forte_full()（E 图标外圈）取或，
        两个都连读 FORTE_CONFIRM 秒才算满 —— boss 白闪只有单帧，会把不满判成满。
        轴里没写「罪火不满怎么办」，这里补普攻到满（上限 FORTE_WAIT），失败就跳过 E3
        并打 warning，让 R 和爆发照常打（少一层恶魔位格，但不会卡死整圈）。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE_WAIT:
            if self.e3_ready():
                break
            self.check_combat()
            self.tap()
            self.sleep(self.FORTE_POLL)
        if not self.e3_ready():
            self.logger.warning(f'{self.TAG}: 罪火 {self.FORTE_WAIT:.1f}s 内没满, 跳过强化E')
            return False
        for attempt in range(self.E3_PRESSES):
            self.send_resonance_key()
            self.record_resonance_use()
            if self.task.wait_until(lambda: not self.is_e_forte_full(),
                                    time_out=self.E3_GONE_WAIT, settle_time=0.05):
                self.logger.info(f'{self.TAG}: 强化E 出手 (第 {attempt + 1} 次)')
                return True
        self.logger.warning(f'{self.TAG}: 强化E {self.E3_PRESSES} 次都没看到图标变化')
        return False

    def e3_ready(self):
        try:
            return bool(self.is_forte_full() or self.is_e_forte_full())
        except Exception:
            return False

    def demon_burst(self, tag):
        """恶魔位格连段：AAAA 闪 AAA 闪 A。

        点的密度和分组沿用嘉露莫 v1.1.0（楽山）实机定标值：0.16s 一下，
        第一组 3.50s（恶魔 A2~A5 一轮，A5 踢出就闪）、第二组 3.56s（A3~A5）、
        尾巴 0.92s（最后一段 A3 展翅）。闪避用右键，两段都在断后摇。
        """
        taps = self.tap_for(self.BURST_DODGE_1)
        self.dodge()
        self.sleep(self.DODGE_TO_A)
        taps += self.tap_for(self.BURST_DODGE_2)
        self.dodge()
        self.sleep(self.DODGE_TO_A)
        taps += self.tap_for(self.BURST_TAIL)
        self.logger.info(f'{self.TAG}: [{tag.upper()}] burst: ok taps={taps}')

    def tap_for(self, duration):
        """在一段时间里按 A 的节奏连点，最后 BURST_PRE_DODGE 秒留空给闪避。"""
        start = time.time()
        n = 0
        while True:
            if duration - (time.time() - start) <= self.BURST_PRE_DODGE:
                break
            self.check_combat()
            self.tap()
            n += 1
            self.sleep(self.BURST_A_INTERVAL)
        return n
