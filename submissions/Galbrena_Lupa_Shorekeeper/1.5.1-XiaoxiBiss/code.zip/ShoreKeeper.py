import time

from src.char.BaseChar import SwitchPriority
from src.char.ShoreKeeper import ShoreKeeper as NativeShoreKeeper


class ShoreKeeper(NativeShoreKeeper):
    """守岸人 —— 嘉露守（嘉贝莉娜 / 露帕 / 守岸人）25 秒轮椅轴的起手与循环收尾。

    轴出处：教学视频 0–115 秒的「轮椅轴」轴表 + 用户《细节.txt》。三份文件共用同一套
    公共段（见 Galbrena.py 顶部注释），改一处记得同步三处。

    本角色在轴里的四棒：
      f1  守 AAEAAZ   —— 开场（自然入场）：2A → E（回血 + 5 蝴蝶）→ 2A → 重击。
                          （视频轴表放大图 media/frames/open_axis2_00020.00.jpg：4 下 A）
      f2  守 AAAZRZ↓  —— 3A → 重击 → R（领域）→ 重击 → 延奏露帕。
      s1  守 AAAQ     —— 3A → Q（声骸覆盖嘉露二人的爆发期）。
      s2  守 EAAZRZ↓  —— E → 2A → 重击 → R → 重击 → 延奏露帕（循环闭合）。

    视频原话：「守岸人重击按住不松」「切回守岸人打满协奏，大招动画时预输入重击」——
    所以重击一律走「回路满了就按住到蝴蝶出来，没满就普通重击」，R 之后那下重击
    靠游戏输入缓存接上。
    """

    TAG = 'shorekeeper'

    # ================================================================ 公共段
    #
    # 为什么不用框架的 switch_next_char():
    #   死顺序 + 它内部会补普攻 + 守岸人满协奏下场后 16 秒内会被框架判成 NO（本队她一圈
    #   里上场两次，第二次就在锁里）。直接按数字键切人绕开了这三条，代价是交接记账
    #   要自己补，全在 handoff_to() 里。
    SWITCH_TIMEOUT: float = 2.0
    SWITCH_KEY_INTERVAL: float = 0.12
    SWITCH_SETTLE: float = 0.06
    HANDOFF_CON_WAIT: float = 0.8
    HANDOFF_CON_POLL: float = 0.1
    CON_QUICK_WAIT: float = 0.08
    CON_FULL_SOFT: float = 0.985       # 0.99 哨兵也算满（见 con_now）
    CON_CONFIRM_WAIT: float = 0.12
    HOLD_POLL: float = 0.1
    FILL_CON_INTERVAL: float = 0.20
    TEAM_HUD_WAIT: float = 3.0
    SWITCH_ANCHOR_MAX: float = 1.5
    INTRO_PENDING_TTL: float = 8.0
    LEAVE_TRIES: int = 2
    GATE_LOG_EVERY: float = 3.0
    TAP_DOWN: float = 0.06
    # 开场就在场上（编队 1 号位）时跑 f1
    OPENER_MODE: str = 'f1'
    # s2 的第一个动作就是 E。变奏 QTE 的不可输入窗口比 INTRO_ANIM=1.45 短
    # （18:33 那局 50.94s 的画面她已经在站着了），所以只等 0.42s：
    # 0.60s 实机还是晚 0.18s，用户 2026-11-24 要求再提前 0.18s。
    # v1.6.0（从 1.5.0 起改）：用户又要求提前 0.4s ⇒ 直接压到 0.05s。
    # 万一按键被 QTE 吃掉，cast_resonance 会在 E_CAST_TIMEOUT(0.45s) 后补一发。
    FAST_INTRO_MODES: tuple = ('s2',)
    FAST_INTRO_ANIM: float = 0.05

    intro_pending = False
    intro_pending_at = 0.0
    switch_confirmed_at = 0.0
    handoff_source = None
    handoff_source_at = 0.0
    _exit_fill = 0.0
    _con_full_confirmed = False
    _skip_con_check = False
    _force_switch_me = False
    _entry_mode = None
    _node = None
    started = False
    _startup_done = False
    _axis_char = True
    # 开场把「按住重击」交给下一位（视频 0:00）
    _handoff_holding = False

    def note_handoff_source(self, source):
        self.handoff_source = source.__class__.__name__ if source is not None else None
        self.handoff_source_at = time.time()

    def take_handoff_source(self):
        name = self.handoff_source
        if name is not None and time.time() - self.handoff_source_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: handoff_source ({name}) 已过期, 按未知处理')
            name = None
        self.handoff_source = None
        self.handoff_source_at = 0.0
        return name

    def note_intro_handoff(self):
        self.intro_pending = True
        self.intro_pending_at = time.time()

    def take_intro(self):
        pending = self.intro_pending
        if pending and time.time() - self.intro_pending_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: intro_pending 已过期, 按空手入场处理')
            pending = False
        self.intro_pending = False
        self.intro_pending_at = 0.0
        return self.has_intro or pending

    def reset_fixed_rotation(self, chars=None):
        for char in (chars if chars is not None else [self]):
            if char is None:
                continue
            char.intro_pending = False
            char.intro_pending_at = 0.0
            char.handoff_source = None
            char.handoff_source_at = 0.0

    # ---------------------------------------------------------------- 切人
    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        演出期间队伍 HUD 整块不画：盲区里补按一次就等，HUD 回来再核对 index。
        """
        start = time.time()
        blind_total = 0.0
        blind_pressed = False
        while True:
            in_team, current_index, _ = self.task.in_team()
            if in_team:
                blind_pressed = False
                if current_index == index:
                    # 先记时间戳再站稳：锚点晚 SWITCH_SETTLE 会让入场等待整体推迟
                    self.switch_confirmed_at = time.time()
                    self.settle_after_switch(self.SWITCH_SETTLE)
                    return True
                if time.time() - start - blind_total >= self.SWITCH_TIMEOUT:
                    return False
                self.task.send_key(index + 1)
            else:
                blind_total += self.SWITCH_KEY_INTERVAL
                if blind_total >= self.TEAM_HUD_WAIT:
                    return False
                if not blind_pressed:
                    self.task.send_key(index + 1)
                    blind_pressed = True
            self.task.next_frame()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)

    def settle_after_switch(self, duration):
        self.sleep(max(0.0, duration), check_combat=False)

    def handoff_to(self, target, has_intro):
        """复刻 switch_next_char() 内部那套记账（绕开框架切人后必须自己补）。"""
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if hasattr(target, 'note_handoff_source'):
            target.note_handoff_source(self)
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def con_now(self):
        """协奏是否算满（把 0.99 哨兵算进去）。

        【为什么需要】框架在「协奏环面积已经超过满环、但轮廓没闭合」时，会把读数夹成 0.99
        并让 is_con_full() 回 False（日志原话 is_con_full not full but percent greater than 1,
        set to 0.99, 1.047）。这时游戏其实已经满协奏、可以延奏了：
        我们按「没满」交接，游戏却演了延奏/QTE，下一棒在 QTE 里按的键全被吞。
        2026-11-24 18:55 那局守岸人两次 ↓ 的读数都是 0.9900（面积 1.04/1.05），就是这个情况。
        """
        try:
            value = self.get_current_con()
        except Exception:
            return self.is_con_full()
        if value is None:
            return self.is_con_full()
        return value >= self.CON_FULL_SOFT

    def wait_con_full(self, timeout=None):
        timeout = self.HANDOFF_CON_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.con_now():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.con_now():
                    return True
            else:
                self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        return False

    def char_at_slot(self, slot):
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def wait_team_hud(self, timeout=None):
        timeout = self.TEAM_HUD_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.task.in_team()[0]:
                return True
            self.task.next_frame()
            self.sleep(0.08, check_combat=False)
        self.logger.warning(f'{self.TAG}: 队伍 HUD {timeout:.1f}s 还没回来')
        return False

    def switch_in_anchor(self):
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now

    # ---------------------------------------------------------------- 强切协议
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return SwitchPriority.NORMAL

    def _find_teammate(self, class_name):
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _exit_intro(self):
        if self._skip_con_check:
            self._skip_con_check = False
            self._exit_fill = 0.0
            return False
        fill = self._exit_fill
        self._exit_fill = 0.0
        if self._con_full_confirmed:
            self._con_full_confirmed = False
            return True
        if fill <= 0:
            return self.wait_con_full(self.CON_QUICK_WAIT)
        if self.wait_con_full(self.CON_QUICK_WAIT):
            return True
        self.logger.info(f'{self.TAG}: 协奏没满, 离场前补普攻 (上限 {fill:.1f}s)')
        start = time.time()
        filled_full = False
        while self.time_elapsed_accounting_for_freeze(start) < fill:
            if self.con_now():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.con_now():
                    filled_full = True
                    break
            self.check_combat()
            self.tap()
            self.sleep(self.FILL_CON_INTERVAL)
        has_intro = filled_full or self.wait_con_full(self.CON_QUICK_WAIT)
        if not has_intro:
            self.logger.info(f'{self.TAG}: 交接时协奏没满, 下一个人按平切入场')
        return has_intro

    def _direct_switch(self, target, has_intro):
        """按数字键直接切过去 + 自己补交接记账。失败返回 False 交给框架兜底。"""
        for attempt in range(1, self.LEAVE_TRIES + 1):
            self.wait_team_hud()
            if self.switch_to_index(target.index):
                self.handoff_to(target, has_intro)
                self.logger.info(f'{self.TAG}: 交接 {target.__class__.__name__} '
                                 f'(intro={has_intro}, 第 {attempt} 次)')
                return True
            has_intro = has_intro or self.wait_con_full()
            self.logger.warning(f'{self.TAG}: 直切失败 (第 {attempt}/{self.LEAVE_TRIES} 次)')
        return False

    def _force_switch_to(self, target, mode):
        if target is None:
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            has_intro = self._exit_intro()
            if self._direct_switch(target, has_intro):
                if self._handoff_holding:
                    # 【跨角色预输入】把「按住左键」交给下一位：他接手后继续按住再松
                    self._handoff_holding = False
                    target._handoff_hold = True
                    self.logger.info(f'{self.TAG}: 按住状态交给 {target.__class__.__name__}')
                return True
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=direct_switch_failed')
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False
            if self._handoff_holding:
                # 没交出去就自己松手, 绝不让左键一直按着
                self._handoff_holding = False
                self.task.mouse_up()
                self.logger.warning(f'{self.TAG}: 交接失败, 自己松手')

    # ---------------------------------------------------------------- 分发器
    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        entry = 'natural' if mode is None else 'forced'
        if mode is None:
            if not self.started:
                mode = self.OPENER_MODE
            elif self._startup_done:
                mode = 's1'
            else:
                self.logger.info(f'{self.TAG}: 启动轴进行中被自然入场, 交还框架切人')
                return self.switch_next_char()
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, 'perform_' + mode, None)
        if func is None:
            self.logger.info(f'{self.TAG}: interrupt reason=unknown_mode mode={mode} next=framework')
            return self.switch_next_char()
        self._node = mode
        self.check_f_on_switch = False
        source = self.take_handoff_source()
        intro = self.take_intro()
        anchor = self.switch_in_anchor()
        self.logger.info(f'{self.TAG}: [{mode.upper()}] enter (intro={intro}, '
                         f'mode={entry}, source={source})')
        if intro:
            intro_anim = self.INTRO_ANIM
            if mode in getattr(self, 'FAST_INTRO_MODES', ()):
                intro_anim = self.FAST_INTRO_ANIM
            self.sleep(max(0.0, anchor + intro_anim - time.time()), check_combat=False)
            if not self.task.in_team()[0]:
                self.task.wait_until(lambda: self.task.in_team()[0], time_out=2.0, settle_time=0.1)
        if self.flying():
            self.sleep(0.30, check_combat=False)
            self.tap()
            self.sleep(0.20, check_combat=False)
        return func()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._exit_fill = 0.0
        self._con_full_confirmed = False
        self._skip_con_check = False
        if self._handoff_holding:
            self._handoff_holding = False
            self.task.mouse_up()
        self._reset_char_state()

    def on_combat_end(self, chars):
        self.reset_fixed_rotation(chars)
        super().on_combat_end(chars)

    # ---------------------------------------------------------------- 通用动作
    def tap(self, after_sleep=0.0):
        """短按普攻。task.click() 缺省时会把 down_time 压回 0.01（10ms 会被吞），
        所以按下/抬起自己发，按住 TAP_DOWN 秒。"""
        self.task.mouse_down()
        try:
            self.sleep(self.TAP_DOWN, check_combat=False)
        finally:
            self.task.mouse_up()
        if after_sleep:
            self.sleep(after_sleep)

    def attack_chain(self, count, interval, last_interval=None):
        for i in range(count):
            self.tap()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def dodge(self):
        self.task.click(key='right')

    def fire_liberation(self, window=None):
        """R —— 在窗口里等图标亮了再按。

        大招动画期间框架会默认每 0.1 秒发一次 F（click_f），这条轴上没有要她按的处决，
        传 click_f=False，击破留给需要它的节点。
        """
        self.task.in_liberation = False
        window = self.LIB_WINDOW if window is None else window
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < window:
            self.task.next_frame()
            if self.liberation_available():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    self.logger.info(f'{self.TAG}: 大招放出 (等了 {waited:.2f}s)')
                    return True
            self.check_combat()
            self.tap()
            self.sleep(self.LIB_RETRY)
        self.logger.warning(f'{self.TAG}: 大招图标 {window:.1f}s 内没亮, 硬按一次')
        return bool(self.click_liberation(wait_if_cd_ready=0.5, click_f=False))

    def fire_echo(self):
        if self.ECHO_TRIES <= 0:
            return False
        was_available = self.echo_available()
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if not was_available:
                return False
            if not self.echo_available():
                if i:
                    self.logger.info(f'{self.TAG}: echo landed on try {i + 1}')
                return True
        self.logger.warning(f'{self.TAG}: echo still reads available after {self.ECHO_TRIES} tries')
        return False

    def cast_resonance(self):
        for attempt in range(self.E_RETRIES):
            self.check_combat()
            self.send_resonance_key()
            if self.task.wait_until(lambda: not self.resonance_available(),
                                    time_out=self.E_CAST_TIMEOUT):
                self.record_resonance_use()
                return True
            if attempt + 1 < self.E_RETRIES:
                self.logger.warning(f'{self.TAG}: E 第 {attempt + 1} 次没进冷却, 补普攻后重发')
                self.tap()
                self.sleep(0.25)
        self.logger.warning(f'{self.TAG}: E 两次都没进冷却, 跳过')
        return False

    # ================================================================ 守岸人这一棒
    #
    # 轴原文（视频 0:04 轴表）：启动「守 AAEAAZ」「守 AAAZRZ↓」；循环「守 AAAQ」「守 EAAZRZ↓」。
    #
    # 【重击是「按住不松」】视频原话两处：开场「守岸人重击按住不松」、循环收尾
    # 「大招动画时预输入重击」。她的重击分两种：
    #   回路满 5 格（A1/A2/A3/A4 攒满）→ 强化重击（化蝶 / 耀星·蝶），协奏 +6；
    #   没满 → 普通重击-化蝶，把场上的坍缩核催成蝴蝶。
    # 轴没写是哪一种，代码按「回路满了就强化重击，没满就普通重击」处理并打日志。
    INTRO_ANIM = 1.45        # QTE 第 86F 前不响应输入, 第 65F 前不能切人
    A_INTERVAL = 0.32
    A_TO_E = 0.12
    E_TO_A = 0.55            # E-地面 派生 40F，演完才轮得到下一组普攻
    A_TO_HEAVY = 0.15
    HEAVY_HOLD = 0.45        # 普通重击按住时长
    # Z 之前等「回路满、可以长按」提示的上限。A 落空时继续补 A（0.20s 一下），
    # 亮了立刻按住；到点还不亮才退回普通重击。
    FORTE_WAIT = 2.00
    FORTE_FILL_INTERVAL = 0.20
    PREHOLD_TAIL = 0.30      # R 演完再按住这么久，保证长按触发（0.25s）后松手
    HEAVY_TO_ECHO = 0.12
    ECHO_TO_LIB = 0.04
    HEAVY_TO_LIB = 0.10
    E_CAST_TIMEOUT = 0.45    # E 进冷却的确认窗口（0.9s 只用于开局那次 15.7s 冷却的读数）
    E_RETRIES = 2
    ECHO_TRIES = 1
    ECHO_RETRY = 0.05
    LIB_WINDOW = 4.0
    LIB_RETRY = 0.15

    def _reset_char_state(self):
        # 内置 ShoreKeeper 里 check_f_on_switch 被设成 True、还带一套 Augusta 专判; 本队不走那条
        self.check_f_on_switch = False
        # 原生 switch_next_char() 里那两个记账字段: 队友的 shorekeeper_auto_dodge() 靠它们
        # 决定还能不能替人闪避。本队走直切, 在 switch_out() 里补。
        self.outrotime = -1
        self.dodge_count = 0

    def skip_combat_check(self):
        """大招演出期间照样算在战斗里: 她的大招有 3 秒以上全屏动画, HUD 全隐。"""
        return self.has_intro or self.flying()

    def switch_out(self, con_full=False):
        """满协奏离场时给全队开「替他闪避」窗口。"""
        if con_full:
            self.outrotime = time.time()
            self.dodge_count = 5
        super().switch_out(con_full=con_full)

    # ------------------------------------------------------------------ 节点
    def perform_f1(self):
        self._action_opening('f1', 'Galbrena.f1')
        self._force_switch_to(self._find_teammate('Galbrena'), 'f1')

    def perform_f2(self):
        self._action_3a_z_r_z('f2', 'Lupa.s1')
        self._force_switch_to(self._find_teammate('Lupa'), 's1')

    def perform_s1(self):
        self._action_3a_q('s1', 'Galbrena.s2')
        self._force_switch_to(self._find_teammate('Galbrena'), 's2')

    def perform_s2(self):
        self._action_e_2a_z_r_z('s2', 'Lupa.s1')
        self._force_switch_to(self._find_teammate('Lupa'), 's1')

    # ------------------------------------------------------------------ 动作体
    def _action_opening(self, tag, nxt):
        """守 AAEAAZ：2A → E（回血 + 5 只蝴蝶）→ 2A → 重击（按住不放，交给嘉贝）。

        【轴原文是 AAEAAZ，不是 AAEAZ】视频 0:04 轴表第一行、放大图
        `media/frames/open_axis2_00020.00.jpg`：4 下普攻打满核心
        （A1 1 + A2 2 + A3 2 + A4 1），Z 才是强化重击。
        v1.0.0 少抄了一组 A，只有 3 下 → 提示不亮 → 退化成普通重击（用户看到的「开场 Z 失败」）。

        【跨角色预输入】视频 0:00「守岸人重击按住不松，切嘉贝自动打完 3Z」：
        这里的重击不松手，按住状态直接交给嘉贝（见 forte_heavy_keep_holding / _force_switch_to）。
        """
        self.attack_chain(2, self.A_INTERVAL, last_interval=self.A_TO_E)
        ok = self.cast_resonance()
        self.sleep(self.E_TO_A)
        self.attack_chain(2, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        z = self.forte_heavy_keep_holding()
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={ok and z} '
                         f'reason=done next={nxt} (hold=on)')

    def _action_3a_q(self, tag, nxt):
        """守 AAAQ：3A → Q（声骸）。视频原话「守岸人3A开Q覆盖嘉露二人爆发期」。"""
        self.attack_chain(3, self.A_INTERVAL, last_interval=self.HEAVY_TO_ECHO)
        q = self.fire_echo()
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={q} reason=done next={nxt}')

    def _action_3a_z_r_z(self, tag, nxt):
        """守 AAAZRZ↓：3A → 重击 → R（动画里预输入重击，HUD 回来立刻切）→ 延奏露帕。"""
        self.attack_chain(3, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        z1 = self.forte_heavy_fill()
        self.sleep(self.HEAVY_TO_LIB)
        r = self.liberation_with_heavy_preinput()
        # 预输入的意义就是立刻切人：不补协奏、不再补动作（视频 0:44 字幕 ②）
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={z1 and r} '
                         f'reason=done next={nxt}')

    def _action_e_2a_z_r_z(self, tag, nxt):
        """守 EAAZRZ↓：循环收尾。E → 2A → 重击 → R（动画里预输入重击）→ 立刻切露帕。"""
        ok = self.cast_resonance()
        self.sleep(self.E_TO_A)
        self.attack_chain(2, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        z1 = self.forte_heavy_fill()
        self.sleep(self.HEAVY_TO_LIB)
        r = self.liberation_with_heavy_preinput()
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={ok and r} '
                         f'reason=done next={nxt}')

    # ------------------------------------------------------------------ 动作
    def forte_heavy_keep_holding(self):
        """强化重击，并且**按住不放**：把按住状态交给下一个角色（嘉贝接着打完 3Z）。

        视频 0:00：「守岸人重击按住不松，切嘉贝自动打完 3Z」——跨角色预输入。
        所以这里等重击真的出手（长按提示消失）后不松手，交给 _force_switch_to 转交；
        切人失败时在 finally 里自己松手，绝不让鼠标一直按着。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE_WAIT:
            if self.is_mouse_forte_full():
                break
            self.check_combat()
            self.tap()
            self.sleep(self.FORTE_FILL_INTERVAL)
        full = self.is_mouse_forte_full()
        self.task.mouse_down()
        self._handoff_holding = True
        if full:
            self.task.wait_until(lambda: not self.is_mouse_forte_full(), time_out=1.5, settle_time=0.05)
            self.logger.info(f'{self.TAG}: 强化重击 按住中, 交给下一位')
        else:
            self.sleep(self.HEAVY_HOLD, check_combat=False)
            self.logger.warning(f'{self.TAG}: 回路没满, 普通重击按住交给下一位')
        return True

    def forte_heavy_fill(self):
        """Z：回路满（5 格核心）才是强化重击。

        轴给的是 AAEAAZ / AAAZ / (E)AAZ，A 打满核心；但实测开场那一下有几发 A 落空
        （boss 位移/浮空），提示不亮，直接按就退化成普通重击，白丢蝴蝶和 6 点协奏。
        所以没亮就继续点 A（上限 FORTE_WAIT），提示一亮立刻按住到蝴蝶出来；
        始终不亮才退回普通重击（并记 warning，下次能从日志看出来）。
        """
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE_WAIT:
            if self.is_mouse_forte_full():
                waited = self.time_elapsed_accounting_for_freeze(start)
                ok = bool(self.heavy_click_forte(self.is_mouse_forte_full))
                self.logger.info(f'{self.TAG}: 强化重击 {"打出" if ok else "没打出"} (补了 {waited:.2f}s)')
                return ok
            self.check_combat()
            self.tap()
            self.sleep(self.FORTE_FILL_INTERVAL)
        self.heavy_attack(self.HEAVY_HOLD)
        self.logger.warning(f'{self.TAG}: 回路 {self.FORTE_WAIT:.1f}s 内没满(一直在补 A), 走普通重击')
        return True

    def liberation_with_heavy_preinput(self):
        """R → 在动画里预输入重击（Z）→ HUD 回来立刻松手切人。

        【视频 0:44 字幕原话】「大招动画时按住重击，有两个作用：①提前攒协奏
        ②如果直接 R 切露帕会触发露帕变奏无时停 bug，浪费约 1.3 秒」。
        【用户 2026-11-24】「HUD 回来后不用再按了，应该立刻切人，这才叫预输入」。

        所以：按住只是为了让重击排在 R 结束那一帧自己出来；HUD 一回来就松手并立刻切，
        不再补按、不等 0.3s、也不补协奏。v1.1.0 在这里多按了一次重击、还补了 1.5s 协奏，
        正好和「预输入」相反。

        按住期间不发任何别的键（rules 5-4），异常也在 finally 里松手。
        """
        self.task.in_liberation = False
        start = time.time()
        fired = False
        while self.time_elapsed_accounting_for_freeze(start) < self.LIB_WINDOW:
            self.task.next_frame()
            if self.liberation_available():
                self.send_liberation_key()
                self.record_liberation_use()
                fired = True
                break
            self.check_combat()
            self.tap()
            self.sleep(self.LIB_RETRY)
        if not fired:
            self.logger.warning(f'{self.TAG}: 大招图标 {self.LIB_WINDOW:.1f}s 内没亮')
            return False
        # 确认演出真的开始了（HUD 消失），再按住；否则按在空地就白按
        if not self.task.wait_until(lambda: not self.task.in_team()[0], time_out=0.6, settle_time=0.02):
            self.logger.warning(f'{self.TAG}: R 按下但 HUD 没消失, 补按一次')
            self.send_liberation_key()
            if not self.task.wait_until(lambda: not self.task.in_team()[0], time_out=0.8, settle_time=0.02):
                return False
        self.task.in_liberation = True
        self.logger.info(f'{self.TAG}: R 演出开始, 预输入重击(按住)')
        self.task.mouse_down()
        try:
            # 一直按到 HUD 回来：重击在动画结束那一帧自己出来
            self.task.wait_until(lambda: self.task.in_team()[0], time_out=6.0, settle_time=0.10)
        finally:
            self.task.mouse_up()
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)
        self.logger.info(f'{self.TAG}: R 结束+松手 ({time.time() - start:.2f}s), 立刻切人')
        return True
